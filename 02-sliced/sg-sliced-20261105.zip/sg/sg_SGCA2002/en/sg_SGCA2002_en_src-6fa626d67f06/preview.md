# SGCA2002 · 战略物品（管制）法（2002）

- 语言：`en`
- 版本：`sg:SGCA2002:en:src-6fa626d67f06`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：41；切片：41；发布资格：否

PDF 页数 32，空白页 []，目录页 [1, 2, 3, 4]，条文 39。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE STRATEGIC GOODS (CONTROL) ACT 2002 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Strategic Goods (Control) Act 2002 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3.
[Repealed] 4. Appointment of authorised officers and senior authorised officers 4A. Strategic goods and strategic goods technology
PART 2 TRANSFER AND BROKERING OF STRATEGIC GOODS AND STRATEGIC GOODS TECHNOLOGY 5. Transfer of strat
```

### `section:1` · section · 

```text
1. This Act is the Strategic Goods (Control) Act 2002. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “authorised officer” means —
(a) an officer appointed as an authorised officer under section 4; or
(b) an officer of customs within the meaning of section 3(1) of the Customs Act 1960; “bring in transit” means to bring goods from any country into Singapore by land, water or air, where the goods are to be taken out from Singapore on the same conveyance on which they are brought into Singapore without any landing in Singapore, but does not include the passage through Singapore in accordance with international law of a foreign conveyance carrying goods; “computer” has the meaning given by section 2(1) of the Computer Misuse Act 1993; “
```

### `section:3` · section · offence.

```text
3. [Repealed by Act 3 of 2021 wef 01/07/2025] Appointment of authorised officers and senior authorised officers
```

### `section:4` · section · officers

```text
4. The Minister may appoint any public officer or officer of a statutory body as an authorised officer or a senior authorised officer 6 for the purposes of this Act or any particular Part or provision of this Act. Strategic goods and strategic goods technology
```

### `section:4A` · section · Strategic goods and strategic goods technology

```text
4A.—(1) The Minister may, by order in the Gazette, prescribe ––
(a) any military or dual-use goods as strategic goods for the purposes of this Act; or
(b) any military or dual‑use technology as strategic goods technology for the purposes of this Act.
[45/2007]
(2) In subsection (1) –– “dual‑use goods” means goods capable of being used for both a non-military purpose and a military purpose or relevant activity; “dual‑use technology” means technology necessary for the development, production or use of any dual‑use goods; “military goods” means goods solely or predominantly designed or modified for a military purpose, including any part or component thereof; “military technology” means technolo
```

### `section:5` · section · Transfer of strategic goods, etc.

```text
5.—(1) A person must not —
(a) export, tranship or bring in transit any strategic goods;
(b) export any document in which any strategic goods technology is recorded, stored or embodied; or
(c) transmit any strategic goods technology. 7
(2) A person must not —
(a) export, tranship or bring in transit any goods;
(b) export any document in which any technology is recorded, stored or embodied; or
(c) transmit any technology, if —
(d) the person has been notified by an authorised officer or a senior authorised officer that the goods are or technology is intended or likely to be used, wholly or in part, for or in connection with a relevant activity;
(e) the person knows that the goods are or techn
```

### `section:6` · section · Brokering of strategic goods, etc.

```text
6.—(1) A person must not arrange or negotiate, or do any act to facilitate the arrangement or negotiation of —
(a) a contract for the acquisition or disposal of any goods mentioned in subsection (2) if the person knows or has reason to believe that such a contract will or is likely to result in the removal of those goods from one foreign country to another foreign country; or 9
(b) a contract for the acquisition, disposal or transmission of —
(i) any technology mentioned in subsection (3); or
(ii) any document in which such technology is recorded, stored or embodied,
(b) if the person knows or has reason to believe that such a contract will or is likely to result in the transmission of such 
```

