# CPFTA2003 · 消费者保护（公平交易）法（2003）

- 语言：`en`
- 版本：`sg:CPFTA2003:en:src-a75960bee418`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：89；切片：93；发布资格：否

PDF 页数 70，空白页 []，目录页 [1, 2, 3, 4]，条文 82。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CONSUMER PROTECTION (FAIR TRADING) ACT 2003 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Consumer Protection (Fair Trading) Act 2003 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 UNFAIR PRACTICES 3. Application of Part 4. Meaning of unfair practice 5. Circumstances surrounding unfair practice 6. Consumer’s right to sue for unfair practice 7. Jurisdiction and powers of courts 8. Volunta
```

### `section:1` · section · 

```text
1. This Act is the Consumer Protection (Fair Trading) Act 2003. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “chief executive” means the chief executive of the Commission and includes any person acting in that capacity; “Commission” means the Competition and Consumer Commission of Singapore established by section 3 of the Competition Act 2004; “consumer” means an individual who, otherwise than exclusively in the course of business —
(a) receives or has the right to receive goods or services from a supplier; or
(b) has a legal obligation to pay a supplier for goods or services that have been or are to be supplied to another individual; 3 “consumer transaction” means —
(a) the supply of goods or services by a supplier to a consumer as a resu
```

### `section:3` · section · Application of Part

```text
3. This Part does not apply unless —
(a) the supplier or consumer is resident in Singapore; or
(b) the offer or acceptance relating to the consumer transaction is made in or is sent from Singapore.
[7/2012] Meaning of unfair practice
```

### `section:4` · section · Meaning of unfair practice

```text
4. It is an unfair practice for a supplier, in relation to a consumer transaction — 7
(a) to do or say anything, or omit to do or say anything, if as a result a consumer might reasonably be deceived or misled;
(b) to make a false claim;
(c) to take advantage of a consumer if the supplier knows or ought reasonably to know that the consumer —
(i) is not in a position to protect his or her own interests; or
(ii) is not reasonably able to understand the character, nature, language or effect of the transaction or any matter related to the transaction; or
(d) without limiting paragraphs (a), (b) and (c), to do anything specified in the Second Schedule. Circumstances surrounding unfair practice
```

### `section:5` · section · Circumstances surrounding unfair practice

```text
5.—(1) An unfair practice may occur before, during or after a consumer transaction.
(2) An unfair practice may consist of a single act or omission.
(3) In determining whether or not a person has engaged in an unfair practice —
(a) the reasonableness of the actions of that person in those circumstances is to be considered; and
(b) an act or omission by an employee or agent of a person is deemed also to be an act or omission of the person if the act or omission occurred in the course of —
(i) the employee’s employment with the person; or
(ii) the agent exercising the powers or performing the duties on behalf of the person within the scope of the agent’s actual or apparent authority. Consumer’s
```

### `section:6` · section · Consumer’s right to sue for unfair practice

```text
6.—(1) A consumer who has entered a consumer transaction involving an unfair practice may commence an action in a court of competent jurisdiction against the supplier. 8
(2) The right to commence an action under subsection (1) does not apply where —
(a) the amount of the claim exceeds the prescribed limit; or
(b) there is no claim for money, and the remedy or relief sought in the action is in respect of a subject matter the value of which exceeds the prescribed limit.
(3) For the purposes of subsection (2)(a), where the amount claimed consists of a balance not exceeding the prescribed limit after set-off of any amount claimed or recoverable by the supplier from the consumer, being a set-off 
```

### `section:7` · section · Jurisdiction and powers of courts

```text
7.—(1) Despite section 5(1)(a) of the Small Claims Tribunals Act 1984, a Small Claims Tribunal has jurisdiction to hear and determine —
(a) any action under section 6(1) insofar as the action relates to an unfair practice involving a relevant contract;
(b) any action under section 8(6), (7) or (8) insofar as the action relates to an undertaking in respect of an unfair practice involving a relevant contract;
(c) any action under any regulations made under section 11 insofar as the action relates to a relevant contract, a time share contract or a time share related contract;
(d) any action under any provisions specified under section 43(2)(j), insofar as the action relates to a relevant contra
```

