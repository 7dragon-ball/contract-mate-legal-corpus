# TMA1998 · 商标法（1998）

- 语言：`en`
- 版本：`sg:TMA1998:en:src-9965a89b106c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：182；切片：184；发布资格：否

PDF 页数 134，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8]，条文 177。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE TRADE MARKS ACT 1998 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Trade Marks Act 1998 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. General interpretation 3. Meaning of infringing goods, material or articles and counterfeit goods or trade mark
PART 2 REGISTRATION OF TRADE MARKS Introductory 4. Registered trade marks Application for registration of trade mark 5. Application for registration 5A. Division of 
```

### `section:1` · section · 

```text
1. This Act is the Trade Marks Act 1998. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “business” includes a trade or profession; “business identifier” means any sign capable of being represented graphically which is used to identify any business; “certification mark” has the meaning given by section 61; “collective mark” has the meaning given by section 60; “Convention country” means —
(a) in section 10 and paragraph 13 of the Third Schedule, a country or territory, other than Singapore, which is —
(i) a party to the Paris Convention; or
(ii) a member of the World Trade Organisation; and
(b) in any other provision of this Act, a country or territory which is —
(i) a party to the Paris Convention; or
(ii) a member of 
```

### `section:3` · section · counterfeit goods or trade mark

```text
3.—(1) For the purposes of this Act —
(a) “infringing goods”, “infringing material” and “infringing articles” are to be construed in accordance with subsections (2), (3) and (4), respectively; and
(b) “counterfeit goods” and “counterfeit trade mark” are to be construed in accordance with subsections (5) and (6), respectively.
(2) Goods are “infringing goods”, in relation to a registered trade mark, if they or their packaging bears a sign identical with or similar to that mark and —
(a) the application of the sign to the goods or their packaging was an infringement of the registered trade mark;
(b) the goods are proposed to be imported into Singapore and the application of the sign in Singapo
```

### `section:4` · section · Registered trade marks

```text
4.—(1) A registered trade mark is a property right obtained by the registration of the trade mark under this Act and the proprietor of a 13 registered trade mark has the rights and remedies provided by this Act.
(2) No proceedings shall lie to prevent or recover damages for the infringement of an unregistered trade mark as such; but nothing in this Act affects the law relating to passing off or rights under the Geographical Indications Act 2014.
[19/2014] Application for registration of trade mark Application for registration
```

### `section:5` · section · Application for registration

```text
5.—(1) An application for registration of a trade mark must be made in the prescribed manner to the Registrar.
(2) The application must —
(a) contain a request for the registration of a trade mark;
(b) state the name and address of the applicant;
(c) contain a clear representation of the trade mark;
(d) list the goods or services in relation to which the applicant seeks to register the trade mark; and
(e) state —
(i) that the trade mark is being used in the course of trade, by the applicant or with the applicant’s consent, in relation to those goods or services; or
(ii) that the applicant has a bona fide intention that the trade mark should be so used.
(3) The application is subject to the p
```

### `section:5A` · section · Division of application for registration

```text
5A.—(1) Subject to this section and any rules made under subsection (3), an application for registration of a trade mark may, at the request of the applicant, be divided into 2 or more separate applications for registration of the trade mark.
[3/2007]
(2) A request under subsection (1) —
(a) must be made to the Registrar —
(i) in the prescribed manner; and
(ii) before the trade mark is registered; and
(b) is subject to the payment of such fee as may be prescribed.
[3/2007]
(3) The Minister may make rules for the purposes of this section and may, in those rules, provide for —
(a) the circumstances in which an application for registration of a trade mark may be divided;
(b) the conditions to b
```

### `section:6` · section · Classification of goods and services

```text
6.—(1) Goods and services must be classified, for the purposes of the registration of trade marks, according to a prescribed system of classification.
(2) Any question arising as to the class within which any goods or services fall is to be determined by the Registrar, whose decision is final. 15 Grounds for refusal of registration Absolute grounds for refusal of registration
```

