# CADDA1996 · 反补贴与反倾销税法（1996）

- 语言：`en`
- 版本：`sg:CADDA1996:en:src-4801599a3c59`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：49；切片：49；发布资格：否

PDF 页数 48，空白页 [2]，目录页 [1, 3, 4, 5]，条文 47。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE COUNTERVAILING AND ANTI-DUMPING DUTIES ACT 1996 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Countervailing and Anti-Dumping Duties Act 1996 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 COUNTERVAILING DUTIES 3. Imposition of countervailing duties 4. Initiation of investigation 5. Consultations with interested foreign governments 6. Duration of investigation 7. Preliminary determinatio
```

### `section:1` · section · 

```text
1. This Act is the Countervailing and Anti-Dumping Duties Act 1996. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “Agreement on Agriculture” means the Agreement by that name set out in Annex 1A to the World Trade Organisation Agreement; “Agreement on Implementation of Article VI of the General Agreement on Tariffs and Trade 1994” means the Agreement by that name set out in Annex 1A to the World Trade Organisation Agreement; “Agreement on Subsidies and Countervailing Measures” means the Agreement by that name set out in Annex 1A to the World Trade Organisation Agreement; “country” includes a customs union or customs territory; “domestic industry” means —
(a) the domestic producers as a whole of the like goods; or 3
(b) the domestic producers who
```

### `section:3` · section · Imposition of countervailing duties

```text
3.—(1) The Minister may impose a countervailing duty on the subject goods imported into Singapore where he or she determines —
(a) that a countervailable subsidy is being provided with respect to the subject goods; and
(b) that injury is found to exist in any one of the following ways:
(i) the subject goods are, through the effects of the subsidy, causing material injury to the domestic industry in Singapore producing like goods;
(ii) the subject goods are, through the effects of the subsidy, threatening to cause material injury to the domestic industry in Singapore producing like goods;
(iii) the subject goods are, through the effects of the subsidy, causing material retardation of the esta
```

### `section:4` · section · Initiation of investigation

```text
4.—(1) A written petition requesting that a countervailing duty investigation be initiated with regard to goods imported, or likely to be imported, into Singapore may be submitted to the Minister by any person on behalf of the domestic industry producing like goods.
(2) A petition must be in such form as may be determined by the Minister and must include evidence of each of the elements specified in section 3(1) and all other evidence that may be prescribed.
(3) The Minister must, within the period prescribed, review the petition and other available information and determine whether —
(a) sufficient evidence to warrant the initiation of an investigation into whether the elements necessary fo
```

### `section:5` · section · Consultations with interested foreign governments

```text
5.—(1) Before initiating a countervailing duty investigation and throughout such an investigation, the Minister must provide any interested foreign government an opportunity for consultation for the purpose of clarifying matters relevant to the investigation and arriving at a mutually agreed solution.
(2) The consultations must not impede the conduct of the investigation. 10 Duration of investigation
```

### `section:6` · section · Duration of investigation

```text
6. All countervailing duty investigations must, except in special circumstances, be concluded by the Minister within one year, and in no case more than 18 months after initiation. Preliminary determination of subsidy and injury
```

### `section:7` · section · Preliminary determination of subsidy and injury

```text
7.—(1) The Minister must, within such period as may be prescribed, make a preliminary determination regarding —
(a) whether a countervailable subsidy is being provided with respect to the subject goods, and the amount of such countervailable subsidy; and
(b) whether injury is found to exist in any one of the following ways:
(i) the subject goods are, through the effects of the subsidy, causing material injury to the domestic industry in Singapore producing like goods;
(ii) the subject goods are, through the effects of the subsidy, threatening to cause material injury to the domestic industry in Singapore producing like goods;
(iii) the subject goods are, through the effects of the subsidy, c
```

