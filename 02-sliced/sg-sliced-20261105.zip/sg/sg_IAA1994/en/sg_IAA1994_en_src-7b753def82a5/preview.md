# IAA1994 · 国际仲裁法（1994）

- 语言：`en`
- 版本：`sg:IAA1994:en:src-7b753def82a5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：83；切片：88；发布资格：否

PDF 页数 63，空白页 []，目录页 [1, 2, 3, 4]，条文 79。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE INTERNATIONAL ARBITRATION ACT 1994 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 International Arbitration Act 1994 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title
PART 2 INTERNATIONAL COMMERCIAL ARBITRATION 2. Interpretation of this Part 2A. Definition and form of arbitration agreement 3. Model Law to have force of law 4. Interpretation of Model Law by use of extrinsic material 5. Application of this Part 6. Enf
```

### `section:1` · section · 

```text
1. This Act is the International Arbitration Act 1994.
PART 2 INTERNATIONAL COMMERCIAL ARBITRATION Interpretation of this Part
```

### `section:2` · section · Interpretation of this Part

```text
2.—(1) In this Part, unless the context otherwise requires — “arbitral tribunal” means a sole arbitrator or a panel of arbitrators or a permanent arbitral institution, and includes an emergency arbitrator appointed pursuant to the rules of 3 arbitration agreed to or adopted by the parties including the rules of arbitration of an institution or organisation; “appointing authority” means the authority designated under section 8(2) or (3); “arbitration agreement” means an arbitration agreement mentioned in section 2A; “award” means a decision of the arbitral tribunal on the substance of the dispute and includes any interim, interlocutory or partial award but excludes any order or direction made
```

### `section:2A` · section · Definition and form of arbitration agreement

```text
2A.—(1) In this Act, “arbitration agreement” means an agreement by the parties to submit to arbitration all or certain disputes which have arisen or which may arise between them in respect of a defined legal relationship, whether contractual or not.
[12/2012]
(2) An arbitration agreement may be in the form of an arbitration clause in a contract or in the form of a separate agreement.
[12/2012]
(3) An arbitration agreement must be in writing.
[12/2012] 4
(4) An arbitration agreement is in writing if its content is recorded in any form, whether or not the arbitration agreement or contract has been concluded orally, by conduct or by other means.
[12/2012]
(5) The requirement that an arbitration
```

### `section:3` · section · Model Law to have force of law

```text
3.—(1) Subject to this Act, the Model Law, with the exception of
Chapter VIII of the Model Law, has the force of law in Singapore.
(2) In the Model Law — “State” means Singapore and any country other than Singapore; “this State” means Singapore. Interpretation of Model Law by use of extrinsic material
```

### `section:4` · section · Interpretation of Model Law by use of extrinsic material

```text
4.—(1) For the purposes of interpreting the Model Law, reference may be made to the documents of —
(a) the United Nations Commission on International Trade Law; and
(b) its working group for the preparation of the Model Law, relating to the Model Law.
(2) Subsection (1) does not affect the application of section 9A of the Interpretation Act 1965 for the purposes of interpreting this Act. Application of this Part
```

### `section:5` · section · Application of this Part

```text
5.—(1) This Part and the Model Law do not apply to an arbitration which is not an international arbitration unless the parties agree in writing that this Part or the Model Law is to apply to that arbitration.
(2) Despite Article 1(3) of the Model Law, an arbitration is international if —
(a) at least one of the parties to an arbitration agreement, at the time of the conclusion of the agreement, has its place of business in any State other than Singapore;
(b) one of the following places is situated outside the State in which the parties have their places of business:
(i) the place of arbitration if determined in, or pursuant to, the arbitration agreement;
(ii) any place where a substantial pa
```

### `section:6` · section · Enforcement of international arbitration agreement

```text
6.—(1) Despite Article 8 of the Model Law, where any party to an arbitration agreement to which this Act applies institutes any proceedings in any court against any other party to the agreement in respect of any matter which is the subject of the agreement, any party to the agreement may, at any time after filing and serving a notice of intention to contest or not contest and before delivering any pleading (other than a pleading asserting that the court does not have jurisdiction in the proceedings) or taking any other step in the proceedings, apply to that court to stay the proceedings so far as the proceedings relate to that matter.
[Act 25 of 2021 wef 01/04/2022]
(2) The court to which an
```

