# MTA2021 · 多式联运法（2021）

- 语言：`en`
- 版本：`sg:MTA2021:en:src-84b81dd7cf85`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：33；切片：33；发布资格：否

PDF 页数 28，空白页 []，目录页 [1, 2, 3, 4]，条文 31。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE MULTIMODAL TRANSPORT ACT 2021 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Multimodal Transport Act 2021 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Application of Parts 3 to 6
PART 2 REGISTRATION UNDER REGISTER OF SINGAPORE COMPETENT NATIONAL BODY 4. Registration 5. Renewal of registration certificate 6. Cancellation of registration certificate 7. Minister may designate others to hear a
```

### `section:1` · section · 

```text
1. This Act is the Multimodal Transport Act 2021. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “ASEAN Framework Agreement on Multimodal Transport” means the ASEAN Framework Agreement on Multimodal Transport, signed at Vientiane, Lao People’s Democratic Republic, on 17 November 2005; “ASEAN member country” means a country declared by the Minister, by notification in the Gazette, as having ratified or acceded to the ASEAN Framework Agreement on Multimodal Transport; “carrier”, in relation to any goods that are the subject of a multimodal transport contract, means a person who performs or undertakes to perform the carriage, or part of the carriage, of the goods by any mode of transport, whether or not the person is the multimoda
```

### `section:3` · section · Application of Parts 3 to 6

```text
3.—(1) Parts 3 to 6 apply in relation to any civil claim relating to the carriage of goods that are the subject of a multimodal transport contract but only if either or both of the following are satisfied:
(a) the place for the taking in charge of the goods by the multimodal transport operator of the contract as specified in the contract is located in Singapore or an ASEAN member country;
(b) the place for delivery of the goods by the multimodal transport operator of the contract as specified in the contract is located in Singapore or an ASEAN member country. 6
(2) Subsection (1) applies to any civil claim whether founded in contract or tort, and whether made against the multimodal transport
```

### `section:4` · section · Registration

```text
4.—(1) A person who desires to be under the register of the Singapore competent national body must apply to the Singapore competent national body for a registration certificate under this section.
(2) An application under subsection (1) must —
(a) be made in the form and manner that the Singapore competent national body requires;
(b) be accompanied by the prescribed non‑refundable application fee; and
(c) include such information as may be prescribed.
(3) Upon receiving an application under subsection (1), the Singapore competent national body may —
(a) issue a registration certificate to the person, with or without conditions, certifying that the person has been entered in the register of t
```

### `section:5` · section · Renewal of registration certificate

```text
5.—(1) An application for the renewal of a registration certificate must —
(a) be made to the Singapore competent national body at least 3 months before the date the registration certificate expires; 8
(b) be made in the form and manner that the Singapore competent national body requires;
(c) be accompanied by the prescribed non-refundable application fee; and
(d) include such information as may be prescribed.
(2) If an application to renew a registration certificate is submitted to the Singapore competent national body less than 3 months before the registration certificate expires, the application is treated as an application under section 4.
(3) Upon receiving an application under subsecti
```

### `section:6` · section · Cancellation of registration certificate

```text
6.—(1) If the Singapore competent national body is satisfied that the holder of a registration certificate —
(a) has, when making an application under section 4 or 5 relating to the registration certificate, made any statement that is incorrect or false in any material particular; 9
(b) has otherwise procured the registration certificate by fraud or misrepresentation; or
(c) is contravening or has contravened any of the conditions of the registration certificate, the Singapore competent national body may, by notice, cancel the registration certificate.
(2) Before cancelling the registration certificate, the Singapore competent national body must give notice to the holder of the registration 
```

### `section:7` · section · Minister may designate others to hear appeals

```text
7.—(1) The Minister may designate any of the following persons to hear and determine, in the Minister’s place, any appeal under section 4, 5 or 6:
(a) the Second Minister for his or her Ministry;
(b) any Minister of State, including a Senior Minister of State, for his or her Ministry;
(c) any Parliamentary Secretary, including a Senior Parliamentary Secretary, to his or her Ministry.
(2) A reference to the Minister in section 4, 5 or 6 includes a reference to a person designated under subsection (1). Register
```

