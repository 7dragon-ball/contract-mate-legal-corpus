# SGCA2002-RG1 · 战略物品管制规例

- 语言：`en`
- 版本：`sg:SGCA2002-RG1:en:src-7be096a3bb96`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：61；切片：61；发布资格：否

PDF 页数 30，空白页 []，目录页 [1, 2, 3]，条文 54。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
Strategic Goods (Control) Regulations Table of Contents
Part I PRELIMINARY 1 Citation 2 Definitions
Part II PERMITS 3 Application for grant or renewal of permit under section 7(1) 4 Information and documents in connection with grant, renewal or amendment of permit 5 Grounds for refusal to grant or renew single-use permit 6 Grounds for refusal to grant or renew bulk permit 7 Reporting requirements for bulk permit 7A Reporting requirements for registered persons 8 Conditions of permit 9 Validity period of permit 10 Power of inspection, examination, etc. 11 Suspension or cancellation of permit 12 Amendment to permit 12A Prescribed service for the purpose of section 6(7) 13 Exemption
Part III RE
```

### `section:1` · section · 

```text
1.  These Regulations may be cited as the Strategic Goods (Control) Regulations. Definitions
```

### `section:2` · section · Definitions

```text
2.—(1)  In these Regulations, unless the context otherwise requires — “bulk permit” means a permit authorising multiple exports, transhipments or transmissions, as the case may be, of the goods, document or technology described in the permit during the period specified in the permit; “decision of the United Nations Security Council” means a decision of the United Nations Security Council in resolutions made under Chapter VII of the Charter of the United Nations signed at San Francisco on 26th June 1945; “exporting country”, in relation to any goods, document or technology in respect of which an application for a permit is made or in respect of which a permit is granted, means any country or 
```

### `section:3` · section · Application for grant or renewal of permit under section 7(1

```text
3.—(1)  Subject to paragraph (2), a person may, under section 7(1), apply for a permit that is —
(a) a single-use permit; or
(b) a bulk permit.
(2)  A person may apply for a bulk permit only in respect of an act referred to in section 5(1).
(3)  An application for the grant or renewal of a permit shall be made by the person who wishes to carry out the act concerned or a person acting on his behalf.
(4)  An application for the grant of a single-use permit shall be made not less than 5 working days before —
(a) the goods or document in respect of which the application is made is brought on board the conveyance on which it is to be exported or transhipped, in the case of export or transhipment;
```

### `section:4` · section · permit

```text
4.—(1)  Every application for the grant or renewal of a permit under regulation 3 or for the amendment to a permit under regulation 12 shall be accompanied by such information or document as the Director-General may require.
(2)  Without prejudice to the generality of paragraph (1), the information or document required by the Director-General may include —
(a) any manual, brochure, data sheet or other document containing such technical information or specifications in respect of the goods, document or technology in respect of which the application is made as the Director- General considers necessary;
(b) the end-user certificate or statement; and
(c) where the goods, document or technology i
```

### `section:5` · section · Grounds for refusal to grant or renew single-use permit

```text
5.—(1)  The Director-General may refuse to grant or renew a single-use permit if —
(a) the applicant has been convicted of an offence under the Act or any other written law set out in the First Schedule;
(b) the act in respect of which the application for a permit is made would contravene or result in any act which would contravene any written law set out in the First Schedule;
(c) the applicant was previously granted a permit which was subsequently cancelled;
(d) in the opinion of the Director-General, the act in respect of which the application for a permit is made is or is likely to be related to or in furtherance of any activity, object or purpose which is contrary to public interest or 
```

### `section:6` · section · Grounds for refusal to grant or renew bulk permit

```text
6.—(1)  The Director-General shall refuse to grant or renew a bulk permit where the applicant is unable to satisfy the Director-General that —
(a) he has implemented or will implement such measures or procedures as may be specified by the Director-General to ensure compliance with the provisions of the Act and the conditions of the permit;
(b) where the goods, document or technology in respect of which the application is made is to be brought into Singapore, or transmitted, from an exporting country and the export or transmission of the goods, document or technology from that country or its acquisition or disposal is regulated by that country, the approval from the relevant authority of that
```

### `section:7` · section · Reporting requirements for bulk permit

```text
7.—(1)  A person to whom a bulk permit is granted must submit to a senior authorised officer a report (including a report stating a nil return) containing the information specified in paragraph (2), on the 14th day of each month, or at such other time or interval as required by a senior authorised officer.
(2)  The report shall contain the following information relating to the goods, document or technology that is exported, transhipped or transmitted under the bulk permit during the one month period that immediately precedes the 14th day of each month or such other period specified by a senior authorised officer:
(a) a description of the goods, document or technology;
(b) the value of the go
```

