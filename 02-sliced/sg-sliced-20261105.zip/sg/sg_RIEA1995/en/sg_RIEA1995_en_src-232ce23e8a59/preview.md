# RIEA1995 · 进出口管制法（1995）

- 语言：`en`
- 版本：`sg:RIEA1995:en:src-232ce23e8a59`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：61；切片：67；发布资格：否

PDF 页数 78，空白页 []，目录页 [1, 2, 3, 4]，条文 59。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE REGULATION OF IMPORTS AND EXPORTS ACT 1995 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Regulation of Imports and Exports Act 1995 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 REGULATION AND CONTROL OF IMPORTATION AND EXPORTATION, ETC. 2A. Administration of Act and delegation of powers 3. Regulations for registration, regulation and control of importation and exportation, etc. 4. Inte
```

### `section:1` · section · 

```text
1. This Act is the Regulation of Imports and Exports Act 1995. 3 Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “aircraft” means aircraft of any description which may be used for the conveyance of persons or goods by air; “authentication code” means any identification or identifying code, password or any other authentication method or procedure which has been assigned to a registered user of the computer service mentioned in section 8 for the purpose of identifying and authenticating the access to and use of the computer service by the registered user; “authorised certificate issuer” means a person who is authorised under section 10A(2) to issue trade information certificates;
[Act 26 of 2025 wef 29/09/2026] “authorised officer” means —
(a) a
```

### `section:2A` · section · Administration of Act and delegation of powers

```text
2A.—(1) The Director-General is responsible for the administration of this Act and any regulations made under this Act, subject to the general or special directions of the Minister.
[6/2003]
(2) The Director-General may delegate the exercise of all or any of the powers conferred or duties imposed upon him or her by this Act or any regulations made under this Act to any senior authorised officer or any authorised officer.
[6/2003]
(3) The Minister may appoint any officer or class or description of officers to exercise the powers and perform the duties conferred and imposed on an authorised officer by this Act.
[Act 5 of 2025 wef 09/03/2025]
(4) The Minister may appoint any officer or class or
```

### `section:3` · section · importation and exportation, etc.

```text
3.—(1) The Minister may make regulations for the registration, regulation and control of all or any class of goods imported into, exported from, transhipped in or in transit through Singapore.
[6/2003]
(2) Without limiting subsection (1), the Minister may make regulations —
(a) for prohibiting, absolutely or conditionally, or for regulating, in all cases or in any specified case or class of cases and subject to such exceptions as may be made by the regulations, the import or export or the carriage coastwise or the shipment as ships’ stores or the transhipment or transit of all goods or of goods of any specified class or description;
(b) for imposing on such importers, exporters, agents, forw
```

### `section:4` · section · Interpretation of section 3

```text
4.—(1) Any regulations made under section 3 are, unless the contrary is expressly stated, deemed to be additional to, and not in substitution for, the provisions of any other written law for the time being in force.
(2) To avoid doubt, it is declared that the taking into or out of Singapore of any ship, aircraft or vehicle may be prohibited or regulated by any regulations made under section 3 as an importation or exportation of goods, even though the ship, aircraft or vehicle is conveying goods or passengers, and whether or not it is moving under its own power. Exemption
```

### `section:5` · section · Exemption

```text
5. The Minister may either generally or in any particular case, and either permanently or for any period or periods that he or she may 13 think fit, exempt, subject to any conditions that he or she thinks fit, any person or class of persons, or any conveyance or class of conveyance, or any goods or class of goods from all or any of the provisions of this Act or any regulations made under this Act. Provisions as to issue and cancellation of licences, etc.
```

### `section:6` · section · Provisions as to issue and cancellation of licences, etc.

```text
6.—(1) Where provision is made by any regulations made under section 3 for the issue of any certificate, licence or permit by the Director‑General, the Director‑General may, if he or she thinks fit and subject to any express provision to the contrary contained in the regulations, make provisions —
(a) as to the issue and terms of the certificate, licence or permit and as to the cancellation or suspension thereof at any time;
(b) as to the conditions to be attached to the issue of the certificate, licence or permit and the cancellation or variation from time to time of those conditions; and
(c) for the refund of all or part of any levy or fee paid for the issue of the certificate, licence or 
```

