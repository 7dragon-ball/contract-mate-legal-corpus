# CPTDSRA1975-S113-2011 · 一般消费品安全要求规例 2011

- 语言：`en`
- 版本：`sg:CPTDSRA1975-S113-2011:en:src-5035e9732810`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：15；切片：14；发布资格：否

PDF 页数 5，空白页 []，目录页 []，条文 13。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
First published in the Government Gazette, Electronic Edition, on 1st April 2011 at 0:00 am. No. S 113 CONSUMER PROTECTION (TRADE DESCRIPTIONS AND SAFETY REQUIREMENTS) ACT (CHAPTER 53) CONSUMER PROTECTION (CONSUMER GOODS SAFETY REQUIREMENTS) REGULATIONS 2011 ARRANGEMENT OF REGULATIONS Regulation 1. Citation and commencement 2. Definitions 3. Requirements in case of non-compliance with safety standards 4. Safety standards The Schedule In exercise of the powers conferred by section 11 of the Consumer Protection (Trade Descriptions and Safety Requirements) Act, the Minister for Trade and Industry hereby makes the following Regulations: Citation and commencement
```

### `section:1` · section · 

```text
1. These Regulations may be cited as the Consumer Protection (Consumer Goods Safety Requirements) Regulations 2011 and shall come into operation on 1st April 2011. Definitions
```

### `section:2` · section · Definitions

```text
2.—(1) In these Regulations, unless the context otherwise requires — “Category 1 goods” means any consumer goods for which safety standards have been formulated or adopted and published by any of the following:
(a) the International Organisation for Standardisation (ISO); 1
(b) the International Electrotechnical Commission (IEC);
(c) the European Committee for Standardisation; or
(d) ASTM International; “Category 2 goods” means any consumer goods other than Category 1 goods; “consumer goods” means any goods which are ordinarily supplied for private use or consumption, not being any goods set out in the Schedule, and includes the packaging in which the goods are supplied; “publish” means made
```

### `section:3` · section · Requirements in case of non-compliance with safety standards

```text
3.—(1) If any consumer goods do not conform to the requirements of regulation 4, the Safety Authority may do any or all of the following:
(a) issue a public notice declaring such goods to be unsafe;
(b) direct any person who has, in the course of trade or business, supplied such goods in Singapore on or after 1st April 2011 to take such steps as may be necessary to —
(i) control or cease the supply by that person of such goods in Singapore; and
(ii) inform users of such goods supplied by that person of the potential danger of the goods.
(2) A public notice referred to in paragraph (1)(a) shall be issued by publishing it in at least 4 daily newspapers circulating in Singapore, one each publis
```

### `section:4` · section · Safety standards

```text
4. For the purposes of regulation 3, the requirements shall be as follows:
(a) Category 1 goods shall conform to —
(i) safety standards for such goods formulated or adopted and published by — (A) ISO and IEC, respectively; (B) the European Committee for Standardisation; or (C) ASTM International; and
(ii) the safety standards and requirements for such goods specified by the Safety Authority and published in its Consumer Protection (Consumer Goods Safety Requirements) Information Booklet;
(b) Category 2 goods shall conform to the safety standards for such goods that have been formulated or adopted and published by any regional or national standards body.
```

### `schedule:1` · schedule · THE SCHEDULE

```text
THE SCHEDULE Regulation 2(1) GOODS EXCLUDED FROM DEFINITION OF “CONSUMER GOODS”
```

### `schedule:1/section:1` · section · DEFINITION OF “CONSUMER GOODS”

```text
1. Controlled goods within the meaning of the Consumer Protection (Safety Requirements) Regulations (Rg 1) which are not exempted from those Regulations.
```

### `schedule:1/section:2` · section · Regulations.

```text
2. Used or second-hand goods, provided that before supplying the goods, the supplier has informed clearly the person to whom the goods are supplied that the goods are used or second-hand. 4 THE SCHEDULE — continued
```

