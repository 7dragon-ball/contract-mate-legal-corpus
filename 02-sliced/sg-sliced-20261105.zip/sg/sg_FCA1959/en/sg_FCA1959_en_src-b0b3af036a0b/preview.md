# FCA1959 · 合同受挫法（1959）

- 语言：`en`
- 版本：`sg:FCA1959:en:src-b0b3af036a0b`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：4；切片：3；发布资格：否

PDF 页数 8，空白页 [2]，目录页 [1, 3]，条文 2。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE FRUSTRATED CONTRACTS ACT 1959 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Frustrated Contracts Act 1959 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Adjustment of rights and liabilities of parties to frustrated contracts 3. Provision as to application of Act An Act relating to the frustration of contracts.
[13 February 1959] Short title
1. This Act is the Frustrated Contracts Act 1959. Adjustment of rights and liabilities o
```

### `section:2` · section · 

```text
2.—(1) Where a contract has become impossible of performance or been otherwise frustrated, and the parties to the contract have for that reason been discharged from the further performance of the contract, this section shall, subject to section 3, have effect in relation to that contract.
(2) Subject to subsection (3), all sums paid or payable to any party in pursuance of the contract before the time when the parties were so discharged (referred to in this Act as the time of discharge) shall, in the case of sums so paid, be recoverable from him as money received by him for the use of the party by whom the sums were paid, and, in the case of sums so payable, cease to be so payable.
(3) If the
```

### `section:3` · section · Provision as to application of Act

```text
3.—(1) This Act shall apply to contracts whether made before or after 13 February 1959, as respects which the time of discharge is on or after 1 January 1959, but not to contracts as respects which the time of discharge is before that date.
(2) This Act shall apply to contracts to which the Government is a party in like manner as to contracts between private persons.
(3) Where any contract to which this Act applies contains any provision which, upon the true construction of the contract, is intended to have effect in the event of circumstances arising which operate, or would but for that provision operate, to frustrate the contract, or is intended to have effect whether such circumstances ar
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY FRUSTRATED CONTRACTS ACT 1959 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act.
1. Ordinance 6 of 1959 — Law Reform (Frustrated Contracts) Ordinance, 1959 Bill : 185/1958 First Reading : 3 December 1958 Second and Third Readings : 22 January 1959 Commencement : 13 February 1959
2. L.N. 40/1965 (G.N. Sp. No. S 77/1965) — Modification of Laws (Frustrated Contracts) (Singapore) Order, 1965 Commencement : 18 February 1965
3. 1970 Revised Edition — Frustrated Contracts Act (Chapter 33) Operation : 1 March 1971
4. 1985 Revised Edition — Frustrated Contracts Act (Chapter 115) Operation : 30 March 198
```

