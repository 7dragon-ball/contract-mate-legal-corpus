# GSTA1993 · 商品及服务税法（1993）

- 语言：`en`
- 版本：`sg:GSTA1993:en:src-7c3ca9bd1a2d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：266；切片：301；发布资格：否

PDF 页数 320，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8]，条文 254。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE GOODS AND SERVICES TAX ACT 1993 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Goods and Services Tax Act 1993 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 2A. Digital payment tokens 3. Meaning of “business”, etc. 3A. Meaning of partnership and partner
PART 2 ADMINISTRATION 4. Comptroller and other officers 5. Responsibility of Comptroller and delegation of powers 6. Official secrecy
PART 3 IM
```

### `section:1` · section · 

```text
1. This Act is the Goods and Services Tax Act 1993. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “account with the electronic service”, in relation to any person, means a computer account within the electronic service which is assigned by the Comptroller to that person for the storage and retrieval of electronic records relating to that person; “accountant” means a public accountant within the meaning of the Accountants Act 2004; “advocate and solicitor” means an advocate and solicitor within the meaning of the Legal Profession Act 1966;
[Deleted by Act 33 of 2022 wef 26/04/2024] “authorised person” means any person acting under the authority of the Comptroller; “bare trustee” means a trustee who —
(a) holds any goods, intellec
```

### `section:2A` · section · Digital payment tokens

```text
2A.—(1) Subject to subsections (2) and (3), a reference in this Act to a digital payment token is a reference to a digital representation of value that has all of the following characteristics:
(a) it is expressed as a unit;
(b) it is designed to be fungible;
(c) it is not denominated in any currency, and is not pegged by its issuer to any currency;
(d) it can be transferred, stored or traded electronically;
(e) it is, or is intended to be, a medium of exchange accepted by the public, or a section of the public, without any substantial restrictions on its use as consideration.
[33/2019] 12
(2) A reference in this Act to a digital payment token does not include any of the following:
(a) money
```

### `section:3` · section · Meaning of “business”, etc.

```text
3.—(1) In this Act, “business” includes any trade, profession or vocation.
(2) Without limiting anything else in this Act, the following are deemed to be the carrying on of a business:
(a) the provision by any club, association, society, management corporation or organisation (for a subscription or other consideration) of the facilities or 13 advantages available its members subsidiary proprietors, as the case may be;
(b) the admission, for a consideration, of persons to any premises.
(3) Where a body has objects which are in the public domain and are of a political, religious, philanthropic or patriotic nature, it is not to be treated as carrying on a business only because its members subsc
```

### `section:3A` · section · Meaning of partnership and partner

```text
3A. For the purposes of this Act, except as otherwise provided —
(a) references to partnerships include references to limited partnerships; and
(b) references to partners of a partnership include references to partners of a limited partnership.
[37/2008] 14
PART 2 ADMINISTRATION Comptroller and other officers
```

### `section:4` · section · Comptroller and other officers

```text
4.—(1) For the due administration of this Act, the Minister may appoint a Comptroller of Goods and Services Tax and such Deputy Comptrollers, Assistant Comptrollers and other officers and persons as may be necessary.
[Act 5 of 2025 wef 09/03/2025]
(2) An appointment under subsection (1) must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025] Responsibility of Comptroller and delegation of powers
```

### `section:5` · section · Responsibility of Comptroller and delegation of powers

```text
5.—(1) The Comptroller is responsible generally for the carrying out of the provisions of this Act and for the collection of tax and must pay all amounts collected in respect thereof into the Consolidated Fund.
(2) The Comptroller may, subject to the conditions or restrictions the Comptroller thinks fit, delegate to any public officer or person employed in the administration of this Act all or any of the powers, functions and duties vested in the Comptroller by this Act.
(3) The Comptroller may —
(a) authorise any suitably qualified officer of the Inland Revenue Authority of Singapore charged with duties of investigation to exercise any power in sections 83A, 83E, 83F, 83G, 83H, 83J and 84(1
```

