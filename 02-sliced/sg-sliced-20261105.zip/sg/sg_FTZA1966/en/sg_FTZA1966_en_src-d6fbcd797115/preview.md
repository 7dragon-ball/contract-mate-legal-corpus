# FTZA1966 · 自由贸易区法（1966）

- 语言：`en`
- 版本：`sg:FTZA1966:en:src-d6fbcd797115`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：58；切片：58；发布资格：否

PDF 页数 50，空白页 []，目录页 [1, 2, 3, 4, 5]，条文 56。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE FREE TRADE ZONES ACT 1966 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Free Trade Zones Act 1966 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Declaration of free trade zones 4. Power of Director-General to administer Act, etc.
PART 2 OPERATIONS PERMITTED WITHIN FREE TRADE ZONE 5. Dealing with or disposal of goods in free trade zone 6. Manipulation or manufacture in free trade zone 7. Calc
```

### `section:1` · section · 

```text
1. This Act is the Free Trade Zones Act 1966. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “air cargo agent” means a person who carries on a business that includes handling goods, to be passed to or received from an operator of an aircraft or its representative, for carriage in the aircraft;
[Act 33 of 2023 wef 01/03/2024] “aircraft” means an aircraft of any description which may be used for the conveyance of persons or goods by air;
[Act 33 of 2023 wef 01/03/2024]
[Deleted by Act 33 of 2023 wef 25/11/2024]
[Deleted by Act 33 of 2023 wef 01/03/2024] “conveyance” includes any vessel, train, vehicle or aircraft in which persons or goods can be carried;
[Act 33 of 2023 wef 01/03/2024] 4 “customs duty” means any customs duty or e
```

### `section:3` · section · Declaration of free trade zones

```text
3.—(1) The Minister may, by notification in the Gazette, declare any area in Singapore to be a free trade zone and every such notification shall define the limits of that free trade zone.
[Act 33 of 2023 wef 25/11/2024]
(2) [Deleted by Act 33 of 2023 wef 25/11/2024] Power of Director-General to administer Act, etc.
```

### `section:4` · section · Power of Director-General to administer Act, etc.

```text
4.—(1) The Director-General is responsible for the administration of this Act, subject to the general or special directions of the Minister.
(2) Subject to the general direction and supervision of the Director- General, the Deputy Directors-General of Customs and Assistant Directors-General of Customs appointed under section 4(2) of the Customs Act 1960 have and may exercise all the powers conferred on the Director-General by this Act.
(3) The Director-General may confer on any senior officer of customs appointed under section 4(4) of the Customs Act 1960 all or any of the powers conferred on the Director-General by this Act (except under this subsection), subject to any conditions or restri
```

### `section:5` · section · Dealing with or disposal of goods in free trade zone

```text
5.—(1) Goods of any description, except such as are specifically and absolutely prohibited by any written law, may be brought into a free trade zone.
(2) Goods in a free trade zone may —
(a) be removed from the free trade zone, destroyed, or sent into customs territory or into another free trade zone in the original package or otherwise; and 7
(b) unless otherwise directed by the licensed FTZ operator of the free trade zone, be stored, sold, exhibited, broken up, repacked, assembled, distributed, sorted, graded, cleaned, mixed, or otherwise manipulated, or be manufactured in accordance with the provisions of this Act, except that when any goods of a class dutiable on entry into customs terri
```

### `section:6` · section · Manipulation or manufacture in free trade zone

```text
6.—(1) Any person who intends to do any of the following in a free trade zone must give the Director-General written notice of the intention and obtain the Director-General’s prior written permission to do so:
(a) assemble, mix or otherwise manipulate any goods for entry into customs territory, where any goods or materials used in the assembly, mixing or manipulation are dutiable goods;
(b) manufacture any goods.
[Act 33 of 2023 wef 01/03/2024] 8
(2) Permission under subsection (1) shall be granted or withheld as the Director‑General in his discretion shall think fit.
[Act 33 of 2023 wef 01/03/2024]
(3) Subject to subsection (4), any manipulation or manufacture permitted under this section s
```

### `section:7` · section · Calculation of duty

```text
7.—(1) The rate of customs duty and the valuation, if any, applicable to any goods subject to customs duty shall be —
(a) in the case of goods lawfully brought into or manufactured in a free trade zone —
(i) if there has been no manipulation or manufacture effecting a change in tariff classification, the rate and valuation in force on the day on which the goods are sent into customs territory;
(ii) if the goods are used in the manufacture of any product which is not of a class dutiable on entry into customs territory, the rate and valuation in force on the day on which the goods are removed for manufacture; and
(iii) if the goods are manufactured from materials which are not subject to custo
```

