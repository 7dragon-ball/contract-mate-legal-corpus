# DIPOPSA2011 · 存款保险和保单持有人保护计划法 2011

- 语言：`en`
- 版本：`sg:DIPOPSA2011:en:src-1a28f3a02c80`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：149；切片：155；发布资格：否

PDF 页数 139，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7]，条文 140。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE DEPOSIT INSURANCE AND POLICY OWNERS’ PROTECTION SCHEMES ACT 2011 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Deposit Insurance and Policy Owners’ Protection Schemes Act 2011 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. General interpretation 3. Meanings of “insured deposit base” and “relevant insured deposits”
PART 2 DEPOSIT INSURANCE SCHEME 4. Reconstitution of Deposit Insurance Scheme 5. Membership of D
```

### `section:1` · section · 

```text
1. This Act is the Deposit Insurance and Policy Owners’ Protection Schemes Act 2011. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “accident and health policy” has the meaning given in the First Schedule to the Insurance Act 1966; “account with the electronic service”, in relation to any person, means a computer account within the electronic service which is assigned by the Authority to that person for the storage and retrieval of electronic records relating to that person; “Agency” means the company designated by the Minister under section 56 to be the deposit insurance and policy owners’ protection fund agency; 6 “authentication code”, in relation to any person, means an identification or identifying code, a password or any other authentication method or proc
```

### `section:3` · section · deposits”

```text
3.—(1) In this Act, unless the context otherwise requires, “insured deposit base”, in relation to a DI Scheme member, means the aggregate of the amount of every relevant insured deposit of all the insured depositors of the DI Scheme member.
(2) In subsection (1), “relevant insured deposits”, in relation to an insured depositor of a DI Scheme member, means —
(a) the aggregate of the amounts, not exceeding the Maximum DI Coverage, of insured deposits placed with the DI Scheme member which —
(i) are held by that insured depositor in the insured depositor’s own right;
(ii) are held by that insured depositor in the insured depositor’s own right jointly with one or more persons in a joint account;
```

### `section:4` · section · Reconstitution of Deposit Insurance Scheme

```text
4. For the purposes of this Act, the Deposit Insurance Scheme continues and is reconstituted in accordance with this Act for the 20 benefit of insured depositors in respect of their insured deposits placed with DI Scheme members. Membership of DI Scheme
```

### `section:5` · section · Membership of DI Scheme

```text
5.—(1) Every full bank or finance company which is not exempted under section 6 is a DI Scheme member so long as it holds a valid licence under the Banking Act 1970 or the Finance Companies Act 1967, as the case may be.
(2) Every full bank or finance company, which holds a valid licence under the Banking Act 1970 or the Finance Companies Act 1967 (as the case may be) immediately before 1 May 2011, is deemed to be a DI Scheme member from that date.
(3) Every full bank or finance company, which is granted a licence under the Banking Act 1970 or the Finance Companies Act 1967 (as the case may be) on or after 1 May 2011, is a DI Scheme member from the date on which its licence is granted. Exempt
```

### `section:6` · section · Exemption from DI Scheme membership

```text
6.—(1) Any full bank or finance company may apply in writing to the Authority to be exempted from the requirement under section 5(1) to be a DI Scheme member.
(2) Upon an application by a full bank or finance company under subsection (1), the Authority may, subject to subsection (4), exempt the full bank or finance company from the requirement under section 5(1), and notice of every such exemption must be published in the Gazette.
(3) The Authority may require the applicant to provide the Authority with such information or documents as the Authority considers necessary in relation to the application.
(4) Without limiting subsection (2), the Authority must, in determining whether to grant an 
```

### `section:7` · section · Withdrawal of exemption from DI Scheme

```text
7.—(1) The Authority may withdraw the exemption granted to a DI exempt member under section 6(2) if —
(a) the DI exempt member fails to comply with any condition or restriction imposed in respect of the exemption under section 6(5) or (6); or
(b) the Authority considers it necessary to do so in the public interest.
(2) Before withdrawing any exemption under subsection (1), the Authority must —
(a) give the DI exempt member written notice of its intention to do so; and
(b) in the notice referred to in paragraph (a), call upon the DI exempt member to show cause, within such time as may be specified in the notice, why the exemption should not be withdrawn.
(3) If the DI exempt member to whom a 
```

