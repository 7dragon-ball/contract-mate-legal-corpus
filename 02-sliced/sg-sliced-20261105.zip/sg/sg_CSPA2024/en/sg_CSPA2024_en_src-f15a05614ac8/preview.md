# CSPA2024 · 企业服务提供商法 2024

- 语言：`en`
- 版本：`sg:CSPA2024:en:src-f15a05614ac8`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：48；切片：48；发布资格：否

PDF 页数 59，空白页 []，目录页 [1, 2, 3, 4, 5, 6]，条文 47。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
CORPORATE SERVICE PROVIDERS ACT 2024 (No. 22 of 2024) ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. General interpretation 3. Meaning of “accounting service”, etc. 4. Purpose of Act 5. Administration of Act and appointment of Registrar of Corporate Service Providers, etc. 6. Registers
PART 2 REGULATION OF PROVISION OF CORPORATE SERVICES
Division 1 — Provision of corporate services 7. No carrying on business of providing corporate services without registration
Division 2 — Registration of corporate service providers 8. Registration and renewal of registration of corporate service providers 9. Criteria for registration or renewal of registration of corpo
```

### `section:1` · section · 

```text
1. This Act is the Corporate Service Providers Act 2024 and comes into operation on a date that the Minister appoints by notification in the Gazette. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act — “accounting corporation”, “accounting firm” and “accounting limited liability partnership” have the meanings given by section 2(1) of the Accountants Act 2004; “accounting entity” means —
(a) an accounting corporation;
(b) an accounting firm;
(c) an accounting limited liability partnership; or
(d) a public accountant who is registered under section 8 of the Business Names Registration Act 2014 as the sole proprietor of a business in providing public accountancy services; “ACRA Act” means the Accounting and Corporate Regulatory Authority Act 2004; “ACRA Fifth Schedule Act” means any of the written laws specified in the first column of the Fifth Schedule to the ACRA Act; “
```

### `section:3` · section · Meaning of “accounting service”, etc.

```text
3.—(1) In this Act — “accounting service” means any of the following services:
(a) financial accounting service;
(b) internal audit service;
(c) management accounting service;
(d) taxation service; “financial accounting service” means any of the following services:
(a) preparing and maintaining accounting and other records of an entity which will sufficiently explain the transactions and financial position of the entity and enable true and fair profit and loss accounts and balance sheets (and any documents attached to the profit and loss accounts and balance sheets) to be prepared from time to time; 12
(b) preparing the general purpose financial statements, special purpose financial statemen
```

### `section:4` · section · Purpose of Act

```text
4. The purpose of this Act is to regulate corporate service providers, and qualified individuals who provide, or supervise the provision of, corporate services, and to impose requirements on those persons so as to detect or prevent money laundering, proliferation financing and terrorism financing. Administration of Act and appointment of Registrar of Corporate Service Providers, etc.
```

### `section:5` · section · Corporate Service Providers, etc.

```text
5.—(1) The Authority is responsible for the administration of this Act, subject to the general or special directions of the Minister.
(2) The Minister may, after consultation with the Authority, and for the proper administration of this Act —
(a) appoint an officer of the Authority to be the Registrar of Corporate Service Providers; and 14
(b) from among the officers of the Authority, public officers and officers of any other statutory board, appoint any number of Deputy Registrars and Assistant Registrars of Corporate Service Providers as the Minister considers necessary.
(3) The Authority may give to the Registrar such directions, not inconsistent with the provisions of this Act, as to the
```

### `section:6` · section · Registers

```text
6. The Registrar must keep and maintain —
(a) a register of registered corporate service providers; and
(b) a register of registered qualified individuals. 15
PART 2 REGULATION OF PROVISION OF CORPORATE SERVICES
Division 1 — Provision of corporate services No carrying on business of providing corporate services without registration
```

### `section:7` · section · without registration

```text
7.—(1) A person must not carry on a business in Singapore of providing any corporate service unless the person is a registered corporate service provider for that type of corporate service.
(2) An accounting entity that carries on a business in Singapore of the corporate service of carrying out any designated activity in relation to the provision of any accounting service by the accounting entity, is treated as registered under section 8 as a registered corporate service provider for that type of corporate service for the purposes of this Act, and continues to be so treated until the accounting entity’s deemed registration is suspended or cancelled under section 18(2) or 19(2) or (3).
(3) De
```

