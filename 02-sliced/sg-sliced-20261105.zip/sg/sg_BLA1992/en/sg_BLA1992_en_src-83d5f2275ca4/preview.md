# BLA1992 · 提单法（1992）

- 语言：`en`
- 版本：`sg:BLA1992:en:src-83d5f2275ca4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：8；切片：7；发布资格：否

PDF 页数 11，空白页 [2]，目录页 [1, 3]，条文 6。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE BILLS OF LADING ACT 1992 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Bills of Lading Act 1992 ARRANGEMENT OF SECTIONS Section 1. Shipping documents, etc., to which Act applies 2. Rights under shipping documents 3. Liabilities under shipping documents 4. Representations in bills of lading 5. Interpretation 6. Short title An Act to replace the Bills of Lading Act 1855 with new provision with respect to bills of lading and certain 
```

### `section:1` · section · 

```text
1.—(1) This Act applies to the following documents:
(a) any bill of lading;
(b) any sea waybill;
(c) any ship’s delivery order.
(2) References in this Act to a bill of lading —
(a) do not include references to a document which is incapable of transfer either by indorsement or, as a bearer bill, by delivery without indorsement; but
(b) subject to that, do include references to a received for shipment bill of lading.
(3) References in this Act to a sea waybill are references to any document which is not a bill of lading but —
(a) is such a receipt for goods as contains or evidences a contract for the carriage of goods by sea; and 1
(b) identifies the person to whom delivery of the goods is to 
```

### `section:2` · section · Rights under shipping documents

```text
2.—(1) Subject to the following provisions of this section, a person who becomes —
(a) the lawful holder of a bill of lading;
(b) the person who (without being an original party to the contract of carriage) is the person to whom delivery of the goods to which a sea waybill relates is to be made by the carrier in accordance with that contract; or
(c) the person to whom delivery of the goods to which a ship’s delivery order relates is to be made in accordance with the undertaking contained in the order, shall (by virtue of becoming the holder of the bill or, as the case may be, the person to whom delivery is to be made) have transferred to and vested in him all rights of suit under the contrac
```

### `section:3` · section · Liabilities under shipping documents

```text
3.—(1) Where section 2(1) operates in relation to any document to which this Act applies and the person in whom rights are vested by virtue of that subsection —
(a) takes or demands delivery from the carrier of any of the goods to which the document relates;
(b) makes a claim under the contract of carriage against the carrier in respect of any of those goods; or
(c) is a person who, at a time before those rights were vested in him, took or demanded delivery from the carrier of any of those goods, that person shall (by virtue of taking or demanding delivery or making the claim or, in a case falling within paragraph (c), of having the rights vested in him) become subject to the same liabilitie
```

### `section:4` · section · Representations in bills of lading

```text
4. A bill of lading which —
(a) represents goods to have been shipped on board a vessel or to have been received for shipment on board a vessel; and
(b) has been signed by the master of the vessel or by a person who was not the master but had the express, implied or apparent authority of the carrier to sign bills of lading, shall, in favour of a person who has become the lawful holder of the bill, be conclusive evidence against the carrier of the shipment of the goods or, as the case may be, of their receipt for shipment. Interpretation
```

### `section:5` · section · Interpretation

```text
5.—(1) In this Act — “bill of lading”, “sea waybill” and “ship’s delivery order” shall be construed in accordance with section 1; “the contract of carriage” —
(a) in relation to a bill of lading or sea waybill, means the contract contained in or evidenced by that bill or waybill; and
(b) in relation to a ship’s delivery order, means the contract under or for the purposes of which the undertaking contained in the order is given; “holder”, in relation to a bill of lading, shall be construed in accordance with subsection (2).
[43/99; 5/2021]
(2) References in this Act to the holder of a bill of lading are references to any of the following persons:
(a) a person with possession of the bill who, 
```

### `section:6` · section · Short title

```text
6. This Act may be cited as the Bills of Lading Act 1992. 6
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY BILLS OF LADING ACT 1992 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act.
1. U.K. 1992, c. 50 — Carriage of Goods by Sea Act 1992 Commencement : 16 September 1992 Application : 12 November 1993 Note: This Act (subject to the amendments in the First Schedule to the Application of English Law Act 1993) was declared by the Application of English Law Act 1993 to apply or continue to apply in Singapore on 12 November 1993.
2. 1994 Revised Edition — Bills of Lading Act (Chapter 384) Operation : 20 May 1994 Note: The Carriage of Goods by Sea Act 1992 was renamed as the Bills of Lading Act in the 199
```

