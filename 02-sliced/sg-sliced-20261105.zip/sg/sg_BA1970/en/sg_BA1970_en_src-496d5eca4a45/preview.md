# BA1970 · 银行法 1970

- 语言：`en`
- 版本：`sg:BA1970:en:src-496d5eca4a45`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：213；切片：235；发布资格：否

PDF 页数 257，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9]，条文 206。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE BANKING ACT 1970 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Banking Act 1970 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 APPOINTMENT OF ASSISTANTS 3. Appointment of assistants
PART 3 LICENSING OF BANKS 4. Licensing of banks 4A. Restriction on deposit-taking business and soliciting deposits 4B. Application of section 4A 4C. Examination of persons suspected of contravening section 4A
```

### `section:1` · section · 

```text
1. This Act is the Banking Act 1970. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “agreement” means an agreement whether formal or informal and whether express or implied; “Authority” means the Monetary Authority of Singapore established under the Monetary Authority of Singapore Act 1970; “bank” means any company which holds a valid bank licence under section 7 or 79; “bank in Singapore” means —
(a) a bank incorporated in Singapore; or
(b) in the case of a bank incorporated outside Singapore, the branches and offices of the bank located within Singapore; “bank incorporated outside Singapore” means a bank incorporated, formed or established outside Singapore; “banking business” means the business of receiving mone
```

### `section:3` · section · Appointment of assistants

```text
3.—(1) Subject to subsection (1A), the Authority may appoint any person to exercise any of its powers or perform any of its functions or duties under this Act, either generally or in any particular case, except the power to make subsidiary legislation.
(1A) The Authority may appoint one or more of its officers to exercise the power to grant an exemption to any person (not being an exemption granted to a class of persons) under a provision of this Act specified in the Fourth Schedule, or to revoke any such exemption.
[Act 5 of 2025 wef 09/03/2025]
(1B) An appointment under subsection (1A) must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025]
(2) Any person appointed by the Authorit
```

### `section:4` · section · Licensing of banks

```text
4.—(1) Subject to section 55S, a banking business must not be transacted in Singapore except by a company which is in possession of a valid bank licence granted under this Act by the Authority authorising it to conduct banking business in Singapore.
[1/2020] 15
(2) Any person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction —
(a) in the case of an individual, to a fine not exceeding $125,000 or to imprisonment for a term not exceeding 3 years or to both and, in the case of a continuing offence, to a further fine not exceeding $12,500 for every day or part of a day during which the offence continues after conviction; or
(b) in any other case, to a
```

### `section:4A` · section · Restriction on deposit-taking business and soliciting deposi

```text
4A.—(1) Subject to subsection (6), a person must not, in the course of carrying on (whether in Singapore or elsewhere) a deposit‑taking business, accept in Singapore any deposit from any person in Singapore.
(2) A person must not, whether in Singapore or elsewhere, offer or invite or issue any advertisement containing any offer or invitation to the public or any section of the public in Singapore —
(a) to make any deposit, whether in Singapore or elsewhere; or
(b) to enter or offer to enter into any agreement to make any deposit, whether in Singapore or elsewhere, where such deposit is to be made with any person (not being a person specified in subsection (6)) in the course of the carrying o
```

### `section:4B` · section · Application of section 4A

```text
4B.—(1) In section 4A, “advertisement” means the dissemination or conveyance of information, or invitation or solicitation by any means or in any form, including by means of —
(a) publication in a newspaper, magazine, journal or other periodical;
(b) display of posters or notices;
(c) circulars, handbills, brochures, pamphlets, books or other documents;
(d) letters addressed to individuals or bodies;
(e) photographs or cinematograph films; or
(f) sound broadcasting, television, the Internet or other media.
(2) An advertisement containing information which is intended or might reasonably be presumed to be intended to lead, directly or indirectly, to the making of a deposit is to be treated as
```

### `section:4C` · section · and access to premises

```text
4C.—(1) Whenever the Authority has reason to believe that a person has contravened or is contravening section 4A(1) or (2), the Authority, at all times —
(a) has full and free access to the premises at which that person is suspected of having committed or of committing the contravention, or at which that person may have books; and
(b) has the power to examine, copy or take possession of the books of that person in order to ascertain whether or not that person has contravened or is contravening section 4A(1) or (2).
(2) Any person who obstructs the Authority in the exercise of its powers under subsection (1) or, without reasonable excuse, fails to provide such books in the person’s possession
```

