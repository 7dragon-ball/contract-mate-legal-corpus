# CLA1909 · 民事法律法（1909）

- 语言：`en`
- 版本：`sg:CLA1909:en:src-a1de32ca6393`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：47；切片：53；发布资格：否

PDF 页数 60，空白页 []，目录页 [1, 2, 3]，条文 44。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CIVIL LAW ACT 1909 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Civil Law Act 1909 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Law and equity to be administered concurrently 4. Administration of insolvent estates, and winding up of companies. Bankruptcy rules to prevail 5. Agreement by way of gaming or wagering to be null and void 5A. Abolition of tort of maintenance and champerty 5B. Validity of certain c
```

### `section:1` · section · 

```text
1. This Act is the Civil Law Act 1909. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “court” means the General Division of the High Court; “executor” means the executor or administrator of a deceased person, and includes, as regards any obligation, any person who takes possession of or intermeddles with the property of a deceased person; “will” includes a codicil.
[40/2019] 2 Law and equity to be administered concurrently
```

### `section:3` · section · Law and equity to be administered concurrently

```text
3. In every civil cause or matter commenced in the court, law and equity shall be administered by the court in its original jurisdiction and by the Appellate Division of the High Court or the Court of Appeal according to the rules following: Claimants to have equitable relief in claims
(a) if any claimant claims to be entitled to any equitable estate or right, or to relief upon any equitable ground against any deed, instrument or contract, or against any right, title or claim whatsoever asserted by any defendant in such cause or matter, or to any relief founded upon a legal right, which before 1 January 1879 could only have been given by the court on its equity side, the court shall give to 
```

### `section:4` · section · companies. Bankruptcy rules to prevail

```text
4.—(1) In the administration by any court of the assets of any deceased person whose estate proves to be insufficient for the payment in full of his debts and liabilities, and in the winding up of any company under the Insolvency, Restructuring and Dissolution Act 2018 whose assets prove to be insufficient for the payment of its debts and liabilities and the costs of winding up, the same rules shall prevail and be observed as to the respective rights of secured and unsecured creditors, and as to debts and liabilities provable, and as to the valuation of annuities and future and contingent liabilities respectively, as are in force for the time being under the law of bankruptcy with respect to
```

### `section:5` · section · Agreement by way of gaming or wagering to be null and void

```text
5.—(1) All contracts or agreements, whether by parol or in writing, by way of gaming or wagering shall be null and void.
(2) No action shall be brought or maintained in the court for recovering any sum of money or valuable thing alleged to be won upon any wager or which has been deposited in the hands of any person to abide the event on which any wager has been made.
(3) Subsections (1) and (2) shall not be deemed to apply to any subscription or contribution, or agreement to subscribe or contribute, for or toward any plate, prize or sum of money to be awarded to the winner or winners of any lawful game, sport, pastime or exercise.
(3A) Subsections (1) and (2) shall not apply to —
(a) a contr
```

### `section:5A` · section · Abolition of tort of maintenance and champerty

```text
5A.—(1) It is declared that no person is, under the law of Singapore, liable in tort for any conduct on account of its being maintenance or champerty as known to the common law.
[2/2017]
(2) Subject to section 5B, the abolition of civil liability under the law of Singapore for maintenance and champerty does not affect any 14 rule of that law as to the cases in which a contract is to be treated as contrary to public policy or otherwise illegal.
[2/2017] Validity of certain contracts for funding of claims
```

### `section:5B` · section · Validity of certain contracts for funding of claims

```text
5B.—(1) This section applies only in relation to prescribed dispute resolution proceedings.
[2/2017]
(2) A contract under which a qualifying Third‑Party Funder provides funds to any party for the purpose of funding all or part of the costs of that party in prescribed dispute resolution proceedings is not contrary to public policy or otherwise illegal by reason that it is a contract for maintenance or champerty.
[2/2017]
(3) Every qualifying Third‑Party Funder and funded party must, in relation to a third‑party funding contract, comply with and ensure that such requirements as may be prescribed under subsection (8) are complied with.
[2/2017]
(4) Where a Third‑Party Funder —
(a) ceases to be 
```

