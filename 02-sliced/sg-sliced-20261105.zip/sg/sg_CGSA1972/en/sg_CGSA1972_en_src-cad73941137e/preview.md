# CGSA1972 · 海上货物运输法（1972）

- 语言：`en`
- 版本：`sg:CGSA1972:en:src-cad73941137e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：27；切片：26；发布资格：否

PDF 页数 16，空白页 [2]，目录页 [1, 3]，条文 24。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CARRIAGE OF GOODS BY SEA ACT 1972 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Carriage of Goods by Sea Act 1972 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Definition 3. Application of Rules 4. Absolute warranty of seaworthiness not to be implied in contracts to which Rules apply 5. Modification of paragraphs 4 and 5 of Article III of Rules in relation to bulk cargoes 6. Saving and operation of other written law The Schedu
```

### `section:1` · section · 

```text
1. This Act is the Carriage of Goods by Sea Act 1972. Definition
```

### `section:2` · section · Definition

```text
2. In this Act, “Rules” means the International Convention for the unification of certain rules of law relating to bills of lading made at Brussels on 25 August 1924, as amended by the Protocol made at Brussels on 23 February 1968, and as set out in the Schedule. Application of Rules
```

### `section:3` · section · Application of Rules

```text
3.—(1) The provisions of the Rules, as set out in the Schedule to this Act, have the force of law. 1
(2) Without affecting subsection (1), the provisions of the Rules also have effect (and have the force of law) in relation to and in connection with the carriage of goods by sea in ships where the port of shipment is a port in Singapore, whether or not the carriage is between ports in 2 different States within the meaning of Article X of the Rules.
(3) Subject to subsection (4), nothing in this section is to be construed as applying anything in the Rules to any contract for the carriage of goods by sea, unless the contract expressly or by implication provides for the issue of a bill of lading
```

### `section:4` · section · contracts to which Rules apply

```text
4. There shall not be implied in any contract for the carriage of goods by sea to which the Rules apply any absolute undertaking by the carrier of the goods to provide a seaworthy ship. Modification of paragraphs 4 and 5 of Article III of Rules in relation to bulk cargoes
```

### `section:5` · section · relation to bulk cargoes

```text
5. Where under the custom of any trade the weight of any bulk cargo inserted in the bill of lading is a weight ascertained or accepted by a third party other than the carrier or the shipper and the fact that the weight is so ascertained or accepted is stated in the bill of lading, then, despite anything in the Rules, the bill of lading is not to be deemed to be prima facie evidence against the carrier of the receipt of goods of the weight so inserted in the bill of lading, and the accuracy thereof at the time of shipment is not to be deemed to have been guaranteed by the shipper. Saving and operation of other written law
```

### `section:6` · section · Saving and operation of other written law

```text
6. Nothing in this Act affects the operation of sections 135 and 136 of the Merchant Shipping Act 1995 as amended by any subsequent Act, or the operation of any other enactment for the time being in force limiting the liability of the owners of sea-going vessels. 3
```

### `schedule:1` · schedule · THE SCHEDULE

```text
THE SCHEDULE Sections 2 and 3(1) THE HAGUE RULES AS AMENDED BY THE BRUSSELS PROTOCOL 1968 ARTICLE I In these Rules the following words are employed, with the meanings set out below:
(a) “Carrier” includes the owner or the charterer who enters into a contract of carriage with a shipper.
(b) “Contract of carriage” applies only to contracts of carriage covered by a bill of lading or any similar document of title, in so far as such document relates to the carriage of goods by sea, including any bill of lading or any similar document as aforesaid issued under or pursuant to a charter party from the moment at which such bill of lading or similar document of title regulates the relations between a 
```

