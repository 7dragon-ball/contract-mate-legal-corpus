# MIA1906 · 海上保险法（1906）

- 语言：`en`
- 版本：`sg:MIA1906:en:src-a9851f4b27a3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：112；切片：111；发布资格：否

PDF 页数 43，空白页 [2]，目录页 [1, 3, 4, 5, 6]，条文 109。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE MARINE INSURANCE ACT 1906 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Marine Insurance Act 1906 ARRANGEMENT OF SECTIONS Marine Insurance Section 1. Marine insurance defined 2. Mixed sea and land risks 3. Marine adventure and maritime perils defined Insurable Interest 4. Avoidance of wagering or gaming contracts 5. Insurable interest defined 6. When interest must attach 7. Defeasible or contingent interest 8. Partial interest 9. 
```

### `section:1` · section · 

```text
1. A contract of marine insurance is a contract whereby the insurer undertakes to indemnify the assured in manner and to the extent thereby agreed, against marine losses, that is to say, the losses incident to marine adventure. Mixed sea and land risks
```

### `section:2` · section · Mixed sea and land risks

```text
2.—(1) A contract of marine insurance may, by its express terms, or by usage of trade, be extended so as to protect the assured against losses on inland waters or on any land risk which may be incidental to any sea voyage. 4
(2) Where a ship in course of building, or the launch of a ship, or any adventure analogous to a marine adventure, is covered by a policy in the form of a marine policy, the provisions of this Act, in so far as applicable, shall apply thereto; but, except as by this section provided, nothing in this Act shall alter or affect any rule of law applicable to any contract of insurance other than a contract of marine insurance as by this Act defined. Marine adventure and marit
```

### `section:3` · section · Marine adventure and maritime perils defined

```text
3.—(1) Subject to the provisions of this Act, every lawful marine adventure may be the subject of a contract of marine insurance.
(2) In particular there is a marine adventure where —
(a) any ship goods or other movables are exposed to maritime perils, and such property is in this Act referred to as “insurable property”;
(b) the earning or acquisition of any freight, passage money, commission, profit, or other pecuniary benefit, or the security for any advances, loan, or disbursements, is endangered by the exposure of insurable property to maritime perils;
(c) any liability to a third party may be incurred by the owner of, or other person interested in or responsible for, insurable property,
```

### `section:4` · section · Avoidance of wagering or gaming contracts

```text
4.—(1) Every contract of marine insurance by way of gaming or wagering is void. 5
(2) A contract of marine insurance is deemed to be a gaming or wagering contract —
(a) where the assured has not an insurable interest as defined by this Act, and the contract is entered into with no expectation of acquiring such an interest; or
(b) where the policy is made “interest or no interest”, or “without further proof of interest than the policy itself”, or “without benefit of salvage to the insurer”, or subject to any other like term: Provided that, where there is no possibility of salvage, a policy may be effected without benefit of salvage to the insurer. Insurable interest defined
```

### `section:5` · section · Insurable interest defined

```text
5.—(1) Subject to the provisions of this Act, every person has an insurable interest who is interested in a marine adventure.
(2) In particular a person is interested in a marine adventure where he stands in any legal or equitable relation to the adventure or to any insurable property at risk therein, in consequence of which he may benefit by the safety or due arrival of insurable property, or may be prejudiced by its loss, or by damage thereto, or by the detention thereof, or may incur liability in respect thereof. When interest must attach
```

### `section:6` · section · When interest must attach

```text
6.—(1) The assured must be interested in the subject-matter insured at the time of the loss though he need not be interested when the insurance is effected: Provided that where the subject-matter is insured “lost or not lost”, the assured may recover although he may not have acquired his interest until after the loss, unless at the time of effecting the contract of insurance the assured was aware of the loss, and the insurer was not.
(2) Where the assured has no interest at the time of the loss, he cannot acquire interest by any act or election after he is aware of the loss. 6 Defeasible or contingent interest
```

### `section:7` · section · Defeasible or contingent interest

```text
7.—(1) A defeasible interest is insurable, as also is a contingent interest.
(2) In particular, where the buyer of goods has insured them, he has an insurable interest, notwithstanding that he might, at his election, have rejected the goods, or have treated them as at the seller’s risk, by reason of the latter’s delay in making delivery or otherwise. Partial interest
```

