# LA1959 · 时效法（1959）

- 语言：`en`
- 版本：`sg:LA1959:en:src-9c0a0a8a54eb`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：40；切片：40；发布资格：否

PDF 页数 32，空白页 []，目录页 [1, 2, 3, 4]，条文 38。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE LIMITATION ACT 1959 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Limitation Act 1959 ARRANGEMENT OF SECTIONS
PART 1 Section 1. Short title 2. Interpretation 3. Saving for other limitation laws 4. Limitation not to operate as a bar unless specially pleaded
PART 2 5.
Part 2 to be subject to Part 3 Action of contract and tort and certain other actions 6. Limitation of actions of contract and tort and certain other actions 6A. Specia
```

### `section:2` · section · 

```text
2.—(1) In this Act, unless the context otherwise requires — “action” includes a suit or any other proceedings in a court; “land” includes things attached to the earth or permanently fastened to anything attached to the earth, rentcharges and any legal or equitable estate or interest in land (including an interest in the proceeds of the sale of land held upon trust for sale) but does not include any right of way, easement, servitude, profit over or in respect of land, or right in the nature of an easement, servitude or profit over or in respect of land, or any other incorporeal hereditament; “personal estate” and “personal property” do not include land or chattels real; “personal injuries” in
```

### `section:3` · section · Saving for other limitation laws

```text
3. This Act shall not apply to any action or arbitration for which a period of limitation is prescribed by any other written law or to any action or arbitration to which the Government is a party and for which if it were between private persons a period of limitation would have been prescribed by any other written law. 4 Limitation not to operate as a bar unless specially pleaded
```

### `section:4` · section · Limitation not to operate as a bar unless specially pleaded

```text
4. Nothing in this Act shall operate as a bar to an action unless this Act has been expressly pleaded as a defence thereto in any case where under any written law relating to civil procedure for the time being in force such a defence is required to be so pleaded.
PART 2
Part 2 to be subject to Part 3
```

### `section:5` · section · Part 2 to be subject to Part 3

```text
5. The provisions of this Part shall have effect subject to the provisions of Part 3. Action of contract and tort and certain other actions Limitation of actions of contract and tort and certain other actions
```

### `section:6` · section · actions

```text
6.—(1) Subject to this Act, the following actions shall not be brought after the expiration of 6 years from the date on which the cause of action accrued:
(a) actions founded on a contract or on tort;
(b) actions to enforce a recognizance;
(c) actions to enforce an award;
(d) actions to recover any sum recoverable by virtue of any written law other than a penalty or forfeiture or sum by way of penalty or forfeiture.
(2) An action for an account shall not be brought in respect of any matter which arose more than 6 years before the commencement of the action.
(3) An action upon any judgment shall not be brought after the expiration of 12 years from the date on which the judgment became enforce
```

### `section:6A` · section · Special time limit for claiming contribution

```text
6A.—(1) Where under section 15 of the Civil Law Act 1909 any person becomes entitled to a right to recover contribution in respect of any damage from any other person, no action to recover contribution by virtue of that right shall, subject to subsection (3), be brought after the end of the period of 2 years from the date on which that right accrued.
[45/98; 2/2012]
(2) For the purposes of this section, the date on which a right to recover contribution in respect of any damage accrues to any person (referred to in this section as the relevant date) shall be ascertained as provided in subsections (3) and (5).
[45/98]
(3) If the person in question is held liable in respect of that damage —
(a)
```

### `section:7` · section · title of owner of converted goods

```text
7.—(1) Where any cause of action in respect of the conversion or wrongful detention of a chattel has accrued to any person and before he recovers possession of the chattel, a further conversion or wrongful detention takes place, no action shall be brought in respect of the further conversion or detention after the expiration of 6 years from the accrual of the cause of action in respect of the original conversion or detention.
(2) Where any such cause of action has accrued to any person and the period prescribed for bringing that action and for bringing any action in respect of such a further conversion or wrongful detention under subsection (1) has expired and he has not during that period r
```

