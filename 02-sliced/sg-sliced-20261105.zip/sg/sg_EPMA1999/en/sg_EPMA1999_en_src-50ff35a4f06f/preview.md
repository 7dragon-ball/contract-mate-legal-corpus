# EPMA1999 · 环境保护与管理法 1999

- 语言：`en`
- 版本：`sg:EPMA1999:en:src-50ff35a4f06f`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：165；切片：182；发布资格：否

PDF 页数 181，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8]，条文 160。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ENVIRONMENTAL PROTECTION AND MANAGEMENT ACT 1999 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Environmental Protection and Management Act 1999 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 ADMINISTRATION 3. Appointment of Director-General and authorised officers 4. Public servants 5. Protection from personal liability
PART 3 USE OF SCHEDULED PREMISES 6. Written permission for use of sc
```

### `section:1` · section · 

```text
1. This Act is the Environmental Protection and Management Act 1999.
[26/2007] Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “Agency” means the National Environment Agency established under the National Environment Agency Act 2002; “air impurities” includes smoke, cinders, solid particles of any kind, gases, fumes, mists, odours and radioactive substances; “air pollution” means the emission into the air of any air impurity; “air pollution control equipment” includes —
(a) any apparatus for separating any air impurities from the gas or liquid medium in which they are carried;
(b) any automatic device used for securing the more efficient operation of any fuel burning equipment;
(c) any device to indicate or record air pollution or give warning of excessive air 
```

### `section:3` · section · Appointment of Director-General and authorised officers

```text
3.—(1) The Minister may appoint any person to be the Director‑General of Environmental Protection who is to be responsible for the administration of this Act and any other written law, subject to the general or special directions of the Minister.
[Act 5 of 2025 wef 09/03/2025]
(1A) An appointment under subsection (1) must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025]
(2) The Director-General may in writing appoint any of the following persons to be an authorised officer for the purposes of this Act:
(a) a public officer;
(b) an officer or auxiliary officer of the Agency;
(c) an officer of any statutory authority;
(d) a member or an employee of any Town Council;
(e) an auxiliary
```

### `section:4` · section · Public servants

```text
4. Any authorised officer who is generally or specially authorised under section 3(2) to perform or exercise all or any of the functions, duties or powers which are imposed or conferred by this Act upon the Director‑General is deemed to be a public servant for the purposes of the Penal Code 1871. Protection from personal liability
```

### `section:5` · section · Protection from personal liability

```text
5.—(1) No liability shall lie against any authorised officer by reason of the fact that —
(a) any works are carried out in accordance with the provisions of this Act; or
(b) such works or plans of the works are subject to inspection, approval or certification by the Director‑General or an authorised officer.
[12/2011]
(2) Nothing in this Act makes it obligatory for the Director‑General or any authorised officer to inspect any building or works or the site of any proposed works to ascertain whether the provisions of this Act are complied with or whether any plans, certificates, reports, notices or other documents submitted to him or her are accurate.
(3) No matter or thing done by the Directo
```

### `section:6` · section · Written permission for use of scheduled premises

```text
6.—(1) A person must not occupy or use any scheduled premises specified in the First Schedule without a written permission granted by the Director‑General.
[12/2011]
(2) Any person who contravenes subsection (1) shall be guilty of an offence.
(3) Any application for a written permission under this section must be made to the Director‑General giving details of the following:
(a) the trade, industry or process proposed to be carried on in or on the premises;
(b) the measures the applicant undertakes to adopt to control air, water and noise pollution from the premises;
(c) the measures the applicant undertakes to adopt to manage hazardous substances and to treat and dispose of toxic substances 
```

### `section:7` · section · permission

```text
7.—(1) Without limiting section 32, the Director‑General may, in granting a written permission under section 6, impose conditions to ensure that pollution of the environment, as well as hazardous substances, are adequately managed and controlled, including but not limited to the following conditions: 16
(a) requiring the owner or occupier —
(i) to install and operate an industrial plant, fuel burning equipment, control equipment or treatment plant in or on the scheduled premises;
(ii) to repair, alter or replace any industrial plant, fuel burning equipment, control equipment or treatment plant installed in or on the scheduled premises;
(iii) to erect or alter the height or dimension of any c
```

