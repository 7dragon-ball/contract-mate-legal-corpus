# GCA1966 · 政府合同法（1966）

- 语言：`en`
- 版本：`sg:GCA1966:en:src-5e65eb5f0628`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：8；切片：7；发布资格：否

PDF 页数 7，空白页 [2]，目录页 [1, 3]，条文 6。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE GOVERNMENT CONTRACTS ACT 1966 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Government Contracts Act 1966 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Contracts on behalf of Government 3. Contracts made outside Singapore 4. No other contracts to be binding 5. Limitation of personal liability of public officer 6. Provision in respect of land An Act to provide for the making of contracts on behalf of the Government and for matt
```

### `section:1` · section · 

```text
1. This Act is the Government Contracts Act 1966. Contracts on behalf of Government
```

### `section:2` · section · Contracts on behalf of Government

```text
2.—(1) All contracts made in Singapore for or on behalf of the Government shall, if reduced to writing, be made in the name of the Government and may be signed by a Minister or by any public officer duly authorised in writing by the Minister for Finance, either specially in any particular case, or generally for all contracts below a certain value in his Ministry or department.
(2) In making an authorisation under subsection (1), it shall be sufficient for the Minister for Finance to name the office held by such public officer and the Minister may cause the authorisation to be published in the Gazette.
(3) For the purposes of this section, an individual who is an employee of a statutory body 
```

### `section:3` · section · Contracts made outside Singapore

```text
3. All contracts made outside Singapore for or on behalf of the Government by a person either generally or specially authorised in writing in that behalf by the Minister for Finance shall, so far as they come within the jurisdiction of the courts in Singapore, be deemed to be Government contracts. No other contracts to be binding
```

### `section:4` · section · No other contracts to be binding

```text
4. No contracts, made after 15 March 1967, shall be binding upon the Government, unless entered into in accordance with this Act and the Constitution. Limitation of personal liability of public officer
```

### `section:5` · section · Limitation of personal liability of public officer

```text
5. No public officer shall be liable to be sued personally upon any contract which he makes in that capacity; but a public officer shall be personally liable when he expressly pledges his personal credit or where he contracts otherwise than as the agent of the Government. Provision in respect of land
```

### `section:6` · section · Provision in respect of land

```text
6.—(1) Grants and leases of State lands and leases made under the Foreshores Act 1920 shall be signed by a Collector of Land Revenue.
(2) Nothing in this Act shall be deemed to affect the provisions of any written law in Singapore as to the use or occupation of State land. Government Contracts Act 1966 2
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY GOVERNMENT CONTRACTS ACT 1966 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act. PICTORIAL OVERVIEW OF PREDECESSOR ACTS LEGISLATIVE HISTORY DETAILS
PART 1 GOVERNMENT CONTRACTS ORDINANCE, 1949 (M. ORDINANCE 67 OF 1949)
1. M. Ordinance 67 of 1949 — Government Contracts Ordinance, 1949 Commencement : 31 December 1949 Application : 16 April 1964 (except section 7) Note: This Ordinance was extended in part to Singapore by the Modification of Laws (Government Contracts) (Extension) Order, 1964 (L.N. 108/1964 (G.N. Sp. No. S 69/1964)) on 16 April 1964.
2. L.N. 108/1964 (G.N. Sp. No. S 69/1964) — Modif
```

