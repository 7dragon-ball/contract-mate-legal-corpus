# CoA1967 · 公司法（1967）

- 语言：`en`
- 版本：`sg:CoA1967:en:src-fe42d163d226`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：485；切片：544；发布资格：否

PDF 页数 611，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]，条文 473。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE COMPANIES ACT 1967 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Companies Act 1967 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Division into Parts 3. Repeals 4. Interpretation 5. Definition of subsidiary and holding company 5A. Definition of ultimate holding company 5B. Definition of wholly owned subsidiary 6. When corporations deemed to be related to each other 7. Interests in shares 7A. Solvency stateme
```

### `section:3` · section · 

```text
3.—(1) The written laws mentioned in the First Schedule to the extent to which they are therein expressed to be repealed or amended are repealed or amended accordingly. Transitory provisions
(2) Unless the contrary intention appears in this Act —
(a) all persons, things and circumstances appointed or created under any of the repealed or amended written laws or existing or continuing under any of such written laws immediately before 29 December 1967 continue under and subject to this Act to have the same status, operation and effect as they respectively would have had if such written laws had not been so repealed or amended; and
(b) in particular and without limiting paragraph (a), such repea
```

### `section:4` · section · Interpretation

```text
4.—(1) In this Act, unless the contrary intention appears — “accounting corporation” means a company approved or deemed to be approved as an accounting corporation under the Accountants Act 2004; “accounting entity” means a public accountant, an accounting corporation, an accounting firm or an accounting limited liability partnership; “accounting firm” means a firm approved or deemed to be approved as an accounting firm under the Accountants Act 2004; “accounting limited liability partnership” means a limited liability partnership approved as an accounting limited liability partnership under the Accountants Act 2004; “accounting records”, in relation to a corporation, includes such working p
```

### `section:5` · section · Definition of subsidiary and holding company

```text
5.—(1) For the purposes of this Act, a corporation is, subject to subsection (3), deemed to be a subsidiary of another corporation, if —
(a) that other corporation —
(i) controls the composition of the board of directors of the firstmentioned corporation; or
(ii) controls more than half of the voting power of the firstmentioned corporation; or
(b) the firstmentioned corporation is a subsidiary of any corporation which is that other corporation’s subsidiary.
[36/2014]
(2) For the purposes of subsection (1), the composition of a corporation’s board of directors is deemed to be controlled by another corporation if that other corporation by the exercise of some power exercisable by it without th
```

### `section:5A` · section · Definition of ultimate holding company

```text
5A. For the purposes of this Act, a corporation is the ultimate holding company of another corporation if —
(a) the other corporation is a subsidiary of the firstmentioned corporation; and
(b) the firstmentioned corporation is not itself a subsidiary of any corporation. Definition of wholly owned subsidiary
```

### `section:5B` · section · Definition of wholly owned subsidiary

```text
5B. For the purposes of this Act, a corporation is a wholly owned subsidiary of another corporation if none of the members of the firstmentioned corporation is a person other than —
(a) that other corporation;
(b) a nominee of that other corporation;
(c) a subsidiary of that other corporation being a subsidiary none of the members of which is a person other than that other corporation or a nominee of that other corporation; or
(d) a nominee of such subsidiary. When corporations deemed to be related to each other
```

### `section:6` · section · When corporations deemed to be related to each other

```text
6. Where a corporation —
(a) is the holding company of another corporation; 42
(b) is a subsidiary of another corporation; or
(c) is a subsidiary of the holding company of another corporation, that firstmentioned corporation and that other corporation are for the purposes of this Act deemed to be related to each other. Interests in shares
```

### `section:7` · section · Interests in shares

```text
7.—(1) The following subsections have effect for the purposes of
Division 4 of Part 4 and sections 163, 164 and 165 and subsection (6A), in addition, also has effect for the purposes of section 244.
[36/2014]
(1A) Subject to this section, a person has an interest in shares if the person has authority (whether formal or informal, or express or implied) to dispose of, or to exercise control over the disposal of, those shares.
[36/2014]
(1B) For the purposes of subsection (1A), it is immaterial that the authority of a person to dispose of, or to exercise control over the disposal of, particular shares is, or is capable of being made, subject to restraint or restriction.
[36/2014]
(2) Where any 
```

