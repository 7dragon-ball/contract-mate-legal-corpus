# CCAA2016 · 选择法院协议法（2016）

- 语言：`en`
- 版本：`sg:CCAA2016:en:src-8229cd009b75`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：26；切片：25；发布资格：否

PDF 页数 25，空白页 [2]，目录页 [1, 3, 4]，条文 24。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CHOICE OF COURT AGREEMENTS ACT 2016 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Choice of Court Agreements Act 2016 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. General interpretation 3. Meaning of “exclusive choice of court agreement” 4. Meaning of “international case” 5. Exclusive choice of court agreement as independent agreement 6. Residence of person other than individual 7. Act binds Government 8. A
```

### `section:1` · section · 

```text
1. This Act is the Choice of Court Agreements Act 2016. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “chosen court” means a court, of a Contracting State, designated in an exclusive choice of court agreement; “Contracting State” —
(a) means a State that is a party to the Convention; and 2
(b) includes, in an appropriate case —
(i) a Regional Economic Integration Organisation that is a party to the Convention; and
(ii) a member State, of a Regional Economic Integration Organisation that is a party to, and has made a declaration under Article 30(1) of, the Convention; “Convention” means the Convention on Choice of Court Agreements done at The Hague on 30 June 2005; “court of origin”, in relation to a foreign judgment for which recogn
```

### `section:3` · section · Meaning of “exclusive choice of court agreement”

```text
3.—(1) An exclusive choice of court agreement is an agreement between 2 or more parties that —
(a) is concluded or documented —
(i) in writing; or
(ii) by any other means of communication that renders the information communicated accessible so as to be usable for subsequent reference; and
(b) designates, for the purpose of deciding any dispute that arises or may arise in connection with a particular legal relationship, the courts, or one or more specific courts, of one Contracting State to the exclusion of the jurisdiction of any other court.
(2) A choice of court agreement between 2 or more parties that satisfies the following requirements is deemed to be an exclusive choice of court agreem
```

### `section:4` · section · Meaning of “international case”

```text
4.—(1) For the purposes of Part 2, a case is an international case unless —
(a) the parties to the case reside in the same Contracting State; and
(b) the relationship of the parties and all other elements relevant to the dispute (other than the location of the chosen court) are connected only with that Contracting State.
(2) For the purposes of Part 3, a case is an international case if the claim is for —
(a) the recognition, or recognition and enforcement, of a foreign judgment; or
(b) the enforcement of a judicial settlement recorded before a court of a Contracting State (other than Singapore). Exclusive choice of court agreement as independent agreement
```

### `section:5` · section · Exclusive choice of court agreement as independent agreement

```text
5. Where an exclusive choice of court agreement forms part of a contract —
(a) the agreement is to be treated as independent of the other terms of the contract; and
(b) the validity of the agreement cannot be challenged solely on the ground that the contract is not valid. 6 Residence of person other than individual
```

### `section:6` · section · Residence of person other than individual

```text
6. For the purposes of this Act, a person (other than an individual) is resident in a State if —
(a) the person has its statutory seat in that State;
(b) the person was incorporated or formed under the law of that State;
(c) the person has its central administration in that State; or
(d) the person has its principal place of business in that State. Act binds Government
```

### `section:7` · section · Act binds Government

```text
7. This Act binds the Government. Application of Act
```

