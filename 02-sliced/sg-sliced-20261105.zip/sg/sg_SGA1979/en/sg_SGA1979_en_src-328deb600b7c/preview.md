# SGA1979 · 货物买卖法（1979）

- 语言：`en`
- 版本：`sg:SGA1979:en:src-328deb600b7c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：88；切片：87；发布资格：否

PDF 页数 46，空白页 []，目录页 [1, 2, 3, 4, 5]，条文 85。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE SALE OF GOODS ACT 1979 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Sale of Goods Act 1979 ARRANGEMENT OF SECTIONS
PART 1 CONTRACTS TO WHICH ACT APPLIES Section 1. Contracts to which Act applies
PART 2 FORMATION OF THE CONTRACT Contract of sale 2. Contract of sale 3. Capacity to buy and sell Formalities of contract 4. How contract of sale is made Subject matter of contract 5. Existing or future goods 6. Goods which have perished 
```

### `section:1` · section · 

```text
1.—(1) This Act applies to contracts of sale of goods made on or after (but not to those made before) 1 January 1894.
(2) In relation to contracts made on certain dates, this Act applies subject to the modification of certain of its sections as mentioned in the Schedule.
(3) Any such modification is indicated in the section concerned by a reference to the Schedule. 4
(4) Accordingly, where a section does not contain such a reference, this Act applies in relation to the contract concerned without such modification of the section.
PART 2 FORMATION OF THE CONTRACT Contract of sale Contract of sale
```

### `section:2` · section · Contract of sale

```text
2.—(1) A contract of sale of goods is a contract by which the seller transfers or agrees to transfer the property in goods to the buyer for a money consideration, called the price.
(2) There may be a contract of sale between one part owner and another.
(3) A contract of sale may be absolute or conditional.
(4) Where under a contract of sale the property in the goods is transferred from the seller to the buyer, the contract is called a sale.
(5) Where under a contract of sale the transfer of the property in the goods is to take place at a future time or subject to some condition later to be fulfilled, the contract is called an agreement to sell.
(6) An agreement to sell becomes a sale when th
```

### `section:3` · section · Capacity to buy and sell

```text
3.—(1) Capacity to buy and sell is regulated by the general law concerning capacity to contract and to transfer and acquire property.
(2) Where necessaries are sold and delivered to a minor or to a person who by reason of mental incapacity or drunkenness is incompetent to contract, he must pay a reasonable price for them.
(3) In subsection (2), “necessaries” means goods suitable to the condition in life of the minor or other person concerned and to his actual requirements at the time of the sale and delivery. 5 Formalities of contract How contract of sale is made
```

### `section:4` · section · How contract of sale is made

```text
4.—(1) Subject to this and any other Act, a contract of sale may be made in writing (either with or without seal), or by word of mouth, or partly in writing and partly by word of mouth, or may be implied from the conduct of the parties.
(2) Nothing in this section affects the law relating to corporations. Subject matter of contract Existing or future goods
```

### `section:5` · section · Existing or future goods

```text
5.—(1) The goods which form the subject of a contract of sale may be existing goods, owned or possessed by the seller, or goods to be manufactured or acquired by him after the making of the contract of sale, in this Act called future goods.
(2) There may be a contract for the sale of goods the acquisition of which by the seller depends on a contingency which may or may not happen.
(3) Where by a contract of sale the seller purports to effect a present sale of future goods, the contract operates as an agreement to sell the goods. Goods which have perished
```

### `section:6` · section · Goods which have perished

```text
6. Where there is a contract for the sale of specific goods, and the goods without the knowledge of the seller have perished at the time when the contract is made, the contract is void. Goods perishing before sale but after agreement to sell
```

### `section:7` · section · Goods perishing before sale but after agreement to sell

```text
7. Where there is an agreement to sell specific goods and subsequently the goods, without any fault on the part of the seller or buyer, perish before the risk passes to the buyer, the agreement is avoided. 6 Price Ascertainment of price
```

