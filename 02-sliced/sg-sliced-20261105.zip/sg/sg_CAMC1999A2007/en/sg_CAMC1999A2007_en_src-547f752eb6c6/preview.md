# CAMC1999A2007 · 航空运输（1999年蒙特利尔公约）法（2007）

- 语言：`en`
- 版本：`sg:CAMC1999A2007:en:src-547f752eb6c6`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：112；切片：111；发布资格：否

PDF 页数 37，空白页 []，目录页 [1, 2]，条文 109。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CARRIAGE BY AIR (MONTREAL CONVENTION, 1999) ACT 2007 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Carriage by Air (Montreal Convention, 1999) Act 2007 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Convention to have force of law 4. State Parties to Convention 5. Liability for fatal accidents under Article 17 of Convention 6. Limitations of liability under Article 22 of Convention 7. Power to amend Schedule a
```

### `section:1` · section · 

```text
1. This Act is the Carriage by Air (Montreal Convention, 1999) Act 2007. 1 Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “Convention” means the Convention for the unification of certain rules relating to international carriage by air opened for signature at Montreal on 28 May 1999, the text of which is set out in the Schedule; “court”, in relation to any arbitration proceedings allowed by Article 34 of the Convention, means the arbitrator or arbitration tribunal hearing the arbitration; “regulations” means regulations made under section 13. Convention to have force of law
```

### `section:3` · section · Convention to have force of law

```text
3.—(1) Despite any other written law or rule of law but subject to this Act, the provisions of the Convention, so far as they relate to the rights and liabilities of carriers, carriers’ servants and agents, passengers, consignors, consignees and other persons, have the force of law in Singapore in relation to any carriage by air to which the Convention applies regardless of the nationality of the aircraft performing that carriage.
(2) Subsection (1) does not affect rights or liabilities arising out of an occurrence before 16 November 2007. State Parties to Convention
```

### `section:4` · section · State Parties to Convention

```text
4.—(1) For the purposes of this Act, a State Party to the Convention refers to any country that has ratified, accepted, approved or acceded to the Convention in accordance with Article 53 of the Convention.
(2) This Act applies to any such State Party to the Convention only in respect of such of its territorial units as it has, by a declaration made under Article 56 of the Convention, declared to be a territorial unit to which the Convention is to apply. Liability for fatal accidents under Article 17 of Convention
```

### `section:5` · section · Liability for fatal accidents under Article 17 of Convention

```text
5. References in section 20 of the Civil Law Act 1909 to a wrongful act, neglect or default include references to any occurrence which gives rise to liability under Article 17 of the Convention. 2 Limitations of liability under Article 22 of Convention
```

### `section:6` · section · Limitations of liability under Article 22 of Convention

```text
6.—(1) The limitations on liability under Article 22 of the Convention apply whatever the nature of the proceedings by which liability may be enforced.
(2) The limitation for each passenger under paragraph 1 of Article 22 of the Convention applies to the aggregate liability of the carrier in all proceedings which may be brought against the carrier under the law of Singapore, together with any proceedings brought against the carrier outside Singapore.
(3) A court before which proceedings are brought to enforce a liability which is limited by Article 22 of the Convention may at any stage of the proceedings make any such order as appears to the court to be just and equitable in view of —
(a) th
```

### `section:7` · section · liability under Article 24 of Convention

```text
7. Where any limit of liability prescribed by Article 21, 22 or 23 of the Convention has been revised under Article 24 of the Convention, the Minister may, by order in the Gazette, amend the Schedule to append thereto, immediately after the text of the Convention, an addendum specifying how the limit of liability has been revised and the date on which the revision is to take effect. Notice of partial loss under Article 31 of Convention
```

