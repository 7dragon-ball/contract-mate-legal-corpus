# FSSA2025 · 食品安全与保障法 2025

- 语言：`en`
- 版本：`sg:FSSA2025:en:src-52b519b1e13f`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：440；切片：453；发布资格：否

PDF 页数 456，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]，条文 437。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
FOOD SAFETY AND SECURITY ACT 2025 (No. 7 of 2025) ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. Purposes of Act 3. General interpretation 4. Meaning of “food” 5. Meaning of “food business” 6. Meaning of “licensable food business” 7. Meanings of “publish in Singapore”, “advertise” and associated terms 8. Meanings of “sell” and “supply” 9. Meaning of “handling” food 10. Meanings of “manufacturing” and “preparing” food 11. Meaning of “unsafe” food 12. Meaning of “unsuitable” food 13. Meaning of “defined food” 14. Meanings of “primary produce” and “unsafe primary produce” 15. Meaning of “primary production activity” 16. Meanings of “animal feed” and associ
```

### `section:1` · section · 

```text
1. This Act is the Food Safety and Security Act 2025 and comes into operation on a date that the Minister appoints by notification in the Gazette. Purposes of Act
```

### `section:2` · section · Purposes of Act

```text
2. The purposes of this Act are —
(a) to improve food security in Singapore through maintaining in Singapore a minimum quantity of stocks of certain foods and agri‑food production inputs, and measures to mitigate the impact of agri‑food supply chain disruptions on Singapore;
(b) to increase production of primary produce on a sustainable basis in Singapore so as to contribute to food security in Singapore;
(c) to ensure that food in Singapore is safe and suitable for human consumption and that non‑packaged drinking water in Singapore is not unwholesome;
(d) to improve traceability systems to enable food to be more efficiently and effectively recalled due to food safety concerns;
(e) to ensure
```

### `section:3` · section · General interpretation

```text
3.—(1) In this Act — “advertise” or “advertising”, as a verb, has the meaning given by section 7(2); “advertisement” has the meaning given by section 7(5); “Agency” means the Singapore Food Agency established by the Singapore Food Agency Act 2019; “agri‑food production input” means any of the following to the extent that it is essential in undertaking any primary production activity:
(a) any animal feed;
(b) any plant pesticide;
(c) any animal reproductive material from a food producing animal;
(d) any young of a food producing animal;
(e) any seed, spore, bulb, root, cutting or other part of a plant from which plants grow or further plants grow;
(f) any veterinary biologics, or any vaccines
```

### `section:4` · section · Meaning of “food”

```text
4.—(1) In this Act, “food” includes the following:
(a) any substance or thing of a kind used, capable of being used, or represented as being for use, for human consumption (whether it is live, raw, prepared or partly prepared);
(b) any substance or thing of a kind used, capable of being used, or represented as being for use, as an ingredient or food additive in a substance or thing referred to in paragraph (a);
(c) any substance used in preparing a substance or thing referred to in paragraph (a) (other than a substance used in preparing a living thing);
(d) chewing gum or an ingredient or food additive in chewing gum, or any substance used in preparing chewing gum;
(e) any substance or thing
```

### `section:5` · section · Meaning of “food business”

```text
5.—(1) In this Act, “food business” means a business or an undertaking or activity that involves —
(a) the production of primary produce;
(b) the handling of food intended for supply or for export; or
(c) the supply of food, 50 regardless of whether the business, undertaking or activity concerned is of a commercial, charitable or community nature or whether it involves the handling or the supply of food on one occasion only.
(2) To avoid doubt, a “food business” includes a food business carried on as a home business or that is an occupation carried on by an individual within the individual’s private residence.
(3) However, a “food business” does not include a business or an undertaking or ac
```

### `section:6` · section · Meaning of “licensable food business”

```text
6.—(1) In this Act, a “licensable food business” means a food business in Singapore that falls within a class of retail food business or non‑retail food business that is specified in the First Schedule. 51
(2) The Minister may, by order in the Gazette, amend the First Schedule —
(a) by deleting a class of food business in the First Schedule;
(b) by varying the description of a class of food business or replacing a class of food business in the First Schedule; or
(c) by adding a class of food business to the First Schedule.
(3) Before amending the First Schedule with respect to any class of food business, the Minister must take into account the following factors:
(a) the risk to public health
```

### `section:7` · section · associated terms

```text
7.—(1) In this Act, “publish in Singapore”, in relation to any content, means communicating, distributing, or making available or making known, the content to the general public, in whatever form and by whatever means, such as (but not limited to) — 52
(a) including the content in a newspaper, magazine, leaflet, brochure, ticket or other document that is available, or distributed, to the general public;
(b) including in a film, video, television programme or radio programme that is, or is intended to be, seen or heard by the general public;
(c) publicly displaying the content, or something that contains the content, in Singapore; . Examples A blimp, a gas‑inflated balloon or other like objec
```

