# CA2004 · 竞争法（2004）

- 语言：`en`
- 版本：`sg:CA2004:en:src-77d3a0fa5cf2`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：166；切片：167；发布资格：否

PDF 页数 123，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7]，条文 160。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE COMPETITION ACT 2004 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Competition Act 2004 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 COMPETITION AND CONSUMER COMMISSION OF SINGAPORE
Division 1 — Establishment, incorporation and constitution of Commission 3. Establishment and incorporation of Competition and Consumer Commission of Singapore 4. Common seal 5. Constitution of Commission
D
```

### `section:1` · section · 

```text
1. This Act is the Competition Act 2004. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “anticipated merger” means an arrangement that is in progress or contemplation and that, if carried into effect, will result in the occurrence of a merger referred to in section 54(2); “block exemption” has the meaning given by section 36(5); “block exemption order” has the meaning given by section 36(3); “Board” means the Competition Appeal Board established under section 72; “Chairperson” means the Chairperson of the Commission and includes any temporary Chairperson of the Commission; “Chief Executive” means the Chief Executive of the Commission, and includes any individual acting in that capacity; “Commission” means the Competiti
```

### `section:3` · section · Consumer Commission of Singapore

```text
3. A body called the Competition and Consumer Commission of Singapore is established, which is a body corporate with perpetual succession and is by that name capable of —
(a) suing and being sued; 9
(b) acquiring, owning, holding and developing or disposing of property, both movable and immovable; and
(c) doing and suffering any other acts or things that bodies corporate may lawfully do and suffer.
[10/2018] Common seal
```

### `section:4` · section · Common seal

```text
4.—(1) The Commission must have a common seal and the seal may be broken, changed, altered or made anew as the Commission thinks fit.
(2) All deeds and other documents requiring the seal of the Commission must be sealed with the common seal of the Commission.
(3) All courts, judges and persons acting judicially are to take judicial notice of the common seal of the Commission affixed to any document and presume that it was duly affixed. Constitution of Commission
```

### `section:5` · section · Constitution of Commission

```text
5.—(1) The Commission consists of the following members:
(a) a Chairperson;
(b) such other members, not being less than 2 or more than 16, as the Minister may determine.
(2) The First Schedule has effect with respect to the Commission, its members and proceedings.
Division 2 — Functions, duties and powers of Commission Functions and duties of Commission
```

### `section:6` · section · Functions and duties of Commission

```text
6.—(1) Subject to the provisions of this Act, the functions and duties of the Commission are —
(a) to maintain and enhance efficient market conduct and promote overall productivity, innovation and competitiveness of markets in Singapore;
(b) to eliminate or control practices having adverse effect on competition in Singapore; 10
(c) to promote and sustain competition in markets in Singapore;
(d) to promote a strong competitive culture and environment throughout the economy in Singapore;
(e) to act internationally as the national body representative of Singapore in respect of competition matters, consumer protection and legal metrology;
[Act 13 of 2025 wef 01/07/2025]
(f) to promote fair tradi
```

### `section:7` · section · Powers of Commission

```text
7.—(1) Subject to the provisions of this Act, the Commission may carry on any activities as appear to the Commission to be advantageous, necessary or convenient for it to carry on for or in connection with the performance of its functions and the discharge of its duties under this Act or any other written law and, in particular, the Commission may exercise any of the powers specified in the Second Schedule.
(2) This section does not limit any power of the Commission conferred by or under any other written law.
(3) The Commission must provide the Minister information with respect to its property and activities in such manner and at such times as the Minister may require. 12 Directions of Mini
```

