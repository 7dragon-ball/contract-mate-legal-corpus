# SGUNCA1995 · 货物买卖（联合国公约）法（1995）

- 语言：`en`
- 版本：`sg:SGUNCA1995:en:src-9da8fcce8597`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：8；切片：17；发布资格：否

PDF 页数 34，空白页 [2]，目录页 [1, 3]，条文 5。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE SALE OF GOODS (UNITED NATIONS CONVENTION) ACT 1995 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Sale of Goods (United Nations Convention) Act 1995 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Convention to have force of law 4. Convention to prevail in event of inconsistency 5. Convention countries The Schedule — United Nations Convention on Contracts for the International Sale of Goods An Act to give effect
```

### `section:1` · section · 

```text
1. This Act is the Sale of Goods (United Nations Convention) Act 1995. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, “Convention” means the United Nations Convention on Contracts for the International Sale of Goods adopted at Vienna, Austria, on 10 April 1980 and opened for signature and accession on 11 April 1980, the English text of which is set out in the Schedule. Convention to have force of law
```

### `section:3` · section · Convention to have force of law

```text
3.—(1) Subject to subsection (2), the provisions of the Convention have the force of law in Singapore. 1
(2) Sub-paragraph (1)(b) of Article 1 of the Convention does not have the force of law in Singapore and accordingly the Convention will apply to contracts of sale of goods only between those parties whose places of business are in different States when the States are Contracting States.
(3) The Minister may by order delete subsection (2) if the reservation made pursuant to Article 95 of the Convention is withdrawn except that sub-paragraph (1)(b) of Article 1 of the Convention does not apply to and does not have the force of law in relation to any proposal for concluding the contract made
```

### `section:4` · section · Convention to prevail in event of inconsistency

```text
4. The provisions of the Convention prevail over any other law in force in Singapore to the extent of any inconsistency. Convention countries
```

### `section:5` · section · Convention countries

```text
5.—(1) A notification made by the Minister and published in the Gazette —
(a) declaring that the Convention has entered or will enter into force, with effect from a specified date, in respect of a specified country;
(b) declaring that a specified country has made a declaration under Part IV of the Convention and specifying details of that declaration, including the date the declaration took or will take effect; or
(c) declaring that a specified country has denounced the Convention or Part II or III of the Convention and specifying the date the denunciation took or will take effect, is evidence of the facts contained in the notification. 2
(2) For the purposes of this Act, a certificate signe
```

### `schedule:1` · schedule · THE SCHEDULE

```text
THE SCHEDULE Section 2 UNITED NATIONS CONVENTION ON CONTRACTS FOR THE INTERNATIONAL SALE OF GOODS THE STATES PARTIES TO THIS CONVENTION, BEARING IN MIND the broad objectives in the resolutions adopted by the sixth special session of the General Assembly of the United Nations on the establishment of a New International Economic Order, CONSIDERING that the development of international trade on the basis of equality and mutual benefit is an important element in promoting friendly relations among States, BEING OF THE OPINION that the adoption of uniform rules which govern contracts for the international sale of goods and take into account the different social, economic and legal systems would co
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY SALE OF GOODS (UNITED NATIONS CONVENTION) ACT 1995 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act.
1. Act 14 of 1995 — Sale of Goods (United Nations Convention) Act 1995 Bill : 8/1995 First Reading : 1 March 1995 Second and Third Readings : 23 March 1995 Commencement : 1 March 1996
2. 1996 Revised Edition — Sale of Goods (United Nations Convention) Act (Chapter 283A) Operation : 30 April 1996
3. 2013 Revised Edition — Sale of Goods (United Nations Convention) Act (Chapter 283A) Operation : 31 August 2013 Abbreviations C.P. Council Paper G.N. No. S (N.S.) Government Notification Number Singap
```

