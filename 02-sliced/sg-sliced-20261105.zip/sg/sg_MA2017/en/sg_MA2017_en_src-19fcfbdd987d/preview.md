# MA2017 · 调解法（2017）

- 语言：`en`
- 版本：`sg:MA2017:en:src-19fcfbdd987d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：18；切片：17；发布资格：否

PDF 页数 17，空白页 []，目录页 [1, 2]，条文 16。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE MEDIATION ACT 2017 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Mediation Act 2017 ARRANGEMENT OF SECTIONS Section 1. Short title 2. General interpretation 3. Meaning of “mediation” 4. Meaning and form of “mediation agreement” 5. Act binds Government 6. Application of Act 7. Designation of mediation service provider and approved certification scheme 8. Stay of court proceedings 9. Restrictions on disclosure 10. Admissibility of m
```

### `section:1` · section · 

```text
1. This Act is the Mediation Act 2017. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “approved certification scheme” means an accreditation or a certification scheme designated as an approved certification scheme under section 7; 1 “certified mediator” means a mediator who is certified under an approved certification scheme; “designated mediation service provider” means a mediation service provider designated under section 7; “mediated settlement agreement”, in relation to a mediation, means an agreement by some or all of the parties to the mediation settling the whole or part of the dispute to which the mediation relates; “mediation agreement” means a mediation agreement described in section 4; “mediation communica
```

### `section:3` · section · Meaning of “mediation”

```text
3.—(1) In this Act, “mediation” means a process comprising one or more sessions in which one or more mediators assist the parties to a dispute to do all or any of the following with a view to facilitating the resolution of the whole or part of the dispute:
(a) identify the issues in dispute;
(b) explore and generate options;
(c) communicate with one another;
(d) voluntarily reach an agreement.
(2) For the purposes of subsection (1), a session is a meeting between the mediator, or one or more mediators (where more than one mediator is appointed for a mediation), and one or more of the parties to the dispute, and includes any activity undertaken (whether by a mediator, a party to the dispute o
```

### `section:4` · section · Meaning and form of “mediation agreement”

```text
4.—(1) In this Act, “mediation agreement” means an agreement by 2 or more persons to refer the whole or part of a dispute which has arisen, or which may arise, between them for mediation.
(2) A mediation agreement may be in the form of a clause in a contract or in the form of a separate agreement.
(3) A mediation agreement must be in writing.
(4) A mediation agreement is in writing if its content is recorded in any form, whether or not the mediation agreement has been concluded orally, by conduct or by other means.
(5) A reference in a contract to any document containing a mediation clause constitutes a mediation agreement in writing if the reference is such as to make that clause part of th
```

### `section:5` · section · Act binds Government

```text
5. This Act binds the Government. Application of Act
```

### `section:6` · section · Application of Act

```text
6.—(1) Subject to subsections (2), (3), (4) and (5), this Act applies to, or in relation to, any mediation conducted under a mediation agreement where —
(a) the mediation is wholly or partly conducted in Singapore; or
(b) the agreement provides that this Act or the law of Singapore is to apply to the mediation.
[4/2020] 4
(2) This Act does not apply to, or in relation to, the following:
(a) any mediation or conciliation proceeding, process, scheme or framework conducted under, or provided by or under, any written law;
(b) unless otherwise provided in an order under subsection (4), any mediation conducted by, or under a direction by, a court;
(c) subject to subsection (5), any mediation or co
```

### `section:7` · section · certification scheme

```text
7.—(1) The Minister may, subject to such terms and conditions as the Minister thinks fit to impose —
(a) designate any mediation service provider to be a designated mediation service provider for the purposes of this Act; and
(b) designate any accreditation or certification scheme administered by a mediation institution to be an approved certification scheme for the purposes of this Act.
(2) Notice of every designation must be published in the Gazette. Stay of court proceedings
```

