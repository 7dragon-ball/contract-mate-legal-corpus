# PA1994 · 专利法（1994）

- 语言：`en`
- 版本：`sg:PA1994:en:src-2632a0c7ee74`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：131；切片：143；发布资格：否

PDF 页数 158，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7]，条文 128。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE PATENTS ACT 1994 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Patents Act 1994 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Application to Government
PART 2 ADMINISTRATION 4. Registrar of Patents and other officers 5. Delegation by Registrar 6. Registry of Patents 7. Seal of Registry 8. Powers of Registrar 9. Disobedience to summons an offence 10. Refusal to give evidence an offence 11. O
```

### `section:1` · section · 

```text
1. This Act is the Patents Act 1994. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “Convention on International Exhibitions” means the Convention relating to International Exhibitions signed in 6 Paris on 22 November 1928, as amended or supplemented by any protocol to that convention which is for the time being in force; “corresponding application”, in relation to an application for a patent (called in this definition the application in suit), means an application for protection filed, or treated as filed, with any prescribed patent office that —
(a) forms the basis for a priority claim under section 17 in the application in suit; or
(b) is subject to a priority claim based on —
(i) the application in suit; or
(ii
```

### `section:3` · section · Application to Government

```text
3. This Act binds the Government.
PART 2 ADMINISTRATION Registrar of Patents and other officers
```

### `section:4` · section · Registrar of Patents and other officers

```text
4.—(1) There is to be a Registrar of Patents who has the chief control of the Registry of Patents.
(2) There is to be one or more Deputy Registrars of Patents who, subject to the control of the Registrar, have all the powers and functions of the Registrar under this Act, other than the powers of the Registrar under section 5.
(3) There is to be one or more Assistant Registrars of Patents.
(4) The Registrar and all the other officers under this section must be appointed by the Minister. Delegation by Registrar
```

### `section:5` · section · Delegation by Registrar

```text
5.—(1) The Registrar may, in relation to a particular matter or class of matters, by writing under the hand of the Registrar, delegate all or any of the Registrar’s powers or functions under this Act (except this power of delegation) to an Assistant Registrar of Patents, any public 15 officer, or any person with the relevant qualifications for or experience in the matter or class of matters, so that the delegated powers and functions may be exercised by the delegate with respect to the matter or class of matters specified in the instrument of delegation.
[4/2014]
(2) A delegation under this section is revocable at will and no delegation prevents the exercise of a power or function by the Reg
```

### `section:6` · section · Registry of Patents

```text
6. For the purposes of this Act, there is an office which is known as the Registry of Patents. Seal of Registry
```

### `section:7` · section · Seal of Registry

```text
7. There is a seal of the Registry and impressions of the seal are to be judicially noticed. Powers of Registrar
```

