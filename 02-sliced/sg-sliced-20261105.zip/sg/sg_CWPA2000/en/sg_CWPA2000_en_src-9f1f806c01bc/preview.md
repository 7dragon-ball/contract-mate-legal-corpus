# CWPA2000 · 禁止化学武器法 2000

- 语言：`en`
- 版本：`sg:CWPA2000:en:src-9f1f806c01bc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：37；切片：38；发布资格：否

PDF 页数 36，空白页 [2]，目录页 [1, 3, 4, 5]，条文 34。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CHEMICAL WEAPONS (PROHIBITION) ACT 2000 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Chemical Weapons (Prohibition) Act 2000 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Act binds Government 4. Purpose of Act 5. Extraterritorial application
PART 2 ADMINISTRATION 6. Administration of Act 7.
[Repealed]
PART 3 OFFENCES 8. Use, etc., of chemical weapons 9. Licence for use, etc., of scheduled 
```

### `section:1` · section · 

```text
1. This Act is the Chemical Weapons (Prohibition) Act 2000. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “authorised officer” means —
(a) the Director-General;
(b) any officer of customs;
(c) any police officer; or
(d) any person appointed as an authorised officer under section 6(3); “chemical weapon” means the following, together or separately:
(a) a toxic chemical and its precursors, except where intended for a permitted purpose, as long as the type and quantity are consistent with that purpose;
(b) a munition or device, specifically designed to cause death or other harm through the toxic properties of a toxic chemical referred to in paragraph (a), which would be released as a result of the employment of the munition or device;
(c) a
```

### `section:3` · section · Act binds Government

```text
3. This Act binds the Government. Purpose of Act
```

### `section:4` · section · Purpose of Act

```text
4.—(1) The purpose of this Act is to implement Singapore’s obligations under the Convention.
(2) Every person exercising a power or discretion conferred under this Act must have regard to Singapore’s obligations under the Convention. Extraterritorial application
```

### `section:5` · section · Extraterritorial application

```text
5.—(1) Sections 8 and 26 extend to acts done or omitted to be done outside Singapore by —
(a) any citizen of Singapore; or
(b) any other person on board any ship or aircraft registered in Singapore. 6
(2) Where an offence under section 8 or 26 is committed outside Singapore by a citizen of Singapore, he or she may be dealt with in respect of that offence as if that offence had been committed within Singapore.
(3) Despite anything in any other written law, proceedings in respect of any offence under section 8 or 26 committed anywhere outside Singapore must not, by virtue only of the provisions of this Act, be instituted in any court except with the consent of the Public Prosecutor.
(4) Despit
```

### `section:6` · section · Administration of Act

```text
6.—(1) The Director-General is responsible for the administration of this Act, subject to the general or special directions of the Minister.
[49/2007]
(2) The Director-General may, with the approval of the Minister, in writing appoint any person as an authorised officer for the purposes of this Act.
[49/2007]
(3) The Director-General may delegate the exercise of all or any of the powers conferred or duties imposed upon him or her by this Act to any authorised officer, except the power of delegation under this subsection.
[49/2007]
```

### `section:7` · section · subsection.

```text
7. [Repealed by Act 49 of 2007] 7
PART 3 OFFENCES Use, etc., of chemical weapons
```

