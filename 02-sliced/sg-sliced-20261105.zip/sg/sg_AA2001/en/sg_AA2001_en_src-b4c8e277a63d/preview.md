# AA2001 · 仲裁法（2001）

- 语言：`en`
- 版本：`sg:AA2001:en:src-b4c8e277a63d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：75；切片：75；发布资格：否

PDF 页数 60，空白页 []，目录页 [1, 2, 3, 4, 5]，条文 73。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ARBITRATION ACT 2001 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Arbitration Act 2001 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Application of this Act
PART 2 ARBITRATION AGREEMENT 4. Definition and form of arbitration agreement 5. Arbitration agreement not to be discharged by death of party
PART 3 STAY OF LEGAL PROCEEDINGS 6. Stay of legal proceedings 7. Court’s powers on stay of pro
```

### `section:1` · section · 

```text
1. This Act is the Arbitration Act 2001. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “appellate court” means the court to which an appeal from a decision of the Court is to be made under section 29C of the Supreme Court of Judicature Act 1969; “appointing authority” means the appointing authority designated under section 13(8) or (9); “arbitral tribunal” means a sole arbitrator or a panel of arbitrators or an arbitral institution, and includes an emergency arbitrator appointed pursuant to the rules of arbitration agreed to or adopted by the parties including the rules of arbitration of an institution or organisation; “arbitration agreement” means an arbitration agreement mentioned in section 4; “award” means a decis
```

### `section:3` · section · Application of this Act

```text
3. This Act applies to any arbitration where the place of arbitration is Singapore and where Part 2 of the International Arbitration Act 1994 does not apply to that arbitration.
PART 2 ARBITRATION AGREEMENT Definition and form of arbitration agreement
```

### `section:4` · section · Definition and form of arbitration agreement

```text
4.—(1) In this Act, “arbitration agreement” means an agreement by the parties to submit to arbitration all or certain disputes which have arisen or which may arise between them in respect of a defined legal relationship, whether contractual or not.
[12/2012]
(2) An arbitration agreement may be in the form of an arbitration clause in a contract or in the form of a separate agreement.
[12/2012]
(3) An arbitration agreement must be in writing.
[12/2012]
(4) An arbitration agreement is in writing if its content is recorded in any form, whether or not the arbitration agreement or contract has been concluded orally, by conduct or by other means.
[12/2012]
(5) The requirement that an arbitration ag
```

### `section:5` · section · Arbitration agreement not to be discharged by death of party

```text
5.—(1) An arbitration agreement is not discharged by the death of any party to the agreement but continues to be enforceable by or against the personal representative of the deceased party.
(2) The authority of an arbitrator is not revoked by the death of any party by whom the arbitrator was appointed.
(3) Nothing in this section affects the operation of any written law or rule of law by virtue of which any right of action is extinguished by the death of a person.
PART 3 STAY OF LEGAL PROCEEDINGS Stay of legal proceedings
```

### `section:6` · section · Stay of legal proceedings

```text
6.—(1) Where any party to an arbitration agreement institutes any proceedings in any court against any other party to the agreement in respect of any matter which is the subject of the agreement, any party 7 to the agreement may, at any time after filing and serving a notice of intention to contest or not contest and before delivering any pleading (other than a pleading asserting that the court does not have jurisdiction in the proceedings) or taking any other step in the proceedings, apply to that court to stay the proceedings so far as the proceedings relate to that matter.
[Act 25 of 2021 wef 01/04/2022]
(2) The court to which an application has been made in accordance with subsection (1)
```

### `section:7` · section · Court’s powers on stay of proceedings

```text
7.—(1) Where a court stays proceedings under section 6, the court may, if in those proceedings property has been arrested or bail or other security has been given to prevent or obtain release from arrest, order that — 8
(a) the property arrested be retained as security for the satisfaction of any award made on the arbitration; or
(b) the stay be conditional on the provision of equivalent security for the satisfaction of any such award.
(2) Subject to the Rules of Court and to any necessary modification, the same law and practice apply in relation to property retained pursuant to an order under this section as would apply if it were held for the purposes of proceedings in the court which made
```

