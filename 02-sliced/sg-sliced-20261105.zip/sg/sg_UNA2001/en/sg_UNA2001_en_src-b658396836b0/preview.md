# UNA2001 · 联合国法（2001）

- 语言：`en`
- 版本：`sg:UNA2001:en:src-b658396836b0`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：9；切片：8；发布资格：否

PDF 页数 8，空白页 []，目录页 [1, 2]，条文 7。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE UNITED NATIONS ACT 2001 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 United Nations Act 2001 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Power to make regulations to enable effect to be given to Article 41 of Charter of United Nations 3. Immunity from suit 4. Protection of persons for acts done under Act 5. Liability for breach of regulations 6. Liability of citizens of Singapore for offences committed outside Singapore 7. 
```

### `section:1` · section · 

```text
1. This Act is the United Nations Act 2001. Power to make regulations to enable effect to be given to Article 41 of Charter of United Nations
```

### `section:2` · section · Article 41 of Charter of United Nations

```text
2.—(1) Subject to subsection (2), if, under Article 41 of the Charter of the United Nations signed at San Francisco on 26 June 1945 (being the Article which relates to measures not involving the use of armed force), the Security Council of the United Nations calls upon the Government to apply any measures to give effect to any decision of that Council, the Minister may, from time to time, make regulations that appear to the Minister to be necessary or expedient for enabling those measures to be effectively applied, including (without limiting the preceding words) provisions for —
(a) the apprehension, trial and punishment of persons offending against the regulations; and 1
(b) empowering any
```

### `section:3` · section · Immunity from suit

```text
3.—(1) No action, suit or other legal proceedings shall lie against —
(a) any party to a contract for failing, neglecting or refusing to carry out any act required by the contract; or
(b) any person for failing, neglecting or refusing to carry out any act under any written law, where the failure, neglect or refusal is solely attributable to, or occasioned by, the provisions of this Act or any regulations made under this Act.
(2) This section does not affect the operation of the Frustrated Contracts Act 1959. Protection of persons for acts done under Act
```

### `section:4` · section · Protection of persons for acts done under Act

```text
4. No person shall be personally liable in respect of any act done by the person in the execution or purported execution of this Act or any regulations made under this Act if the person did it in the honest belief that the person’s duty under this Act or any regulations made under this Act required or entitled the person to do it. Liability for breach of regulations
```

### `section:5` · section · Liability for breach of regulations

```text
5.—(1) Every person who commits, or attempts to commit, or does any act with intent to commit, or counsels, procures, aids, abets, or incites any other person to commit, or conspires with any other person (whether in Singapore or elsewhere) to commit any offence against any regulations made under this Act shall be liable on conviction —
(a) in the case of an individual, to a fine not exceeding $500,000 or to imprisonment for a term not exceeding 10 years or to both; or
(b) in any other case, to a fine not exceeding $1 million.
[4/2014]
(2) Nothing in this Act or any regulations made under this Act prevents any person from being prosecuted under any other written law for any act or omission w
```

### `section:6` · section · outside Singapore

```text
6.—(1) The provisions of this Act have effect, in relation to citizens of Singapore, outside as well as within Singapore, and where an offence under this Act or any regulations made under this Act is committed by a citizen of Singapore in any place outside Singapore, he or she may be dealt with in respect of that offence as if it had been committed within Singapore.
(2) Any proceedings against any person under this section which would be a bar to subsequent proceedings against that person for the same offence, if the offence had been committed in Singapore, is a bar to further proceedings against the person, under any written law for the time being in force relating to the extradition of per
```

### `section:7` · section · Jurisdiction of District Court

```text
7. Despite any provision to the contrary in the Criminal Procedure Code 2010, a District Court has jurisdiction to try any offence under this Act and has power to impose the full penalty or punishment in respect of the offence.
[9/2003] 4
```

