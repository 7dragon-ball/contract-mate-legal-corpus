# FA1889 · 商业代理人法（1889）

- 语言：`en`
- 版本：`sg:FA1889:en:src-1fc44ea6bfe0`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：16；切片：15；发布资格：否

PDF 页数 9，空白页 [2]，目录页 [1, 3, 4]，条文 14。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE FACTORS ACT 1889 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Factors Act 1889 ARRANGEMENT OF SECTIONS Preliminary Section 1. Interpretation Dispositions by mercantile agents 2. Powers of mercantile agent with respect to disposition of goods 3. Effect of pledges of documents of title 4. Pledge for antecedent debt 5. Rights acquired by exchange of goods or documents 6. Agreements through clerks, etc. 7. Provisions as to consignors
```

### `section:1` · section · 

```text
1.—(1) For the purposes of this Act — “document of title” includes any bill of lading, dock warrant, warehouse-keeper’s certificate, and warrant or order for the delivery of goods, and any other document used in the ordinary course of business as proof of the possession or control of goods, or authorising or purporting to authorise, either by endorsement or by delivery, the possessor of the document to transfer or receive goods thereby represented; “goods” includes wares and merchandise; “mercantile agent” means a mercantile agent having in the customary course of his business as such agent authority either to sell goods, or to consign goods for the purpose of sale, or to buy goods, or to ra
```

### `section:2` · section · Powers of mercantile agent with respect to disposition of go

```text
2.—(1) Where a mercantile agent is, with the consent of the owner, in possession of goods or of the documents of title to goods, any sale, pledge, or other disposition of the goods, made by him when acting in the ordinary course of business of a mercantile agent, shall, subject to the provisions of this Act, be as valid as if he were expressly authorised by the owner of the goods to make the same: Provided that the person taking under the disposition acts in good faith, and has not at the time of the disposition notice that the person making the disposition has no authority to make the same.
(2) Where a mercantile agent has, with the consent of the owner, been in possession of goods or of th
```

### `section:3` · section · Effect of pledges of documents of title

```text
3. A pledge of the documents of title to goods shall be deemed to be a pledge of the goods. Pledge for antecedent debt
```

### `section:4` · section · Pledge for antecedent debt

```text
4. Where a mercantile agent pledges goods as security for a debt or liability due from the pledgor to the pledgee before the time of the 3 pledge, the pledgee shall acquire no further right to the goods than could have been enforced by the pledgor at the time of the pledge. Rights acquired by exchange of goods or documents
```

### `section:5` · section · Rights acquired by exchange of goods or documents

```text
5. The consideration necessary for the validity of a sale, pledge, or other disposition of goods, in pursuance of this Act, may be either a payment in cash, or the delivery or transfer of other goods, or of a document of title to goods, or of a negotiable security, or any other valuable consideration; but where goods are pledged by a mercantile agent in consideration of the delivery or transfer of other goods, or of a document of title to goods, or of a negotiable security, the pledgee shall acquire no right or interest in the goods so pledged in excess of the value of the goods, documents, or security when so delivered or transferred in exchange. Agreements through clerks, etc.
```

### `section:6` · section · Agreements through clerks, etc.

```text
6. For the purposes of this Act, an agreement made with a mercantile agent through a clerk or other person authorised in the ordinary course of business to make contracts of sale or pledge on his behalf shall be deemed to be an agreement with the agent. Provisions as to consignors and consignees
```

### `section:7` · section · Provisions as to consignors and consignees

```text
7.—(1) Where the owner of goods has given possession of the goods to another person for the purpose of consignment or sale, or has shipped the goods in the name of another person, and the consignee of the goods has not had notice that such person is not the owner of the goods, the consignee shall, in respect of advances made to or for the use of such person, have the same lien on the goods as if such person were the owner of the goods, and may transfer any such lien to another person.
(2) Nothing in this section shall limit or affect the validity of any sale, pledge, or disposition, by a mercantile agent. 4 Dispositions by sellers and buyers of goods Disposition by seller remaining in posses
```

