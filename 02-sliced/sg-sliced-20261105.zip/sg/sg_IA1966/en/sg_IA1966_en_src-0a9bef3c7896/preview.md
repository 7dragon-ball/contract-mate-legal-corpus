# IA1966 · 保险法 1966

- 语言：`en`
- 版本：`sg:IA1966:en:src-0a9bef3c7896`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：194；切片：211；发布资格：否

PDF 页数 267，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]，条文 190。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE INSURANCE ACT 1966 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Insurance Act 1966 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Classification of insurance business and construction of references to matters connected with insurance
PART 2 CONDUCT OF INSURANCE BUSINESS
Division 1 — General restriction on insurers 4. No person to carry on insurance business unless licensed or authorised by 
```

### `section:3` · section · 

```text
3.—(1) For the purposes of this Act, insurance business is divided into 2 classes —
(a) life business, which means all insurance business concerned with life policies, long-term accident and health policies, or both; and
(b) general business, that is to say, all insurance business which is not life business, including the effecting and carrying out by any person, not being a person licensed, approved, designated or otherwise regulated under the Monetary Authority of Singapore Act 1970, Banking Act 1970, Finance Companies Act 1967 or Securities and Futures Act 2001; of contracts for fidelity bonds, performance bonds, administration bonds, bail bonds or customs bonds or similar contracts of gu
```

### `section:4` · section · authorised by Authority

```text
4.—(1) Subject to the provisions of this Act, a person must not carry on any class of insurance business in Singapore as an insurer unless the person is licensed by the Authority under this Act in respect of that class of business.
[23/2003; 11/2013]
(2) Except for a licensed insurer or a foreign insurer carrying on insurance business in Singapore under a foreign insurer scheme, a person carrying on reinsurance business outside Singapore must not carry on the business of providing the reinsurance of liabilities under 17 insurance policies, as a principal and as an insurer, to persons in Singapore unless —
(a) the person is authorised by the Authority under section 42 to do so; or
(b) the per
```

### `section:5` · section · Holding out as licensed insurer or authorised reinsurer

```text
5.—(1) Where any person holds himself, herself or itself out, or purports to hold himself, herself or itself out, to be a licensed insurer or an authorised reinsurer in respect of life business or general business, or both, when that person is not licensed or authorised under this Act in respect of that business —
(a) that person shall be guilty of an offence; and
(b) where that person is a corporation, limited liability partnership or firm, every director, manager or officer of the corporation and every partner or officer of the firm and every partner or manager of the limited liability partnership (as the case may be) shall, unless the person proves that the offence was committed without t
```

### `section:6` · section · Use of word “insurance”

```text
6.—(1) Subject to subsection (3) and except with the written consent of the Authority, a person, other than a licensed insurer, an authorised reinsurer or a foreign insurer carrying on insurance business in Singapore under a foreign insurer scheme, must not —
(a) use the word “insurance” or any of its derivatives in any language, or any other word indicating that that person carries on insurance business in the name, description or title under which it carries on business in Singapore; or
(b) make any representation to such effect in any bill head, letter paper, notice, advertisement or in any other manner.
[23/2003; 11/2013]
(2) Subject to subsections (4) and (5) and except with the written
```

### `section:7` · section · Restrictions on co-branding

```text
7.—(1) Except with the prior written consent of the Authority, a licensed insurer, authorised reinsurer or foreign insurer carrying on insurance business in Singapore under a foreign insurer scheme must not use, together with its name, logo or trade mark in the course of the business it carries on in Singapore, the name, logo or trade mark of any person who —
(a) carries on the business of assuming risk or undertaking liability under policies, whether in Singapore or elsewhere; but
(b) is not a licensed insurer, an authorised reinsurer or a foreign insurer carrying on insurance business in Singapore under a foreign insurer scheme.
[11/2013]
(2) Any insurer which contravenes subsection (1) sh
```

### `section:8` · section · Prohibition relating to solicitation of insurance business

```text
8.—(1) Subject to subsection (5), a person must not solicit any insurance business for any insurer other than —
(a) a licensed insurer;
(b) an authorised reinsurer;
(c) a foreign insurer carrying on insurance business in Singapore under a foreign insurer scheme; or
(d) any other insurer entitled to carry on insurance business in Singapore.
[11/2013]
(2) Subject to subsection (5), a person who solicits any insurance business for a licensed insurer or an insurer referred to in subsection (1)(d) — 22
(a) may only solicit in respect of the insurance business in Singapore of that insurer; and
(b) must not solicit in respect of the insurance business of —
(i) any branch located outside Singapore o
```

### `section:9` · section · Registration of representative office

```text
9.—(1) A person must not establish or operate a representative office unless the representative office is registered with the Authority.
[11/2013]
(2) Any person who desires to establish and operate a representative office must —
(a) apply in writing to the Authority for registration under this section; and
(b) provide any information or document that the Authority may require.
[11/2013]
(3) The Authority must refuse to register a representative office unless —
(a) the applicant is a company, or a company incorporated outside Singapore; and
(b) the applicant satisfies such criteria as may be determined by the Authority.
[11/2013]
(4) The Authority may register a representative office subject
```

