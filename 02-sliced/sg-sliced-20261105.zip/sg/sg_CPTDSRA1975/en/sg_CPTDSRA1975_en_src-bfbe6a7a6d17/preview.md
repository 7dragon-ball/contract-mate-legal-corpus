# CPTDSRA1975 · 消费者保护（商品说明与安全要求）法 1975

- 语言：`en`
- 版本：`sg:CPTDSRA1975:en:src-bfbe6a7a6d17`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：37；切片：37；发布资格：否

PDF 页数 26，空白页 []，目录页 [1, 2, 3, 4]，条文 34。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CONSUMER PROTECTION (TRADE DESCRIPTIONS AND SAFETY REQUIREMENTS) ACT 1975 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Consumer Protection (Trade Descriptions and Safety Requirements) Act 1975 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Appointment of Director of Consumer Protection and other officers
PART 2 PROHIBITION OF FALSE TRADE DESCRIPTIONS 4. Prohibition of false trade descriptio
```

### `section:1` · section · 

```text
1. This Act is the Consumer Protection (Trade Descriptions and Safety Requirements) Act 1975. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “advertisement” includes a catalogue, a circular and a price list; “Director” means the Director of Consumer Protection appointed under section 3; “goods” includes ships, aircraft, vehicles, animals, plants and all kinds of movable property; “premises” includes any place, stall, ship, aircraft or vehicle; “Safety Authority” means the Competition and Consumer Commission of Singapore established by section 3 of the Competition Act 2004;
[Act 13 of 2025 wef 01/07/2025] “supply” includes offer to supply or having goods in possession for the purpose of supply; “trade description” means any description, statement or indication which, dire
```

### `section:3` · section · officers

```text
3.—(1) The Minister may appoint a Director of Consumer Protection, a Deputy Director of Consumer Protection, and such number of Assistant Directors of Consumer Protection and other officers as the Minister may consider necessary or expedient for the purposes of this Act. 4
(2) The powers and duties of the Director under this Act may be exercised and discharged by the Deputy Director or an Assistant Director of Consumer Protection.
PART 2 PROHIBITION OF FALSE TRADE DESCRIPTIONS Prohibition of false trade descriptions
```

### `section:4` · section · Prohibition of false trade descriptions

```text
4. Subject to the provisions of this Act, any person who in the course of a trade or business —
(a) applies a false trade description to any goods; or
(b) supplies any goods to which a false trade description is applied, shall be guilty of an offence. False trade descriptions
```

### `section:5` · section · False trade descriptions

```text
5. For the purposes of this Part —
(a) a false trade description —
(i) means a trade description which by reason of anything contained in or omitted from the trade description is false or likely to mislead in a material respect as regards the goods to which it is applied or in connection with which it is used; and
(ii) includes every alteration of a trade description whether by way of addition, effacement or otherwise which makes the description false or likely to mislead in a material respect; and
(b) a false indication, or anything likely to be taken as an indication which would be false, that any goods comply with a standard specified or recognised by any person or implied by the approval
```

### `section:6` · section · Applying trade description to goods

```text
6.—(1) A person applies a trade description to goods if the person —
(a) affixes or annexes it to or in any manner marks it on or incorporates it with —
(i) the goods themselves; or
(ii) anything in, on or with which the goods are supplied;
(b) places the goods in, on or with anything which the trade description has been affixed or annexed to, marked on or incorporated with, or places any such thing with the goods; or
(c) uses the trade description in any manner likely to be taken as referring to the goods.
(2) An oral statement may amount to the use of a trade description.
(3) Where goods are supplied pursuant to a request in which a trade description is used and the circumstances are such 
```

### `section:7` · section · Trade descriptions used in advertisements

```text
7.—(1) This section has effect where in an advertisement a trade description is used in relation to any class of goods.
(2) The trade description is taken as referring to all goods of the class, whether or not in existence at the time the advertisement is published —
(a) for the purpose of determining whether an offence has been committed under section 4(a); and
(b) where goods of the class are supplied by a person publishing or displaying the advertisement, also for the purpose of determining whether an offence has been committed under section 4(b). 6
(3) In determining for the purposes of this section whether any goods are of a class to which a trade description used in an advertisement re
```

