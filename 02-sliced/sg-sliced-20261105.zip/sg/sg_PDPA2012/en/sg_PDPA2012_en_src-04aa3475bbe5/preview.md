# PDPA2012 · 个人资料保护法（2012）

- 语言：`en`
- 版本：`sg:PDPA2012:en:src-04aa3475bbe5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：165；切片：165；发布资格：否

PDF 页数 125，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7]，条文 153。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE PERSONAL DATA PROTECTION ACT 2012 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Personal Data Protection Act 2012 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Purpose 4. Application of Act
PART 2 PERSONAL DATA PROTECTION COMMISSION AND ADMINISTRATION 5. Personal Data Protection Commission 6. Functions of Commission 7. Advisory committees 8. Delegation 9. Conduct of proceedings 10. Cooperat
```

### `section:1` · section · 

```text
1. This Act is the Personal Data Protection Act 2012. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “advisory committee” means an advisory committee appointed under section 7; “Appeal Committee” means a Data Protection Appeal Committee constituted under section 48P(4), read with the Seventh Schedule; “Appeal Panel” means the Data Protection Appeal Panel established by section 48P(1); “authorised officer”, in relation to the exercise of any power or performance of any function or duty under any provision of this Act, means a person to whom the exercise of that power or performance of that function or duty under that provision has been delegated under section 38 of the Info‑communications Media Development Authority Act 2016; 6 “Aut
```

### `section:3` · section · Purpose

```text
3. The purpose of this Act is to govern the collection, use and disclosure of personal data by organisations in a manner that recognises both the right of individuals to protect their personal data and the need of organisations to collect, use or disclose personal data for purposes that a reasonable person would consider appropriate in the circumstances. Application of Act
```

### `section:4` · section · Application of Act

```text
4.—(1) Parts 3, 4, 5, 6, 6A and 6B do not impose any obligation on —
(a) any individual acting in a personal or domestic capacity;
(b) any employee acting in the course of his or her employment with an organisation;
(c) any public agency; or
(d) any other organisations or personal data, or classes of organisations or personal data, prescribed for the purposes of this provision.
[40/2020]
(2) Parts 3, 4, 5, 6 (except sections 24 and 25), 6A (except sections 26C(3)(a) and 26E) and 6B do not impose any obligation on a data intermediary in respect of its processing of personal data on behalf of and for the purposes of another organisation pursuant to a contract which is evidenced or made in writ
```

### `section:5` · section · Personal Data Protection Commission

```text
5.—(1) The Info‑communications Media Development Authority is designated as the Personal Data Protection Commission.
[22/2016] 13
(2) The Personal Data Protection Commission is responsible for the administration of this Act.
[22/2016] Functions of Commission
```

### `section:6` · section · Functions of Commission

```text
6. The functions of the Commission are —
(a) to promote awareness of data protection in Singapore;
(b) to provide consultancy, advisory, technical, managerial or other specialist services relating to data protection;
(c) to advise the Government on all matters relating to data protection;
(d) to represent the Government internationally on matters relating to data protection;
(e) to conduct research and studies and promote educational activities relating to data protection, including organising and conducting seminars, workshops and symposia relating thereto, and supporting other organisations conducting such activities;
(f) to manage technical cooperation and exchange in the area of data pro
```

### `section:7` · section · Advisory committees

```text
7.—(1) The Minister may appoint one or more advisory committees to provide advice to the Commission with regard to the performance of any of its functions under this Act. 14
(2) The Commission may consult such advisory committees in relation to the performance of its functions and duties and the exercise of its powers under this Act but is not bound by such consultation. Delegation
```

