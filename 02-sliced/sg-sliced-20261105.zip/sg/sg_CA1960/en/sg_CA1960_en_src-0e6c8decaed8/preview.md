# CA1960 · 海关法（1960）

- 语言：`en`
- 版本：`sg:CA1960:en:src-0e6c8decaed8`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：173；切片：178；发布资格：否

PDF 页数 146，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9]，条文 170。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CUSTOMS ACT 1960 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Customs Act 1960 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Scope of Act 3. Interpretation
PART 2 APPOINTMENT OF OFFICERS 4. Appointment of Director‑General and other officers 5. Powers of Director‑General to delegate 6. Officers of customs to be public servants 6A. Officers of customs to be armed 7. Powers of police officers 8. Authority card
```

### `section:3` · section · 

```text
3.—(1) In this Act — “agent”, in relation to a vessel, includes a chinchew and a comprador; “aircraft” includes any kind of craft which may be used for the conveyance of passengers or goods by air; “alcohol” means ethanol; “authentication code” means any identification or identifying code, password or any other authentication method or procedure which has been assigned to a registered user of the computer service mentioned in section 86 for the purposes of identifying and authenticating the access to and use of the computer service by the registered user; “auxiliary police officer” means an auxiliary police officer appointed under the Police Force Act 2004;
[Act 6 of 2025 wef 01/04/2025] “bo
```

### `section:0` · section · containing more than 0.5 per cent alcohol by mass; or

```text
0.5 per cent alcohol by volume, which is fit, or intended, or can by any means be converted, for use as a beverage, but does not include denatured spirit; “in transit” means taken out or sent from any country and brought into Singapore by land, sea or air (whether or not landed or transhipped in Singapore) for the sole purpose of being carried to another country either by the same or another conveyance; “licensed FTZ operator” has the meaning given by section 2 of the Free Trade Zones Act 1966;
[Act 33 of 2023 wef 01/03/2024] “licensed warehouse” means a warehouse or other place licensed or deemed to be licensed under section 51(1), 63(1), or 83(4) (if the licence granted under section 83(3)
```

### `section:4` · section · Appointment of Director‑General and other officers

```text
4.—(1) The Minister may appoint an officer to be styled the Director‑General of Customs who has the superintendence of all matters relating to this Act, subject to the direction and control of the Minister.
(2) The Minister may appoint such number of Deputy Directors‑General of Customs and Assistant Directors‑General of Customs as the Minister thinks fit.
(3) Subject to the general direction and supervision of the Director‑General of Customs, the Deputy Directors‑General of Customs and Assistant Directors‑General of Customs have and may exercise all the powers conferred on the Director‑General by this Act.
(4) The Minister may appoint such number of other senior officers of customs as the Mi
```

### `section:5` · section · Powers of Director‑General to delegate

```text
5.—(1) The Director‑General may confer on any senior officer of customs appointed under section 4(4) all or any of the powers conferred on the Director‑General by this Act, subject to such conditions or restrictions as the Director‑General thinks fit.
[29/2018]
(2) The Director‑General may appoint such number of other officers of customs as the Director‑General thinks fit for the purpose of carrying out the provisions of this Act.
(3) The Director‑General may confer on any officer of customs appointed under subsection (2) all or any of the powers of a senior officer of customs. Officers of customs to be public servants
```

### `section:6` · section · Officers of customs to be public servants

```text
6. All officers of customs are deemed to be public servants within the meaning of the Penal Code 1871. 16 Officers of customs to be armed
```

### `section:6A` · section · Officers of customs to be armed

```text
6A. Every officer of customs must be provided with such batons, arms, ammunition and other accoutrements as may be necessary for the effective discharge of his or her duties.
[Act 31 of 2022 wef 01/11/2022] Powers of police officers
```

### `section:7` · section · Powers of police officers

```text
7. For the purposes of this Act —
(a) all police officers not below the rank of sergeant have and may exercise all the powers conferred by this Act on senior officers of customs; and
(b) all police officers below the rank of sergeant have and may exercise all the powers conferred by this Act on officers of customs. Authority card to be produced
```

