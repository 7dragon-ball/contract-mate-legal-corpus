# RIEA1995-RG1 · 进出口管制规例

- 语言：`en`
- 版本：`sg:RIEA1995-RG1:en:src-9a4d3b880f1c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：56；切片：62；发布资格：否

PDF 页数 57，空白页 []，目录页 [1, 2, 3, 4]，条文 46。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
Regulation of Imports and Exports Regulations Table of Contents
Part I PRELIMINARY 1 Citation 2 Definitions
Part II IMPORT, EXPORT AND TRANSHIPMENT OF GOODS 3 Permit for import, export or transhipment 4 Application for permit mentioned in regulation 3 5 Approval of competent authority 5A Permit for certain goods 5B Application for permit mentioned in regulation 5A 6 Prohibited goods 7 Lapsing of permits 8 Taking delivery of imported goods or despatch of goods for export 9 Manifests, bills of lading and air waybills in respect of exports 10 Return of permits 11 Submission of manifests and permits for exports 12 Submission of manifests and permits for imports 13 Nationality of vessel or aircra
```

### `section:1` · section · 

```text
1.  These Regulations may be cited as the Regulation of Imports and Exports Regulations. Definitions
```

### `section:2` · section · Definitions

```text
2.  In these Regulations, unless the context otherwise requires — “competent authority”, in relation to a controlled import, controlled export or controlled transhipment —
(a) specified in the first column of Part A or C of the First Schedule, means the authority specified in the second column thereof; or
[S 645/2017 wef 08/11/2017]
(b) for which a permit, licence or any form of approval or sanction is required from any authority under any regulations made under the Act or any other written law for its import into, export from or transhipment in Singapore, means that authority; “controlled export” means —
(a) any goods specified in the first column of Part C of the First Schedule; or
[S 645/
```

### `section:3` · section · Permit for import, export or transhipment

```text
3.—(1)  Subject to paragraphs (2), (2A), (3) and (4) and regulation 5A, no goods shall be —
(a) imported into Singapore;
(b) exported out of Singapore; or
(c) transhipped in Singapore, except in accordance with a permit granted by the Director-General under this Part.
[S 370/2013 wef 01/07/2013]
[S 645/2017 wef 08/11/2017]
(2)  The requirement in paragraph (1) for a permit to import, export or tranship any goods shall not apply if such goods are not controlled imports, controlled exports or controlled transhipments and are —
(a) personal or household effects, other than motor vehicles, which —
(i) accompany passengers, crew or employees of transport undertakings by land, sea or air;
(ii) are
```

### `section:4` · section · Application for permit mentioned in regulation 3

```text
4.—(1)  An application for a permit under regulation 3 to import, export or tranship any goods shall be made to the Director-General —
(a) by the importer, exporter, shipping agent, air cargo agent, freight forwarder or common carrier, as the case may be, or the declarant as referred to in Part IVA; and
[S 189/2013 wef 02/04/2013]
(b) in such form and manner as the Director-General may determine.
[S 645/2017 wef 08/11/2017]
(2)  Where the application relates to any controlled import, controlled export or controlled transhipment, the applicant shall obtain the approval of the competent authority for that controlled import, controlled export or controlled transhipment.
(3)  The applicant shall
```

### `section:5` · section · Approval of competent authority

```text
5.—(1)  An application for the approval of the competent authority in relation to any controlled import, controlled export or controlled transhipment shall be made before any contract for the import, export or transhipment of the goods has been entered into.
(2)  Where approval is sought from the competent authority for the controlled import, controlled export or controlled transhipment, the competent authority may take samples of each consignment of goods for testing and analysis, and may specify the procedure to be adopted for such sampling, testing or analysis.
(3)  Any expenses incurred for or arising out of the sampling, testing or analysis and for the detention of goods pending the res
```

### `section:5A` · section · Permit for certain goods

```text
5A.—(1)  Subject to paragraph (2), goods originating from, or bound for, the Democratic People’s Republic of Korea, as the case may be, must not be —
(a) imported into Singapore;
(b) exported out of Singapore;
(c) transhipped in Singapore; or
(d) brought in transit through Singapore, except in accordance with a permit granted by the Director-General under this Part.
(2)  The requirement in paragraph (1) for a permit mentioned in that paragraph does not apply to goods that are —
(a) personal or household effects, not listed in the Seventh Schedule, which accompany passengers, crew or employees of transport undertakings by land, sea or air;
(b) diplomatic correspondence; or
(c) human corpses, 
```

### `section:5B` · section · Application for permit mentioned in regulation 5A

```text
5B.—(1)  An application for a permit mentioned in regulation 5A to import, export, tranship, or bring in transit, any goods is to be made to the Director-General —
(a) by the importer, exporter, shipping agent, air cargo agent, freight forwarder or common carrier, as the case may be, or the declarant mentioned in Part IVA; and
(b) in such form and manner as the Director-General may determine.
(2)  The applicant must provide the Director-General with any further document or information that the Director-General may require in any particular case.
(3)  The Director-General may, in any case in which the Director-General thinks fit, grant or refuse to grant any permit to import, export, tranship
```

