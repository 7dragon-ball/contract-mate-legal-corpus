# FLPA2012 · 外国时效期间法（2012）

- 语言：`en`
- 版本：`sg:FLPA2012:en:src-5d35f00ad285`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：10；切片：9；发布资格：否

PDF 页数 7，空白页 [2]，目录页 [1, 3]，条文 8。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE FOREIGN LIMITATION PERIODS ACT 2012 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Foreign Limitation Periods Act 2012 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Application of foreign limitation law 4. Exceptions 5. Foreign judgments on limitation points 6. Meaning of law relating to limitation 7. Application to Government 8. Transitional provision An Act to provide for any law relating to the limitation o
```

### `section:1` · section · 

```text
1. This Act is the Foreign Limitation Periods Act 2012. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, “country” includes a State or territory. Application of foreign limitation law
```

### `section:3` · section · Application of foreign limitation law

```text
3.—(1) Subject to the following provisions of this Act, where in any action or proceedings in a court in Singapore the law of any other country is required (in accordance with rules of private international law applicable by any such court) to be applied to determine any matter — 1
(a) the law of that other country relating to limitation applies in respect of that matter for the purposes of the action or proceedings; and
(b) the law of Singapore relating to limitation does not so apply.
(2) Where a foreign law is required to be considered for the purpose of actionability under a choice of law rule, that foreign law is deemed to apply under subsection (1).
(3) For the purposes of any law appl
```

### `section:4` · section · Exceptions

```text
4.—(1) In any case in which the application of section 3 would to any extent conflict with public policy, that section does not apply to the extent that its application would so conflict.
(2) The application of section 3 in relation to any action or proceedings conflicts with public policy to the extent that its application would cause undue hardship to a person who is, or might be made, a party to the action or proceedings.
(3) Where, under a law applicable by virtue of section 3 for the purposes of any action or proceedings, a limitation period is or may be extended or interrupted in respect of the absence of a party to the action or proceedings from any specified jurisdiction or country, 
```

### `section:5` · section · Foreign judgments on limitation points

```text
5. Where a court in any country outside Singapore has determined any matter wholly or partly by reference to the law of that or any other country (including Singapore) relating to limitation, then, for the purposes of the law relating to the effect to be given in Singapore to that determination, that court is, to the extent that it has so determined the matter, deemed to have determined it on its merits. Meaning of law relating to limitation
```

### `section:6` · section · Meaning of law relating to limitation

```text
6.—(1) References in this Act to the law of any country (including Singapore) relating to limitation are, in relation to any matter, to be construed as references to so much of the relevant law of that country as (in any manner) makes provision with respect to a limitation period applicable to the bringing of proceedings in respect of that matter in the courts of that country and include —
(a) references to so much of that law as relates to, and to the effect of, the application, extension, reduction or interruption of that period; and
(b) a reference, where under that law there is no limitation period which is so applicable, to the rule that such proceedings may be brought within an indefin
```

### `section:7` · section · Application to Government

```text
7. This Act binds the Government and applies in relation to any action or proceedings by or against the Government as it applies in relation to actions and proceedings to which the Government is not a party. 3 Transitional provision
```

