# EA1893 · 证据法（1893）

- 语言：`en`
- 版本：`sg:EA1893:en:src-82750c238a00`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：205；切片：212；发布资格：否

PDF 页数 129，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]，条文 201。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE EVIDENCE ACT 1893 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Evidence Act 1893 ARRANGEMENT OF SECTIONS
PART 1 RELEVANCY OF FACTS Section Preliminary Section 1. Short title 2. Application of Parts 1, 2 and 3 3. Interpretation 4. Presumptions Relevancy of facts 5. Evidence may be given of facts in issue and relevant facts 6. Relevancy of facts forming part of same transaction 7. Facts which are the occasion, cause or effect of fa
```

### `section:2` · section · 

```text
2.—(1) Parts 1, 2 and 3 apply to all judicial proceedings in or before any court, but not to affidavits presented to any court or officer nor to proceedings before an arbitrator.
(2) All rules of evidence not contained in any written law, so far as such rules are inconsistent with any of the provisions of this Act, are repealed. Interpretation
```

### `section:3` · section · Interpretation

```text
3.—(1) In Parts 1, 2 and 3, unless the context otherwise requires — “child abuse offence” means any offence specified in Part 1 of the First Schedule, and includes attempting to commit, abetting the commission of, or being a party to a criminal conspiracy to commit, such an offence; “copy of a document” includes —
(a) in the case of a document falling within paragraph (d) but not paragraph (e) of the definition of “document”, a transcript of the sounds or other data embodied in it;
(b) in the case of a document falling within paragraph (e) but not paragraph
(d) of that definition, a reproduction or still reproduction of the image or images embodied in it, whether enlarged or not;
(c) in the 
```

### `section:4` · section · Presumptions

```text
4.—(1) Whenever it is provided by this Act that the court may presume a fact, it may either regard such fact as proved unless and until it is disproved, or may call for proof of it.
(2) Whenever it is directed by this Act that the court is to presume a fact, the court is to regard such fact as proved unless and until it is disproved.
(3) When one fact is declared by this Act to be conclusive proof of another, the court is, on proof of the one fact, to regard the other as proved, and is not to allow evidence to be given for the purpose of disproving it. Relevancy of facts Evidence may be given of facts in issue and relevant facts
```

### `section:5` · section · Evidence may be given of facts in issue and relevant facts

```text
5. Evidence may be given in any suit or proceeding of the existence or non-existence of every fact in issue and of such other facts as are hereinafter declared to be relevant, and of no others. Explanation.—This section does not enable any person to give evidence of a fact which the person is disentitled to prove by any provision of the law for the time being in force relating to civil procedure. Illustrations 13
(a) A is tried for the murder of B by beating B with a club with the intention of causing B’s death. At A’s trial the following facts are in issue:
(i) A’s beating B with the club;
(ii) A’s causing B’s death by such beating;
(iii) A’s intention to cause B’s death.
(b) A, a party to 
```

### `section:6` · section · Relevancy of facts forming part of same transaction

```text
6. Facts which, though not in issue, are so connected with a fact in issue as to form part of the same transaction are relevant, whether they occurred at the same time and place or at different times and places. Illustrations
(a) A is accused of the murder of B by beating B. Whatever was said or done by A or B or the bystanders at the beating or so shortly before or after it as to form part of the transaction is a relevant fact.
(b) A is accused of waging war against the Government by taking part in an armed insurrection in which property is destroyed, troops are attacked and gaols are broken open. The occurrence of these facts is relevant as forming part of the general transaction, though A
```

### `section:7` · section · Facts which are the occasion, cause or effect of facts in is

```text
7. Facts which are the occasion, cause or effect, immediate or otherwise, of relevant facts or facts in issue, or which constitute the state of things under which they happened or which afforded an opportunity for their occurrence or transaction, are relevant. Illustrations
(a) The question is whether A robbed B. The facts that shortly before the robbery B went to a fair with money in B’s possession, and that B showed or mentioned the fact that B had it to third persons, are relevant.
(b) The question is whether A murdered B. Marks on the ground produced by a struggle at or near the place where the murder was committed are relevant facts.
(c) The question is whether A poisoned B. The state o
```

### `section:8` · section · Motive, preparation and previous or subsequent conduct

```text
8.—(1) Any fact is relevant which shows or constitutes a motive or preparation for any fact in issue or relevant fact.
(2) The conduct of any party or of any agent to any party to any suit or proceeding in reference to such suit or proceeding or in reference to any fact in issue therein or relevant thereto, and the conduct of any person an offence against whom is the subject of any proceeding, is relevant if such conduct influences or is influenced by any fact in issue or relevant fact, and whether it was previous or subsequent thereto. Explanation 1.—The word “conduct” in this section does not include statements unless those statements accompany and explain acts other than statements; but t
```

