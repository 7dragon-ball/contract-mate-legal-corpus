# SDA1929 · 印花税法 1929

- 语言：`en`
- 版本：`sg:SDA1929:en:src-67085ca34ecc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：145；切片：193；发布资格：否

PDF 页数 245，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7]，条文 138。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE STAMP DUTIES ACT 1929 2021 REVISED EDITION This revised edition incorporates all amendments up to and including 16 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Stamp Duties Act 1929 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Commissioner and Deputy Commissioners of Stamp Duties
PART 2 PROVISIONS APPLICABLE TO INSTRUMENTS GENERALLY Liability of instruments to duty 4. Instruments chargeable with duty Payment of duty 5. All facts and circumstances to be set out 6. Instrument rela
```

### `section:2` · section · 

```text
2.—(1) In this Act, unless the context otherwise requires — “bare trust beneficiary”, in relation to a trust over property, means a person —
(a) who is identified in the declaration of trust as a beneficiary of that property; and
(b) who, upon the declaration of the trust, has beneficial ownership of that property;
[Act 22 of 2022 wef 10/05/2022] “Commissioner” means the Commissioner of Stamp Duties appointed under this Act; “company” means any company incorporated or registered under any law in force in Singapore or elsewhere; “conveyance on sale” includes every instrument and every decree or order of any court, by which any property, or any estate or interest in any property, upon the sale
```

### `section:3` · section · Commissioner and Deputy Commissioners of Stamp Duties

```text
3.—(1) The Minister may appoint an officer to carry out the provisions of this Act, to be called the Commissioner of Stamp Duties, and such number of Deputy Commissioners of Stamp Duties as the Minister thinks fit.
[Act 5 of 2025 wef 09/03/2025]
(1A) An appointment under subsection (1) must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025]
(2) Every Deputy Commissioner of Stamp Duties has and may exercise all the powers of the Commissioner under the provisions of this Act except subsection (3) and sections 40(3) and 68(1).
(3) The Commissioner may, subject to such conditions or restrictions as the Commissioner thinks fit, delegate to any person having official duty or employed in t
```

### `section:4` · section · Instruments chargeable with duty

```text
4.—(1) Subject to the provisions of this Act and any other written law, every instrument mentioned in the First Schedule, being an instrument —
(a) which, not having been previously executed by any person, is executed in Singapore; or 10
(b) which is executed outside Singapore, and relates to any property situated, or to any matter or thing done or to be done, in Singapore, and is received in Singapore, is chargeable with duty of the amount specified in that Schedule as the proper duty for that instrument.
(2) All instruments chargeable with duty must be duly stamped. Payment of duty All facts and circumstances to be set out
```

### `section:5` · section · All facts and circumstances to be set out

```text
5.—(1) All the facts and circumstances affecting the liability of any instrument to duty or the amount of the duty with which any instrument is chargeable are to be fully and truly set out in the instrument.
(2) Where the liability of an instrument to duty or any amount of duty, is determined by facts or circumstances that are not set out in the instrument, those facts or circumstances must be provided to the Commissioner in such form and manner as the Commissioner may specify.
[13/2017]
(3) The Commissioner may require to be furnished with such evidence as the Commissioner may consider necessary to prove that all such facts and circumstances are truly set out in the instrument or provided u
```

### `section:6` · section · Instrument relating to distinct matters

```text
6. Except where express provision to the contrary is made by this Act or any other Act —
(a) an instrument containing or relating to several distinct matters is to be separately and distinctly charged, as if it were a separate instrument, with duty in respect of each of the matters; and
(b) an instrument made for any consideration in respect of which it is chargeable with ad valorem duty, and also for any further or other valuable consideration or 11 considerations, is to be separately and distinctly charged, as if it were a separate instrument, with duty in respect of each of the considerations. How duties are denoted
```

### `section:6A` · section · How duties are denoted

```text
6A. Except where express provision is made to the contrary in this Act, all duties chargeable on any instrument are to be paid and denoted by attaching to the instrument a stamp certificate relating to the instrument. E‑Stamping system
```

### `section:6B` · section · E‑Stamping system

```text
6B.—(1) The computer service known as the E‑Stamping system and established under section 6B as in force immediately before 4 October 2018, may be used for the purposes mentioned in subsection (2).
[37/2018]
(2) The purposes are to enable any person, in accordance with the arrangements made under this section —
(a) to do the following without the need to present the instrument concerned to the Commissioner or a proper officer in charge of the stamp office:
(i) obtain an assessment of stamp duty (and any penalty) on an instrument;
(ii) pay stamp duty (and any penalty) on the instrument by electronic funds transfer in accordance with the assessment;
(iii) stamp the instrument by attaching a st
```

