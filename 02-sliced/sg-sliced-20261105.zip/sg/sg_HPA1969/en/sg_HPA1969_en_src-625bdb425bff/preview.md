# HPA1969 · 租购法（1969）

- 语言：`en`
- 版本：`sg:HPA1969:en:src-625bdb425bff`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：73；切片：73；发布资格：否

PDF 页数 54，空白页 [2]，目录页 [1, 3, 4, 5, 6]，条文 66。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE HIRE-PURCHASE ACT 1969 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Hire-Purchase Act 1969 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and application 2. Interpretation
PART 2 FORM AND CONTENTS OF REGULATED AGREEMENTS 3. Requirements relating to regulated agreements 4. Copy of documents to be served on hirer 5. Regulated agreements which are not enforceable
PART 3 IMPLIED TERMS 6. Implied terms as to title 6
```

### `section:1` · section · 

```text
1.—(1) This Act is the Hire-Purchase Act 1969.
(2) This Act shall apply to hire-purchase agreements or conditional sale agreements made on or after 1 September 2012.
(3) In the case of agreements made before 1 September 2012, this Act shall continue to apply as if section 9 of the Consumer Protection (Fair Trading) (Amendment) Act 2012 had not been enacted.
(4) The Minister may by order amend, vary, delete or add to any of the Schedules.
(5) The Minister may, in any order made under subsection (4), make such transitional and savings provisions as he may consider necessary or expedient. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act — “action” includes counterclaim and set-off; “business day” means any day other than a Saturday, Sunday or public holiday; “cash” includes a cheque drawn on a banker; “certificate of entitlement” means a permit issued by the Registrar of Vehicles under section 10A of the Road Traffic Act 1961; “conditional sale agreement” means an agreement for the sale of goods under which the purchase price or part of it is payable by instalments, and the property in the goods is to remain in the owner (notwithstanding that the hirer is to be in possession of the goods) until such conditions as to the payment of instalments or otherwise as may be specified in that agreement are fulfille
```

### `section:3` · section · Requirements relating to regulated agreements

```text
3.—(1) Before a regulated agreement is entered into in respect of any goods, the owner shall give or cause to be given to the prospective hirer a written statement which shall contain the items set out in the Second Schedule.
(2) Where a regulated agreement is entered into by way of acceptance by the owner of a written offer signed by or on behalf of the hirer, subsection (1) shall be deemed not to have been complied with unless the written statement was given to the prospective hirer before the written offer was signed.
(3) Every regulated agreement —
(a) shall be in writing and in the English language;
(b) shall be signed by or on behalf of the hirer and all other parties to the agreement;
```

### `section:4` · section · Copy of documents to be served on hirer

```text
4.—(1) The owner shall serve or cause to be served on the hirer within 7 business days after the making of a regulated agreement —
(a) a copy of the agreement; and
(b) a notice, which is at least as prominent as the rest of the contents of the agreement, in the terms prescribed in the Third Schedule.
(2) Where any part of the total amount payable consists of an amount paid or to be paid under a policy of insurance in respect of the goods, the owner shall serve or cause to be served on the hirer within 7 days of receipt of the policy, a copy of the policy or statement in writing setting out the terms, conditions and exclusions of the policy that affect the rights of the hirer. Regulated agree
```

### `section:5` · section · Regulated agreements which are not enforceable

```text
5.—(1) A regulated agreement that is not in writing shall not be enforceable by the owner. 9
(2) An owner shall not be entitled to enforce a regulated agreement or any contract of guarantee relating to a regulated agreement or any right to recover the goods from the hirer, and no security given by the hirer in respect of money payable under the regulated agreement or given by a guarantor in respect of money payable under such a contract of guarantee shall be enforceable against the hirer or guarantor by any holder of the security, unless the requirements set out in sections 3(3)(b) to (e) and 4 have been complied with.
(3) Notwithstanding subsection (2), where the court is satisfied that —
(
```

### `section:6` · section · Implied terms as to title

```text
6.—(1) In every hire-purchase agreement, other than one to which subsection (2) applies, there is —
(a) an implied term on the part of the owner that he will have a right to sell the goods at the time when the property is to pass; and
(b) an implied term that —
(i) the goods are free, and will remain free until the time when the property is to pass, from any charge or encumbrance not disclosed or known to the hirer; and
(ii) the hirer will enjoy quiet possession of the goods except so far as it may be disturbed by any person 10 entitled to the benefit of any charge or encumbrance so disclosed or known.
(2) In a hire-purchase agreement, in the case of which there appears from the agreement or
```

### `section:6A` · section · Bailing or hiring by description

```text
6A.—(1) Where under a hire-purchase agreement goods are bailed by description, there is an implied term that the goods will correspond with the description, and if under the agreement the goods are bailed by reference to a sample as well as a description, it is not sufficient that the bulk of the goods corresponds with the sample if the goods do not also correspond with the description.
(2) The term implied by subsection (1) is a condition.
(3) Goods shall not be prevented from being bailed by description by reason only that, being exposed for sale or bailment, they are selected by the hirer. 11 Implied undertakings as to quality or fitness
```

