# BEA1949 · 汇票法（1949）

- 语言：`en`
- 版本：`sg:BEA1949:en:src-edef9d902f3e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：106；切片：105；发布资格：否

PDF 页数 59，空白页 [2]，目录页 [1, 3, 4, 5, 6, 7, 8]，条文 104。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE BILLS OF EXCHANGE ACT 1949 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Bills of Exchange Act 1949 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 BILLS OF EXCHANGE Form and interpretation 3. Bill of exchange defined 4. Inland and foreign bills 5. Effect where different parties to bill are the same person 6. Address to drawee 7. Certainty required as to payee 8. What bills are negotiable
```

### `section:3` · section · 

```text
3.—(1) A bill of exchange is an unconditional order in writing, addressed by one person to another, signed by the person giving it, requiring the person to whom it is addressed to pay on demand or at a fixed or determinable future time a sum certain in money to, or to the order of, a specified person, or to bearer.
(2) An instrument which does not comply with these conditions, or which orders any act to be done in addition to the payment of money, is not a bill of exchange. 6
(3) An order to pay out of a particular fund is not unconditional within the meaning of this section.
(4) An unqualified order to pay, coupled with —
(a) an indication of a particular fund out of which the drawee is to 
```

### `section:4` · section · Inland and foreign bills

```text
4.—(1) An inland bill is a bill which is, or on the face of it purports to be —
(a) both drawn and payable within Singapore; or
(b) drawn within Singapore upon some person resident in Singapore.
(2) Any other bill is a foreign bill.
(3) Unless the contrary appears on the face of the bill, the holder may treat it as an inland bill. Effect where different parties to bill are the same person
```

### `section:5` · section · Effect where different parties to bill are the same person

```text
5.—(1) A bill may be drawn payable to, or to the order of, the drawer; or it may be drawn payable to, or to the order of, the drawee.
(2) Where in a bill, drawer and drawee are the same person or where the drawee is a fictitious person or a person not having capacity to contract, the holder may treat the instrument, at his option, either as a bill of exchange or as a promissory note. 7 Address to drawee
```

### `section:6` · section · Address to drawee

```text
6.—(1) The drawee must be named or otherwise indicated in a bill with reasonable certainty.
(2) A bill may be addressed to 2 or more drawees whether they are partners or not, but an order addressed to 2 drawees in the alternative or to 2 or more drawees in succession is not a bill of exchange. Certainty required as to payee
```

### `section:7` · section · Certainty required as to payee

```text
7.—(1) Where a bill is not payable to bearer, the payee must be named or otherwise indicated therein with reasonable certainty.
(2) A bill may be made payable to 2 or more payees jointly, or it may be made payable in the alternative to one of 2, or one or some of several payees.
(3) A bill may also be made payable to the holder of an office for the time being.
(4) Where the payee is a fictitious or non-existing person the bill may be treated as payable to bearer. What bills are negotiable
```

### `section:8` · section · What bills are negotiable

```text
8.—(1) When a bill contains words prohibiting transfer, or indicating an intention that it should not be transferable, it is valid as between the parties thereto, but is not negotiable.
(2) A negotiable bill may be payable either to order or to bearer.
(3) A bill is payable to bearer which is expressed to be so payable, or on which the only or last indorsement is an indorsement in blank.
(4) A bill is payable to order which is expressed to be so payable, or which is expressed to be payable to a particular person, and does not contain words prohibiting transfer or indicating an intention that it should not be transferable.
(5) Where a bill, either originally or by indorsement, is expressed to
```

### `section:9` · section · Sum payable

```text
9.—(1) The sum payable by a bill is a sum certain within the meaning of this Act, although it is required to be paid —
(a) with interest;
(b) by stated instalments;
(c) by stated instalments, with a provision that upon default in payment of any instalment the whole shall become due;
(d) according to an indicated rate of exchange or according to a rate of exchange to be ascertained as directed by the bill.
(2) Where the sum payable is expressed in words and also in figures, and there is a discrepancy between the 2, the sum denoted by the words is the amount payable.
(3) Where a bill is expressed to be payable with interest, unless the instrument otherwise provides, interest runs from the date
```

