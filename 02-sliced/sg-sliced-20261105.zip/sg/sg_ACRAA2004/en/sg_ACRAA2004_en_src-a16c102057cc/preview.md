# ACRAA2004 · 会计与企业监管局法 2004

- 语言：`en`
- 版本：`sg:ACRAA2004:en:src-a16c102057cc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：108；切片：109；发布资格：否

PDF 页数 88，空白页 []，目录页 [1, 2, 3, 4, 5]，条文 100。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ACCOUNTING AND CORPORATE REGULATORY AUTHORITY ACT 2004 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Accounting and Corporate Regulatory Authority Act 2004 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 ESTABLISHMENT, INCORPORATION AND CONSTITUTION OF AUTHORITY 3. Establishment and incorporation of Accounting and Corporate Regulatory Authority 4. Common seal 5. Constitution of Authority

```

### `section:1` · section · 

```text
1. This Act is the Accounting and Corporate Regulatory Authority Act 2004. 4 Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “Authority” means the Accounting and Corporate Regulatory Authority established under section 3; “Chairperson” means the Chairperson of the Authority appointed under section 5(1)(a) and includes any temporary Chairperson of the Authority; “chartered accountant” means a person registered or deemed to be registered as a Chartered Accountant of Singapore under Part 6B;
[Act 36 of 2022 wef 01/04/2023] “Chief Executive” means the Chief Executive of the Authority, and includes any individual acting in that capacity; “debenture” includes debenture stock; “Deputy Chairperson” means any person who is appointed under section 5(3)(a) to be the
```

### `section:3` · section · Regulatory Authority

```text
3. A body called the Accounting and Corporate Regulatory Authority is established, which is a body corporate with perpetual succession and is by that name capable of —
(a) suing and being sued;
(b) acquiring, owning, holding and developing or disposing of property, both movable and immovable; and
(c) doing and suffering any other acts or things that bodies corporate may lawfully do and suffer. Common seal
```

### `section:4` · section · Common seal

```text
4.—(1) The Authority must have a common seal and such seal may be broken, changed, altered or made anew as the Authority thinks fit.
(2) All deeds and other documents requiring the seal of the Authority must be sealed with the common seal of the Authority.
(3) All instruments to which the common seal is affixed must be signed by any 2 members generally or specially authorised by the Authority for the purpose or by one member and the Chief Executive. 6
(4) All courts, judges and persons acting judicially are to take judicial notice of the common seal of the Authority affixed to any document and presume that it was duly affixed. Constitution of Authority
```

### `section:5` · section · Constitution of Authority

```text
5.—(1) The Authority consists of the following members, all of whom must be appointed by the Minister:
(a) a Chairperson;
(b) not less than 10 but not more than 15 other members.
(2) The members appointed under subsection (1)(b) are to include —
(a) one public accountant to be selected by the Minister from a list of at least 2 public accountants nominated by each designated professional accountancy body; and
(b) one non-practising accountant to be selected by the Minister from a list of at least 2 non‑practising accountants nominated by each designated professional accountancy body.
[18/2014]
(3) The Minister may appoint —
(a) a member of the Authority to be its Deputy Chairperson; and
(b) t
```

### `section:6` · section · Functions of Authority

```text
6.—(1) Subject to the provisions of this Act, the functions of the Authority are —
(a) to administer the written laws specified in the Second Schedule;
(b) to report and make recommendations to, and advise the Government on, matters relating to —
(i) the registration and regulation of business entities and public accountants; and
(ii) the growth and development of the accountancy sector and its related fields in Singapore;
[Act 36 of 2022 wef 01/04/2023]
(c) to establish and administer a repository of information and documents relating to business entities and accounting entities and to provide access to such information and documents in accordance with this Act, the scheduled laws and the d
```

### `section:7` · section · Powers of Authority

```text
7.—(1) The Authority has power to do anything for the purpose of discharging its functions under this Act or any other written law, or which is incidental or conducive to the discharge of those functions.
(2) Without limiting subsection (1) but subject to this Act, the powers of the Authority include the power —
(a) to enter into any contracts, agreements or arrangements that may be necessary or expedient for the purpose of discharging its functions;
[Act 36 of 2022 wef 01/04/2023]
(b) with the approval of the Minister, to form or participate in the formation of any company, association, trust or partnership or in any joint venture as a shareholder or partner or in any other capacity, with a
```

