# CA2021 · 版权法（2021）

- 语言：`en`
- 版本：`sg:CA2021:en:src-e3809cec7d7d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：542；切片：542；发布资格：否

PDF 页数 349，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]，条文 540。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE COPYRIGHT ACT 2021 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Copyright Act 2021 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. Application to things existing before 21 November 2021 3. Extension of Act to reciprocating countries 4. Exclusion of non‑reciprocating countries from Act 5. Saving for other laws 6. Act binds Government
PART 2 INTERPRETATION
Division 1 — General 7. General interp
```

### `section:1` · section · 

```text
1.—(1) This Act is the Copyright Act 2021.
(2) Division 2 of Part 9 and sections 501(2) and (3) and 507(4)(c) and (10) come into operation on a date that the Minister appoints by notification in the Gazette. Application to things existing before 21 November 2021
```

### `section:2` · section · Application to things existing before 21 November 2021

```text
2. Unless it expressly provides otherwise, this Act applies to a thing existing on 21 November 2021 as it applies to a thing coming into existence after that date. 24 Extension of Act to reciprocating countries
```

### `section:3` · section · Extension of Act to reciprocating countries

```text
3.—(1) Subject to subsection (2), regulations may prescribe that —
(a) a country is a reciprocating country; and
(b) this Act is extended so as to apply in relation to the country or its nationals —
(i) generally or for specified classes of cases; and
(ii) with or without modifications or exceptions.
(2) A country may be prescribed as a reciprocating country only if —
(a) in relation to works protected by copyright under the provisions of this Act —
(i) the country and Singapore are both parties to a treaty, convention or other international agreement relating to copyright; or
(ii) the Minister is satisfied that those works are or will be adequately protected under the law of the country; an
```

### `section:4` · section · Exclusion of non‑reciprocating countries from Act

```text
4.—(1) Subject to subsection (2), regulations may prescribe that —
(a) a country is a non‑reciprocating country; and
(b) either —
(i) this Act does not apply in relation to the country or its nationals, whether generally or for specified classes of cases; or
(ii) the application of this Act in relation to the country or its nationals is subject to modifications or exceptions.
(2) A country may be prescribed as a non‑reciprocating country only if the Minister considers that the law of the country does not give adequate protection to —
(a) works (or any class of works) protected by copyright under this Act; or
(b) performances (or any class of performances) protected under this Act.
(3) Withou
```

### `section:5` · section · Saving for other laws

```text
5.—(1) Unless it expressly provides otherwise, this Act does not affect any right or privilege of any person (including the Government) under any other written law.
(2) This Act does not affect the operation of the law relating to breaches of trust or confidence. Act binds Government
```

### `section:6` · section · Act binds Government

```text
6.—(1) Unless it expressly provides otherwise, this Act binds the Government.
(2) The Government is not liable to be prosecuted for an offence under this Act.
PART 2 INTERPRETATION
Division 1 — General General interpretation
```

### `section:7` · section · General interpretation

```text
7.—(1) In this Act, unless the context otherwise requires — “1911 Act” means the Copyright Act 1911 of the United Kingdom (U.K. 1911, c. 46) insofar as that Act has effect as part of the law of Singapore; “1987 Act” means the Copyright Act (Cap. 63, 2006 Revised Edition) repealed by this Act; “action” means a civil action and includes a counterclaim; “adaptation” —
(a) in relation to a literary or dramatic work, has the meaning given by section 17; and
(b) in relation to a musical work, has the meaning given by section 18; “archive” has the meaning given by section 92; “article” includes a copy, in electronic form, of a work; 27 “artistic work” has the meaning given by section 20(1); “author
```

