# TSFA2002 · 制止资助恐怖主义法（2002）

- 语言：`en`
- 版本：`sg:TSFA2002:en:src-7f2c797cbdbd`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：54；切片：56；发布资格：否

PDF 页数 45，空白页 []，目录页 [1, 2, 3, 4]，条文 50。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE TERRORISM (SUPPRESSION OF FINANCING) ACT 2002 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Terrorism (Suppression of Financing) Act 2002 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 TERRORIST PROPERTY 3. Prohibition against providing or collecting property for terrorist acts 4. Prohibition against provision of property and services for terrorist purposes 5. Prohibition against use or 
```

### `section:1` · section · 

```text
1. This Act is the Terrorism (Suppression of Financing) Act 2002. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “entity” means a person, group, trust, partnership or fund or an unincorporated association or organisation; “police officer” includes a Commercial Affairs Officer mentioned in section 64 of the Police Force Act 2004; “property” means —
(a) assets of every kind, whether tangible or intangible, movable or immovable, however acquired; and
(b) legal documents or instruments in any form, including electronic or digital, evidencing title to, 3 or interest in, such assets, including, but not limited to, bank credits, travellers cheques, bank cheques, money orders, shares, securities, bonds, drafts and letters of credit; “terrorism financi
```

### `section:3` · section · terrorist acts

```text
3.—(1) Every person who directly or indirectly, wilfully and without lawful excuse, provides or collects property —
(a) with the intention that the property be used; or
(b) knowing or having reasonable grounds to believe that the property will be used, in whole or in part, in order to commit any terrorist act, shall be guilty of an offence.
[17/2013; 51/2018]
(2) Any person who acts reasonably in taking, or omitting to take, measures to avoid committing an offence under subsection (1) shall not be liable in any civil proceedings arising from taking or omitting to take those measures.
[51/2018] 6 Prohibition against provision of property and services for terrorist purposes
```

### `section:4` · section · terrorist purposes

```text
4.—(1) Every person who directly or indirectly, collects property, provides or invites a person to provide, or makes available property or financial or other related services —
(a) intending that they be used, or knowing or having reasonable grounds to believe that they will be used, in whole or in part, for the purpose of facilitating or carrying out any terrorist act, or for benefiting any person who is facilitating or carrying out such an activity; or
(b) knowing or having reasonable grounds to believe that, in whole or in part, they will be used by or will benefit any terrorist or terrorist entity, shall be guilty of an offence.
[17/2013; 51/2018]
(2) Any person who acts reasonably in ta
```

### `section:5` · section · purposes

```text
5.—(1) Every person who —
(a) uses property, directly or indirectly, in whole or in part, for the purpose of facilitating or carrying out any terrorist act; or
(b) possesses property intending that it be used or knowing or having reasonable grounds to believe that it will be used, 7 directly or indirectly, in whole or in part, for the purpose of facilitating or carrying out a terrorist act, shall be guilty of an offence.
[17/2013; 51/2018]
(2) Any person who acts reasonably in taking, or omitting to take, measures to avoid committing an offence under subsection (1) shall not be liable in any civil proceedings arising from taking or omitting to take those measures.
[51/2018] Prohibition again
```

### `section:6` · section · Prohibition against dealing with property of terrorists

```text
6.—(1) No person in Singapore and no citizen of Singapore outside Singapore may —
(a) deal, directly or indirectly, in any property that the person knows or has reasonable grounds to believe is owned or controlled by or on behalf of any terrorist or terrorist entity, including funds derived or generated from property owned or controlled, directly or indirectly, by any terrorist or terrorist entity;
(b) enter into or facilitate, directly or indirectly, any financial transaction related to a dealing in property mentioned in paragraph (a); or
(c) provide any financial services or any other related services in respect of any property mentioned in paragraph (a) to, or for the benefit of, or on th
```

### `section:6A` · section · Penalty

```text
6A. Any person who is guilty of an offence under section 3, 4, 5 or 6 shall be liable on conviction —
(a) in the case of an individual, to a fine not exceeding $500,000 or to imprisonment for a term not exceeding 10 years or to both; or
(b) in any other case, to a fine not exceeding the higher of —
(i) $1 million; or
(ii) twice the value of the property (including funds derived or generated from the property), financial services or other related services, or financial transaction (as the case may be) in respect of which the offence was committed.
[17/2013; 51/2018] Abetment, etc., of offence under section 3, 4, 5 or 6
```

