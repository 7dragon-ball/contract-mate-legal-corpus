# HPA2007 · 健康产品法 2007

- 语言：`en`
- 版本：`sg:HPA2007:en:src-cc3906e13890`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：82；切片：86；发布资格：否

PDF 页数 86，空白页 []，目录页 [1, 2, 3, 4, 5, 6]，条文 78。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE HEALTH PRODUCTS ACT 2007 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Health Products Act 2007 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. Interpretation 3. Purposes of Act 4. Act to apply only to health products specified in First Schedule 5. Act not to apply to supply or use of health products and active ingredients for veterinary purposes
PART 2 ADMINISTRATION 6. Administration of Act 
```

### `section:1` · section · 

```text
1.—(1) This Act is the Health Products Act 2007.
(2) Part 14 comes into operation on such date as the Minister charged with the responsibility for national development may, by notification in the Gazette, appoint. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “active ingredient” means any substance or compound that is usable in the manufacture of a health product as a pharmacologically active constituent; “adverse effect”, in relation to a health product, means any debilitating, harmful, toxic or detrimental effect that the health product has been found to have or to be likely to have on the body or health of humans when the health product is used by or administered to humans; “advertisement”, in relation to a health product, means the publication, dissemination or conveyance of any information for the purpose of promoting, whether directly or indirectly, the sale or use of that health p
```

### `section:3` · section · Purposes of Act

```text
3. The purposes of this Act are —
(a) to provide for the categorisation of health products in accordance with their different characteristics and uses;
(b) to provide the framework for a uniform approach for —
(i) the registration of health products; and
(ii) the regulation of the manufacture, import, supply, storage, presentation and advertisement of health products;
(c) to allow for each category of health products to be registered and regulated by reference to its formulation, composition, design specification, quality, safety and 13 efficacy and within the framework provided by this Act; and
(d) to prescribe the standards for health products in relation to their formulation, composition,
```

### `section:4` · section · Act to apply only to health products specified in First Sche

```text
4.—(1) Except for and as provided in Part 14, this Act applies only in relation to the categories of health products that are specified and described in the first and second columns of the First Schedule to the extent prescribed in the third column thereof.
(2) The Minister may, after consulting the Authority, by order in the Gazette add to, amend or vary the categories and descriptions of health products in the First Schedule and the extent to which the provisions of this Act apply to those health products.
(3) In prescribing the extent to which this Act applies to any category of health products, the Minister may, in the third column of the First Schedule, specify the provisions or any par
```

### `section:5` · section · ingredients for veterinary purposes

```text
5. Except as provided in Part 14, this Act does not apply in relation to the supply or use by a veterinarian of any health product or active ingredient for veterinary purposes.
PART 2 ADMINISTRATION Administration of Act
```

### `section:6` · section · Administration of Act

```text
6. The Authority is responsible for the administration and enforcement of this Act (except for Part 14) subject to the general and special directions of the Minister. 14 Appointment of enforcement officers
```

### `section:7` · section · Appointment of enforcement officers

```text
7.—(1) The Chief Executive may in writing appoint —
(a) any officer of the Authority; or
(b) with the approval of the Authority, any other person, to be an enforcement officer for the purposes of this Act.
(2) Every enforcement officer, when exercising his or her powers and carrying out his or her duties under this Act, must comply with such general or special directions as may, from time to time, be given to him or her by the Chief Executive.
(3) Every enforcement officer when exercising any of his or her powers under this Act must, if not in uniform, declare his or her office and must, on demand, produce to any person affected by the exercise of that power such identification card as the A
```

