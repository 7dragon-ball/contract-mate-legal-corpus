# SCMA2020 · 新加坡调解公约法（2020）

- 语言：`en`
- 版本：`sg:SCMA2020:en:src-5d87aa1bd54b`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：55；切片：54；发布资格：否

PDF 页数 21，空白页 []，目录页 [1, 2]，条文 52。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE SINGAPORE CONVENTION ON MEDIATION ACT 2020 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Singapore Convention on Mediation Act 2020 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Application of Act 4. Applications in respect of international settlement agreements 5. Grant of permission to record international settlement agreement as order of High Court 6. Requirements for applications under section 4 7. Ground
```

### `section:1` · section · 

```text
1. This Act is the Singapore Convention on Mediation Act 2020. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “Convention” means the United Nations Convention on International Settlement Agreements Resulting from 1 Mediation, also known as the Singapore Convention on Mediation, opened for signature on 7 August 2019 in Singapore, a copy of the English text of which is set out in the Schedule; “international settlement agreement” means a settlement agreement to which this Act applies under section 3; “mediation” means a process (whether referred to by the expression “mediation” or “conciliation” or any term of similar import) —
(a) by which the parties to the mediation attempt to reach an amicable settlement of their dispute with the assistan
```

### `section:3` · section · Application of Act

```text
3.—(1) Subject to subsection (2), this Act applies to a settlement agreement which, at the time of its conclusion, is international within the meaning of article 1, paragraph 1(a) and (b), read with article 2, paragraph 1, of the Convention.
(2) This Act does not apply to —
(a) a settlement agreement mentioned in article 1, paragraph 2 or 3 of the Convention; or
(b) a settlement agreement in relation to which a reservation by Singapore under article 8 of the Convention has been made and the reservation is not withdrawn.
(3) Articles 12 and 13 of the Convention apply to the interpretation of the articles of the Convention mentioned in subsections (1) and (2).
(4) This Act binds the Government
```

### `section:4` · section · Applications in respect of international settlement agreemen

```text
4.—(1) Subject to this Act, a party to an international settlement agreement may —
(a) apply to the High Court to record the agreement as an order of court for the purposes of —
(i) enforcing the agreement in Singapore; or
(ii) invoking the agreement in any court proceedings in Singapore involving a dispute concerning a matter that the party to the international settlement agreement claims was already resolved by the agreement, in order to prove that the matter has already been resolved; or
(b) in any proceedings in the High Court (whether exercising its original or appellate jurisdiction), or in any proceedings in the Court of Appeal — 3
(i) to which the party to the international settlemen
```

### `section:5` · section · agreement as order of High Court

```text
5.—(1) The High Court may, following an application under section 4(1)(a), grant permission to record an international settlement agreement as an order of court if the requirements of this Act are complied with.
[Act 25 of 2021 wef 01/04/2022]
(2) Subject to this Act, an international settlement agreement that is recorded by the High Court as an order of court —
(a) may be enforced in the same manner as a judgment given, or an order made, by the High Court; and
(b) may be relied on by the party who made the application under section 4(1)(a) by way of defence, set-off or otherwise in any court proceedings.
[Act 25 of 2021 wef 01/04/2022] Requirements for applications under section 4
```

### `section:6` · section · Requirements for applications under section 4

```text
6.—(1) A party to an international settlement agreement making an application mentioned in section 4(1) must provide to the court before which the application is made the following documents and evidence:
(a) the international settlement agreement signed by the parties to the agreement or a certified copy of the signed agreement; 4
(b) evidence that the international settlement agreement resulted from mediation, such as —
(i) the signature on the international settlement agreement of the mediator conducting the mediation;
(ii) a document signed by the mediator conducting the mediation indicating that the mediation was carried out;
(iii) an attestation by the institution that administered the
```

### `section:7` · section · Grounds for refusing application

```text
7.—(1) The court before which an application mentioned in section 4(1) is made may, at the request of the party (A) against whom the international settlement agreement is sought to be enforced or invoked, refuse to grant the application if A furnishes proof of any of the grounds set out in subsection (2).
(2) For the purposes of subsection (1), the grounds are the following:
(a) that a party to the international settlement agreement was under some incapacity;
(b) that the international settlement agreement —
(i) is null and void, inoperative or incapable of being performed under the law to which the parties have validly subjected it or, failing any indication thereon, under the law deemed ap
```

