# CDTOSCCBA1992 · 贪污、贩毒及其他严重罪行（没收利益）法（1992）

- 语言：`en`
- 版本：`sg:CDTOSCCBA1992:en:src-4ab7acf47333`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：142；切片：160；发布资格：否

PDF 页数 201，空白页 []，目录页 [1, 2, 3, 4, 5, 6]，条文 136。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CORRUPTION, DRUG TRAFFICKING AND OTHER SERIOUS CRIMES (CONFISCATION OF BENEFITS) ACT 1992 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Corruption, Drug Trafficking and Other Serious Crimes (Confiscation of Benefits) Act 1992 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. General interpretation 3. Meaning of “item subject to legal privilege” 4. Application 5. Suspicious Transaction Reporting Office
PART 2 CON
```

### `section:1` · section · 

```text
1. This Act is the Corruption, Drug Trafficking and Other Serious Crimes (Confiscation of Benefits) Act 1992. General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “authorised officer” means —
(a) any officer of the Bureau;
(b) any special investigator of the Corrupt Practices Investigation Bureau appointed under section 3(2) of the Prevention of Corruption Act 1960;
(c) any Commercial Affairs Officer appointed under section 64 of the Police Force Act 2004;
(d) any police officer; and
(e) any other person authorised in writing by the Minister for the purposes of this Act; “bank” means a bank licensed under the Banking Act 1970; “charging order” means an order made under section 20(1); “confiscation order” means an order made under section 6 or 7; “corresponding law” means a law of a foreign co
```

### `section:3` · section · Meaning of “item subject to legal privilege”

```text
3.—(1) For the purposes of this Act, an item is subject to legal privilege if —
(a) it is a communication made between a lawyer and a client, or a legal counsel acting as such and his or her employer, in connection with the lawyer giving legal advice to the client or the legal counsel giving legal advice to the employer, as the case may be;
(b) it is a communication made between 2 or more lawyers acting for a client, or 2 or more legal counsel acting as such for their employer, in connection with one or more of the lawyers giving legal advice to the client or one or more of the legal counsel giving legal advice to the employer, as the case may be;
(c) it is a communication made —
(i) between
```

### `section:4` · section · Application

```text
4.—(1) This Act applies to any drug dealing offence or foreign drug dealing offence whether committed before or after 30 November 1993.
[21/2014]
(2) Nothing in this Act imposes any duty or confer any power on any court in or in connection with any proceedings under this Act against a person for a drug dealing offence in respect of which the person has been convicted by a court before 30 November 1993.
[21/2014]
(3) This Act applies to any serious offence or foreign serious offence whether committed before or after 13 September 1999.
(4) Nothing in this Act imposes any duty or confers any power on any court in connection with any proceedings under this Act against a person for a serious offe
```

### `section:5` · section · Suspicious Transaction Reporting Office

```text
5.—(1) There is to be an office of the Government called the Suspicious Transaction Reporting Office which is responsible for — 13
(a) the receipt and analysis of —
(i) any thing disclosed to a Suspicious Transaction Reporting Officer pursuant to a requirement under subsection (3) or pursuant to section 45(1);
(ii) any report under section 60 given to a Suspicious Transaction Reporting Officer under section 60(4) or forwarded to a Suspicious Transaction Reporting Officer under section 61;
(iii) any report under section 62 given to a Suspicious Transaction Reporting Officer under section 62(4);
(iv) any cash transaction report submitted to a Suspicious Transaction Reporting Officer under sect
```

### `section:6` · section · Confiscation orders for benefits derived from drug dealing

```text
6.—(1) Subject to section 30, where a defendant is convicted of one or more drug dealing offences, the court must, on the application of the Public Prosecutor, make a confiscation order against the defendant in respect of benefits derived by the defendant from drug dealing if the court is satisfied that those benefits have been so derived.
[21/2014]
(2) If the court is satisfied that benefits have been derived by the defendant from drug dealing, the court must, at any time after sentencing or otherwise dealing with the defendant in respect of the offence or any of the offences concerned (as the case may be), determine in accordance with section 13 the amount to be recovered in the defendant’
```

### `section:7` · section · Confiscation orders for benefits derived from criminal condu

```text
7.—(1) Subject to section 30, where a defendant is convicted of one or more serious offences, the court must, on the application of the Public Prosecutor, make a confiscation order against the defendant in respect of benefits derived by the defendant from criminal conduct if the court is satisfied that those benefits have been so derived.
(2) If the court is satisfied that benefits have been derived by the defendant from criminal conduct, the court must, at any time after sentencing or otherwise dealing with the defendant in respect of the offence or any of the offences concerned (as the case may be), determine in accordance with section 13 the amount to be recovered in the defendant’s case 
```

