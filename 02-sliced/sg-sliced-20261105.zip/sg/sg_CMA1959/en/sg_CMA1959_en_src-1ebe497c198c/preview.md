# CMA1959 · 制造控制法 1959

- 语言：`en`
- 版本：`sg:CMA1959:en:src-1ebe497c198c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：22；切片：22；发布资格：否

PDF 页数 14，空白页 []，目录页 [1, 2]，条文 18。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CONTROL OF MANUFACTURE ACT 1959 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Control of Manufacture Act 1959 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Manufacture of goods prohibited except on registration 4. Appointment of Registrar 5. Registration 6. Revocation of registration 7. Returns and information 8. Offences 9. Composition of offences 10. Powers of entry and inspection 11. Liability for act of s
```

### `section:1` · section · 

```text
1. This Act is the Control of Manufacture Act 1959. 1 Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “goods” includes all materials, commodities and articles for the time being specified in the First or Second Schedule; “manufacture” means —
(a) the making of any goods or part of any goods;
(b) the altering, ornamenting, finishing, cleaning or washing or the breaking up or the assembling or processing in any form of any goods; or
(c) the adapting for sale of any goods, in which machinery operated by mechanical power is used; “registered manufacturer” means, in respect of the goods for the manufacture of which he is so registered, a person registered under section 3; “Registrar” means the Registrar of Manufacturers appointed under secti
```

### `section:3` · section · Manufacture of goods prohibited except on registration

```text
3. Subject to the provisions of this Act, no person shall engage in the manufacture for sale or other commercial purpose of any goods unless he is registered under the provisions of this Act in respect of that manufacture. Appointment of Registrar
```

### `section:4` · section · Appointment of Registrar

```text
4.—(1) For the purposes of this Act, the Minister may, by name or office, appoint a Registrar of Manufacturers and such Deputy and Assistant Registrars of Manufacturers and such other officers as he may consider necessary.
(2) The Minister may authorise any Deputy or Assistant Registrar of Manufacturers to exercise and perform all or any of the powers and duties conferred and imposed on the Registrar.
[Act 5 of 2025 wef 09/03/2025] 2
(3) An appointment under subsection (1), and any authorisation under subsection (2), must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025] Registration
```

### `section:5` · section · Registration

```text
5.—(1) Every application for registration under section 3 shall be made in the prescribed form and shall be accompanied by such information as may be required by any rules made under this Act.
(2) The Registrar may in his discretion register or refuse to register any person applying for registration in respect of any goods or class of goods and at the time of registering any person may impose such conditions as he thinks fit.
(3) Where any person satisfies the Minister that immediately before the specification of any particular goods or class of goods in the First Schedule he —
(a) was engaged in the manufacture in Singapore of those goods or class of goods; or
(b) had bona fide made substan
```

### `section:6` · section · Revocation of registration

```text
6.—(1) Where it appears to the Registrar that —
(a) any registration was effected as a result of a misrepresentation of facts;
(b) any condition of registration has been contravened by a registered manufacturer; or
(c) a registered manufacturer has for a continuous period of not less than 3 months ceased to manufacture goods in respect of which he has been registered, the Registrar may, after notice to the registered manufacturer and after such inquiry as he thinks fit, revoke the registration.
(2) The Registrar shall within 7 days of revoking any registration inform the registered manufacturer in writing of the revocation and the grounds for the revocation and inform him of his right to app
```

### `section:7` · section · Returns and information

```text
7.—(1) The Registrar may by notice in writing call upon any registered manufacturer to furnish before a specified date such information pertaining to the conditions of his registration as the Registrar may require.
(2) Nothing in subsection (1) shall be deemed to authorise the Registrar to require a registered manufacturer to disclose any secret process used by him in the manufacture of goods.
(3) The information given by a registered manufacturer under subsection (1) shall be treated as confidential and shall not be used, published or disclosed otherwise than for the purposes of this Act without the consent in writing of the registered manufacturer. Offences
```

