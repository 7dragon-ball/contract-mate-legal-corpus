# ETA2010 · 电子交易法（2010）

- 语言：`en`
- 版本：`sg:ETA2010:en:src-7a17e5e184c6`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：90；切片：89；发布资格：否

PDF 页数 59，空白页 []，目录页 [1, 2, 3, 4, 5]，条文 84。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ELECTRONIC TRANSACTIONS ACT 2010 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Electronic Transactions Act 2010 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Purposes and construction 4. Excluded matters 5. Party autonomy
PART 2 ELECTRONIC RECORDS, SIGNATURES AND CONTRACTS 6. Legal recognition of electronic records 7. Requirement for writing 8. Requirement for signature 9. Retention of elec
```

### `section:1` · section · 

```text
1. This Act is the Electronic Transactions Act 2010. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “addressee”, in relation to an electronic communication, means a party who is intended by the originator to receive the electronic communication, but does not include a party acting as an intermediary with respect to that electronic communication; “authorised officer”, in relation to the exercise of any power or performance of any duty under this Act, means a person to whom the exercise of that power or performance of that duty has been delegated under section 27; “automated message system” means a computer program or an electronic or other automated means used to initiate an action or respond to data messages or performances in who
```

### `section:3` · section · Purposes and construction

```text
3. This Act is to be construed consistently with what is commercially reasonable under the circumstances and to give effect to the following purposes:
(a) to facilitate electronic communications by means of reliable electronic records;
(b) to facilitate electronic commerce, to eliminate barriers to electronic commerce resulting from uncertainties over writing and signature requirements, and to promote the development of the legal and business infrastructure necessary to implement secure electronic commerce;
(c) to facilitate electronic filing of documents with public agencies, and to promote efficient delivery by public agencies of services by means of reliable electronic records;
(d) to min
```

### `section:4` · section · Excluded matters

```text
4.—(1) The provisions of this Act specified in the first column of the First Schedule do not apply to any rule of law requiring writing or signatures in any of the matters specified in the second column of that Schedule.
(2) The Minister may, by order in the Gazette, amend the First Schedule. Party autonomy
```

### `section:5` · section · Party autonomy

```text
5.—(1) Nothing in Part 2 affects any rule of law or obligation requiring the agreement or consent of the parties as to the form of a communication or record, and (unless otherwise agreed or provided by a rule of law) such agreement or consent may be inferred from the conduct of the parties.
(2) Nothing in Part 2 prevents the parties to a contract or transaction from —
(a) excluding the use of electronic records, electronic communications or electronic signatures in the contract or transaction by agreement; or
(b) imposing additional requirements as to the form or authentication of the contract or transaction by agreement.
(3) Subject to any other rights or obligations of the parties to a con
```

### `section:6` · section · Legal recognition of electronic records

```text
6. To avoid doubt, it is declared that information is not to be denied legal effect, validity or enforceability solely on the ground that it is in the form of an electronic record. Requirement for writing
```

### `section:7` · section · Requirement for writing

```text
7. Where a rule of law requires information to be written, in writing, to be presented in writing or provides for certain consequences if it is not, an electronic record satisfies that rule of law if the information contained in the electronic record is accessible so as to be usable for subsequent reference. Requirement for signature
```

