# CAA1988 · 航空运输法（1988）

- 语言：`en`
- 版本：`sg:CAA1988:en:src-e3e48d6da263`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：18；切片：32；发布资格：否

PDF 页数 50，空白页 []，目录页 [1, 2]，条文 13。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CARRIAGE BY AIR ACT 1988 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Carriage by Air Act 1988 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Conventions to have force of law 4. High Contracting Parties 5. Fatal accidents 6. Limitations of liability 7. Notice of partial loss 8. Time for bringing proceedings 9. Contributory negligence 10. Power to exclude aircraft in use for military purposes 11. Actions again
```

### `section:1` · section · 

```text
1. This Act is the Carriage by Air Act 1988. 1 Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “court”, in an arbitration allowed by the Warsaw Convention, the Warsaw (Hague) Convention or the Warsaw (Hague) (Montreal) Convention, includes an arbitrator; “Hague Protocol” means the Protocol to amend the Warsaw Convention opened for signature at the Hague on 28 September 1955; “Montreal Protocol No. 4” means Protocol No. 4 to amend the Warsaw (Hague) Convention opened for signature at Montreal on 25 September 1975; “Warsaw Convention” means the original Convention for the unification of certain rules relating to international carriage by air opened for signature at Warsaw on 12 October 1929, the text of which is set out in the Seco
```

### `section:3` · section · Conventions to have force of law

```text
3.—(1) Subject to this Act, the provisions of the Warsaw Convention, the Warsaw (Hague) Convention and the Warsaw (Hague) (Montreal) Convention, so far as they relate to the rights and liabilities of carriers, carriers’ employees and agents, passengers, consignors, consignees and other persons, have the force of law in Singapore in relation to any carriage by air to which the Warsaw Convention, the Warsaw (Hague) Convention or the Warsaw (Hague) (Montreal) Convention (as the case may require) applies irrespective of the nationality of the aircraft performing that carriage.
(2) If there is any inconsistency between any of the texts set out in the First, Second and Third Schedules and the auth
```

### `section:4` · section · High Contracting Parties

```text
4.—(1) For the purposes of this Act —
(a) a High Contracting Party to the Warsaw Convention is a country that has ratified or acceded to that Convention;
(b) a High Contracting Party to the Warsaw (Hague) Convention is a country that has ratified or acceded to that Convention; and
(c) a High Contracting Party to the Warsaw (Hague) (Montreal) Convention is a country that has ratified or acceded to that Convention, except that this Act applies to any such High Contracting Party —
(d) only in relation to the territories in respect of which it is a party to the Warsaw Convention, the Warsaw (Hague) Convention or the Warsaw (Hague) (Montreal) Convention, as the case may be; and
(e) to the extent 
```

### `section:5` · section · Fatal accidents

```text
5. References in section 20 of the Civil Law Act 1909 to a wrongful act, neglect or default include references to any occurrence which gives rise to liability under Article 17 in the First, Second and Third Schedules. 3 Limitations of liability
```

### `section:6` · section · Limitations of liability

```text
6.—(1) It is declared that the limitations on liability in Article 22 in the First, Second and Third Schedules apply whatever the nature of the proceedings by which liability may be enforced and that, in particular the limitation for each passenger in Article 22(1) in the First, Second and Third Schedules applies to the aggregate liability of the carrier in all proceedings which may be brought against him under the law of Singapore, together with any proceedings brought against him outside Singapore.
(2) A court before which proceedings are brought to enforce a liability which is limited by Article 22 in the First, Second or Third Schedule may at any stage of the proceedings make any such or
```

### `section:7` · section · Notice of partial loss

```text
7. In Article 26(2) in the First, Second and Third Schedules —
(a) references to damage are to be construed as including loss of part of the baggage or cargo in question; and
(b) references to the receipt of baggage or cargo, in relation to loss of part of it, are to be construed as receipt of the remainder of it. Time for bringing proceedings
```

