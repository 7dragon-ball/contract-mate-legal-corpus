# SGA1982 · 货物供应法（1982）

- 语言：`en`
- 版本：`sg:SGA1982:en:src-d661028e4dd4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：18；切片：17；发布资格：否

PDF 页数 18，空白页 [2]，目录页 [1, 3, 4]，条文 16。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE SUPPLY OF GOODS ACT 1982 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Supply of Goods Act 1982 ARRANGEMENT OF SECTIONS
PART 1 Section Contracts for transfer of property in goods 1. Contracts concerned 2. Implied terms about title, etc. 3. Implied terms where transfer is by description 4. Implied terms about quality or fitness 5. Implied terms where transfer is by sample 5A. Modification of remedies for breach of statutory conditi
```

### `section:1` · section · 

```text
1.—(1) In this Act, “contract for the transfer of goods” means a contract under which one person transfers or agrees to transfer to another the property in goods, other than an excepted contract.
(2) For the purposes of this section, an excepted contract means any of the following:
(a) a contract of sale of goods;
(b) a hire-purchase agreement;
(c) a transfer or agreement to transfer which is made by deed and for which there is no consideration other than the presumed consideration imported by the deed;
(d) a contract intended to operate by way of mortgage, pledge, charge or other security.
(3) For the purposes of this Act, a contract is a contract for the transfer of goods whether or not se
```

### `section:2` · section · Implied terms about title, etc.

```text
2.—(1) In a contract for the transfer of goods, other than one to which subsection (3) applies, there is an implied condition on the part of the transferor that in the case of a transfer of the property in the goods he has a right to transfer the property and in the case of an agreement to transfer the property in the goods he will have such a right at the time when the property is to be transferred. 2
(2) In a contract for the transfer of goods, other than one to which subsection (3) applies, there is also an implied warranty that —
(a) the goods are free, and will remain free until the time when the property is to be transferred, from any charge or encumbrance not disclosed or known to the
```

### `section:3` · section · Implied terms where transfer is by description

```text
3.—(1) This section applies where, under a contract for the transfer of goods, the transferor transfers or agrees to transfer the property in the goods by description. 3
(2) In such a case, there is an implied condition that the goods will correspond with the description.
(3) If the transferor transfers or agrees to transfer the property in the goods by sample as well as by description, it is not sufficient that the bulk of the goods corresponds with the sample if the goods do not also correspond with the description.
(4) A contract is not prevented from falling within subsection (1) by reason only that, being exposed for supply, the goods are selected by the transferee. Implied terms about 
```

### `section:4` · section · Implied terms about quality or fitness

```text
4.—(1) Except as provided by this section and section 5 and subject to the provisions of any other enactment, there is no implied condition or warranty about the quality or fitness for any particular purpose of goods supplied under a contract for the transfer of goods.
(2) Where, under such a contract, the transferor transfers the property in goods in the course of a business, there is an implied condition that the goods supplied under the contract are of satisfactory quality.
(2A) For the purposes of this section and section 5, goods are of satisfactory quality if they meet the standard that a reasonable person would regard as satisfactory, taking account of any description of the goods, th
```

### `section:5` · section · Implied terms where transfer is by sample

```text
5.—(1) This section applies where, under a contract for the transfer of goods, the transferor transfers or agrees to transfer the property in the goods by reference to a sample. 5
(2) In such a case, there is an implied condition —
(a) that the bulk will correspond with the sample in quality;
(b) that the transferee will have a reasonable opportunity of comparing the bulk with the sample; and
(c) that the goods will be free from any defect, making their quality unsatisfactory, which would not be apparent on reasonable examination of the sample.
(3) [Deleted by Act 44 of 1996]
(4) For the purposes of this section, a transferor transfers or agrees to transfer the property in goods by reference
```

### `section:5A` · section · non-consumer contracts for transfer of goods

```text
5A.—(1) Where in the case of a contract for the transfer of goods —
(a) the transferee would, apart from this subsection, have the right to treat the contract as repudiated by reason of a breach on the part of the transferor of a condition implied by section 3, 4 or 5(2)(a) or (c); but
(b) the breach is so slight that it would be unreasonable for the transferee to do so, then, if the transferee does not deal as consumer, the breach is not to be treated as a breach of condition but may be treated as a breach of warranty.
(2) This section applies unless a contrary intention appears in, or is to be implied from, the contract.
(3) It is for the transferor to show that a breach fell within subsec
```

### `section:6` · section · Contracts concerned

```text
6.—(1) In this Act, “contract for the hire of goods” means a contract under which one person bails or agrees to bail goods to another by way of hire, other than a hire-purchase agreement.
(2) For the purposes of this Act, a contract is a contract for the hire of goods whether or not services are also provided or to be provided under the contract, and whatever is the nature of the consideration for the bailment or agreement to bail by way of hire. Implied terms about right to transfer possession, etc.
```

