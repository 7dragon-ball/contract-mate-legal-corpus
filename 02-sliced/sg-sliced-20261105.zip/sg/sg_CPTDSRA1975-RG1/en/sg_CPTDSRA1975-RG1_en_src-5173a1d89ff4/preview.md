# CPTDSRA1975-RG1 · 消费者保护（安全要求）规例

- 语言：`en`
- 版本：`sg:CPTDSRA1975-RG1:en:src-5173a1d89ff4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：60；切片：60；发布资格：否

PDF 页数 32，空白页 []，目录页 []，条文 55。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
CONSUMER PROTECTION (TRADE DESCRIPTIONS AND SAFETY REQUIREMENTS) ACT (CHAPTER 53, SECTIONS 11 AND 32) CONSUMER PROTECTION (SAFETY REQUIREMENTS) REGULATIONS ARRANGEMENT OF REGULATIONS
PART I PRELIMINARY Regulation 1. Citation 2. Definitions 3. Exemption 4. Supply of safe goods
PART II REGISTERED SUPPLIERS AND REGISTERED CONTROLLED GOODS 5. Importer or manufacturer to apply to be registered as Registered Supplier and to register controlled goods 6. Application for registration of supplier 7. Application for registration of controlled goods 8. Duration and renewal of registration of controlled goods 9. Application of regulations to renewal of registration of controlled goods 10. Register of Reg
```

### `section:1` · section · 

```text
1. These Regulations may be cited as the Consumer Protection (Safety Requirements) Regulations. Definitions
```

### `section:2` · section · Definitions

```text
2.—(1) In these Regulations, unless the context otherwise requires — p. 2 “alternate testing laboratory” means —
(a) a testing laboratory or manufacturer’s testing laboratory that is recognised under the International Electrotechnical Commission System of Conformity Assessment Schemes for Electrotechnical Equipment and Components Certification Bodies Scheme (the IECEE CB Scheme);
(b) a testing laboratory that is recognised by a Foreign Recognition Body; or
(c) a testing laboratory the test reports of which are agreed to be accepted by one or more CAB (Certification) or CAB (Testing) under an approved testing agreement;
[S 14/2018 wef 15/01/2018] “approved testing agreement” means an agreemen
```

### `section:3` · section · Exemption

```text
3. The Safety Authority may, in its discretion and for such period and on such conditions as it thinks fit, exempt any person or any controlled goods from all or any of the provisions of these Regulations. Supply of safe goods
```

### `section:4` · section · Supply of safe goods

```text
4.—(1) No person shall, in the course of any trade or business, supply or advertise for the purpose of supply any controlled goods after the effective date specified in the First Schedule unless —
(a) such controlled goods are registered controlled goods conforming to the safety requirements specified by the Safety Authority for those goods; and
(b) such controlled goods have affixed to them the Safety Mark in accordance with Part III.
(2) Where any person contravenes paragraph (1), he shall be guilty of an offence under section 11(2) of the Act, and the Safety Authority may —
(a) require such person to effect a recall of the controlled goods and keep the Safety Authority informed of the pro
```

### `section:5` · section · Registered Supplier and to register controlled goods

```text
5.—(1) Any importer or manufacturer in Singapore who intends, in the course of any trade or business, to supply or advertise for supply any controlled goods in Singapore shall apply to the Safety Authority —
(a) to be registered as a Registered Supplier; and
(b) to register any controlled goods which the importer or manufacturer intends to supply or advertise for supply in Singapore.
(2) An importer or a manufacturer which contravenes paragraph (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $2,000 or to imprisonment for a term not exceeding 12 months or to both. Application for registration of supplier
```

### `section:6` · section · Application for registration of supplier

```text
6. An application to be registered as a Registered Supplier shall be in such form as the Safety Authority may determine and shall be accompanied by such documents and information as the Safety Authority may require. Application for registration of controlled goods
```

### `section:7` · section · Application for registration of controlled goods

```text
7.—(1) Subject to paragraph (5), an application for registration of any high-risk controlled goods or medium-risk controlled goods must be made by a Registered Supplier in such form as the Safety Authority may require, and must be accompanied by —
(a) a certificate of conformity in respect of the controlled goods;
[S 687/2018 wef 11/10/2018]
(b) such other information and documents as the Safety Authority may require to decide the application; and p. 8
(c) a non-refundable fee of the amount specified in the Third Schedule.
(2) Subject to paragraph (6), an application for registration of any low-risk controlled goods must be made by a Registered Supplier in such form as the Safety Authority m
```

