# AELA1993 · 英国法律适用法（1993）

- 语言：`en`
- 版本：`sg:AELA1993:en:src-a113222618b3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：35；切片：34；发布资格：否

PDF 页数 21，空白页 [2]，目录页 [1, 3]，条文 31。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE APPLICATION OF ENGLISH LAW ACT 1993 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Application of English Law Act 1993 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Application of common law and equity 4. Application of English enactments 5. Other enactments not part of law of Singapore 6. Repeal 7. Miscellaneous amendments 8. Modification Orders 9. Revised edition of English enactments First Schedule Second S
```

### `section:1` · section · 

```text
1. This Act is the Application of English Law Act 1993. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “English enactment” means an enactment of the Parliament of England, the Parliament of Great Britain or the Parliament of the United Kingdom; “local Act” means an Act of the Parliament of Singapore and includes any Ordinance or Act of Singapore or of Malaysia having the force of law in Singapore. 1 Application of common law and equity
```

### `section:3` · section · Application of common law and equity

```text
3.—(1) The common law of England (including the principles and rules of equity), so far as it was part of the law of Singapore immediately before 12 November 1993, continues to be part of the law of Singapore.
(2) The common law continues to be in force in Singapore, as provided in subsection (1), so far as it is applicable to the circumstances of Singapore and its inhabitants and subject to such modifications as those circumstances may require. Application of English enactments
```

### `section:4` · section · Application of English enactments

```text
4.—(1) Subject to the provisions of this section and of any other written law, the following English enactments, with the necessary modifications, apply or continue to apply in Singapore:
(a) the English enactments specified in the second and third columns of the First Schedule to the extent specified in the fourth column thereof; and
(b) any other English enactment which applies to or is in force in Singapore by virtue of any written law.
(2) The English enactments specified in Part 2 of the First Schedule are the enactments as they are in force as at 12 November 1993, subject to the exceptions specified in the fourth column of that Part and to the amendments specified in Part 3 of that Sch
```

### `section:5` · section · Other enactments not part of law of Singapore

```text
5.—(1) Except as provided in this Act, no English enactment is part of the law of Singapore.
(2) Where any English enactment ceases by virtue of this Act to be part of the law of Singapore, the Interpretation Act 1965 applies as it would apply on the repeal of an Act of the Parliament of Singapore. Repeal
```

### `section:6` · section · Repeal

```text
6.—(1) Subject to subsection (2), section 5 of the Civil Law Act (Cap. 43, 1988 Revised Edition) is repealed.
(2) In respect of any proceedings instituted or any cause of action accruing before 12 November 1993, section 5 of the Civil Law Act (Cap. 43, 1988 Revised Edition) continues to apply as if it had not been repealed by this Act.
(3) The Voluntary Conveyances Act (Cap. 346, 1985 Revised Edition) is repealed. Miscellaneous amendments
```

### `section:7` · section · Miscellaneous amendments

```text
7. The local Acts specified in the Second Schedule are amended in the manner provided in that Schedule. Modification Orders
```

