# REFJA1959 · 外国判决相互执行法（1959）

- 语言：`en`
- 版本：`sg:REFJA1959:en:src-c36bbeb88fa5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：14；切片：14；发布资格：否

PDF 页数 22，空白页 []，目录页 [1, 2, 3]，条文 12。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE RECIPROCAL ENFORCEMENT OF FOREIGN JUDGMENTS ACT 1959 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Reciprocal Enforcement of Foreign Judgments Act 1959 ARRANGEMENT OF SECTIONS
PART 1 REGISTRATION OF FOREIGN JUDGMENTS Section 1. Short title 2. Interpretation 2A. Application 3. Extension of Part to judgments of recognised courts of foreign countries on basis of reciprocity 4. Application for, and effect of, registration of foreign j
```

### `section:1` · section · 

```text
1. This Act is the Reciprocal Enforcement of Foreign Judgments Act 1959. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “appeal” includes any proceedings by way of discharging or setting aside a judgment or an application for a new trial or stay of enforcement;
[Act 25 of 2021 wef 01/04/2022] “country” includes a territory; “country of the original court” means the country in which the original court is situated; “Family Justice Rules” means the Family Justice Rules made under section 46 of the Family Justice Act 2014; “foreign country” means any country outside Singapore; “judgment” means an interlocutory or final judgment or order given or made by a court in any civil proceedings, or a judgment or order given or made by a court in any criminal proc
```

### `section:2A` · section · Application

```text
2A. This Act does not apply to any judgment which may be recognised or enforced in Singapore under the Choice of Court Agreements Act 2016.
[14/2016] 4 Extension of Part to judgments of recognised courts of foreign countries on basis of reciprocity
```

### `section:3` · section · countries on basis of reciprocity

```text
3.—(1) If the Minister is satisfied that, in the event of the benefits conferred by this Part being extended to a particular description of judgments given in a particular court or description of courts of a foreign country, substantial reciprocity of treatment will be assured as respects the enforcement in that foreign country of similar judgments given in a similar court or similar courts of Singapore, the Minister may, by order in the Gazette, direct that —
(a) this Part applies to that foreign country;
(b) the court or courts of the foreign country specified in the order is a recognised court or are recognised courts of the foreign country for the purposes of this Part; and
(c) judgments
```

### `section:4` · section · Application for, and effect of, registration of foreign judg

```text
4.—(1) A person, being a judgment creditor under a judgment to which this Part applies, may apply to the General Division of the High Court at any time —
(a) within 6 years after the date of the judgment; or
(b) where there have been proceedings by way of appeal against the judgment, after the date of the last judgment given in those proceedings, to have the judgment registered in the General Division of the High Court.
[40/2019]
(2) On an application under subsection (1), the court shall, subject to proof of the prescribed matters and to the provisions of this Act, order the judgment to be registered.
(3) A judgment shall not be registered under this section if at the date of the applicatio
```

### `section:5` · section · Cases in which registered judgments must or may be set aside

```text
5.—(1) On an application in that behalf duly made by any party against whom a registered judgment may be enforced, the registration of the judgment —
(a) shall be set aside if the registering court is satisfied —
(i) that the judgment is not a judgment to which this Part applies or was registered in contravention of sections 3 and 4;
(ii) that the courts of the country of the original court had no jurisdiction in the circumstances of the case;
(iii) that the judgment debtor, being a defendant in the proceedings in the original court, did not (notwithstanding that process may have been duly served on him in accordance with the law of the country of the original court) receive notice of those 
```

### `section:6` · section · registration

```text
6.—(1) If, on an application to set aside the registration of a judgment, the applicant satisfies the registering court either that an appeal is pending, or that he is entitled and intends to appeal, against the judgment, the court, if it thinks fit, may, on such terms as it may think just —
(a) set aside the registration; or
(b) adjourn the application to set aside the registration until after the expiration of such period as appears to the court to be reasonably sufficient to enable the applicant to take the necessary steps to have the appeal disposed of by the competent tribunal.
(2) Where the registration of a judgment is set aside under subsection (1), or solely for the reason that the 
```

