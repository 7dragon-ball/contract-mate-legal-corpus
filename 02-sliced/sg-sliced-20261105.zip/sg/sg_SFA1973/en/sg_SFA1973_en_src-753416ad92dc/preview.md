# SFA1973 · 食品销售法 1973

- 语言：`en`
- 版本：`sg:SFA1973:en:src-753416ad92dc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：75；切片：75；发布资格：否

PDF 页数 70，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]，条文 73。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE SALE OF FOOD ACT 1973 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Sale of Food Act 1973 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. General interpretation 2A. Meaning of “food” 2B. Meaning of “food business” 2C. Meaning of unsafe food 2D. Meaning of unsuitable food 2E. Meaning of “sell” 2F. Meaning of “non-retail food business”
PART 2 ADMINISTRATION AND ENFORCEMENT 3. Administration of Act and appointmen
```

### `section:2A` · section · 

```text
2A.—(1) In this Act, “food” includes the following:
(a) any substance or thing of a kind used, capable of being used, or represented as being for use, for human 10 consumption (whether it is live, raw, prepared or partly prepared);
(b) any substance or thing of a kind used, capable of being used, or represented as being for use, as an ingredient or additive in a substance or thing mentioned in paragraph (a);
(c) any substance used in preparing a substance or thing mentioned in paragraph (a) (other than a substance used in preparing a living thing);
(d) chewing gum or an ingredient or additive in chewing gum, or any substance used in preparing chewing gum;
(e) any substance or thing declared 
```

### `section:2B` · section · Meaning of “food business”

```text
2B.—(1) In this Act, “food business” means a business or an undertaking or activity that involves, in whole or part —
(a) the handling of food intended for sale;
(b) the sale of food (on the Internet or otherwise); or
(c) primary food production, regardless of whether the business, undertaking or activity concerned is of a commercial, charitable or community nature, or whether it involves the handling or sale of food on one occasion only, and whether part of a non‑retail food business or a retail food business.
[48/2017] 12
(2) However, a food business does not include a business or an undertaking or activity —
(a) that is part of a business other than trading in food and, in the course of w
```

### `section:2C` · section · Meaning of unsafe food

```text
2C.—(1) For the purposes of this Act, food is unsafe at a particular time if it would be likely to cause illness or injury or other physical harm to a person who might later consume it, assuming —
(a) it was, after that particular time and before being consumed by the person, properly subjected to all processes (if any) that are relevant to its reasonable intended use;
(b) nothing happened to it after that particular time and before being consumed by the person that would prevent it being used for its reasonable intended use; and
(c) it was consumed by the person according to its reasonable intended use.
[48/2017]
(2) However, food is not unsafe for the purposes of this Act merely because —

```

### `section:2D` · section · Meaning of unsuitable food

```text
2D.—(1) For the purposes of this Act, food is unsuitable if it is food that —
(a) is damaged, deteriorated or perished to an extent that affects its reasonable intended use;
(b) contains, or has attached to it or enclosed with it, any damaged, deteriorated, perished or contaminated substance or thing to an extent that affects its reasonable intended use;
(c) is the product of a diseased animal, or an animal that has died otherwise than by slaughter, and has not been declared by or under another Act to be safe for human consumption;
(d) contains a biological or chemical agent, or other matter or substance, that is foreign to the nature of the food and the presence of which would be unexpected
```

### `section:2E` · section · Meaning of “sell”

```text
2E.—(1) In this Act, “sell” includes carrying on any of the following activities, or a combination of those activities, in relation to food for human consumption or to a food contact article:
(a) bartering;
(b) offering for sale or attempting to sell;
(c) receiving, or having in possession, for sale;
(d) displaying for sale;
(e) causing or permitting to be sold or offered or displayed for sale;
(f) sending, forwarding or delivering for sale;
(g) disposing of by any method for valuable consideration;
(h) disposing of to an agent for sale on consignment;
(i) supplying as a meal or part of a meal to an employee or other individual in accordance with an employment agreement or an agreement for s
```

### `section:2F` · section · Meaning of “non-retail food business”

```text
2F.—(1) In this Act, “non-retail food business” means a food business that is —
(a) not carried out for a purpose specified in the First Schedule to the Environmental Public Health Act 1987; and
(b) not a primary food production business, but includes a food business a component of which is a business, an undertaking or activity carried out for a purpose specified in the First Schedule to the Environmental Public Health Act 1987.
[48/2017]
(2) Without limiting subsection (1), a non‑retail food business includes (but is not limited to) any of the following food businesses: 17
(a) a factory, plant or other premises where meat products or fish products are processed for sale to wholesalers or r
```

### `section:3` · section · etc.

```text
3.—(1) The Minister must appoint from among officers of the Agency the Director‑General, Food Administration, who is responsible for the administration of this Act, subject to the general or special directions of the Minister.
[11/2019]
(2) The Director‑General may in writing appoint any public officer or any officer of the Agency or any other statutory authority, or an auxiliary police officer appointed under the Police Force Act 2004, to be an authorised officer for the purposes of this Act.
[11/2019]
(3) The Director‑General may appoint one or more persons with the prescribed qualifications and practical experience to be authorised analysts for the purposes of this Act.
(4) The Director‑G
```

