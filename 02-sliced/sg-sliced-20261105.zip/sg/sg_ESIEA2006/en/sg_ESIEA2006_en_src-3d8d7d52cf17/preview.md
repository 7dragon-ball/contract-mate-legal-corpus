# ESIEA2006 · 濒危物种（进出口）法 2006

- 语言：`en`
- 版本：`sg:ESIEA2006:en:src-3d8d7d52cf17`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：58；切片：95；发布资格：否

PDF 页数 159，空白页 []，目录页 [1, 2, 3, 4]，条文 55。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ENDANGERED SPECIES (IMPORT AND EXPORT) ACT 2006 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Endangered Species (Import and Export) Act 2006 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 2A. Meaning of transit in Singapore 3. Appointment of Director‑General and authorised officers
PART 2 CONTROL OF IMPORT, EXPORT, ETC., OF SCHEDULED SPECIES 4. Restriction on import, export, etc., of scheduled
```

### `section:1` · section · 

```text
1. This Act is the Endangered Species (Import and Export) Act 2006. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “advertise”, in relation to a scheduled species, means to describe, make reference to or allude in any way, by any means or in any form, to that scheduled species —
(a) whether directly or indirectly;
(b) whether orally, in writing in any language, diagrammatically, pictorially, by the use of symbols or photographs, or in any combination thereof; and
(c) whether by the common name or the scientific name of that scheduled species or otherwise; “animal” means any member of the Animal Kingdom, and includes —
(a) any mammal (other than man), bird, reptile, amphibian, fish, mollusc, arthropod, or other vertebrate or invertebrate, whether
```

### `section:2A` · section · Meaning of transit in Singapore

```text
2A. For the purposes of this Act, a scheduled species is in transit in Singapore only if —
(a) the scheduled species is supported by a prescribed document that —
(i) is issued on or before, or within 14 days after, the date on which the scheduled species is brought into Singapore; and
(ii) specifies a port, an airport or any other place outside Singapore as the destination for the scheduled species; and
(b) one of the following conditions is satisfied:
(i) the scheduled species remains at all times in or on the conveyance in or on which it is brought into Singapore, pending transport of the scheduled species to the port, airport or other place outside Singapore; 7
(ii) the scheduled species 
```

### `section:3` · section · Appointment of Director‑General and authorised officers

```text
3.—(1) The Board is responsible for the administration of this Act, and to that end, the Board must appoint an officer of the Board to be the Director‑General, Wildlife Trade Control.
[10/2019]
(2) The Director‑General may, subject to the directions of the Board, appoint any of the following persons to be an authorised officer for the purpose of assisting the Director‑General in administering and carrying out the provisions of this Act or any other written law which confers powers on the Director‑General:
(a) an employee of the Board;
(b) an employee of another statutory authority;
(c) a public officer who is not a police officer or an officer of customs within the meaning of the Customs Act
```

### `section:4` · section · Restriction on import, export, etc., of scheduled species

```text
4.—(1) Any person who —
(a) imports, introduces from the sea, exports or re-exports any scheduled species without a valid permit;
(b) has in the person’s possession or under the person’s control, or sells, or offers, exposes or advertises for sale, or displays to the public, any scheduled species that is imported, or introduced from the sea, without a valid permit; or 9
(c) sells, or offers, exposes or advertises for sale, or displays to the public, any scheduled species that is specified by the Minister by notification in the Gazette, shall be guilty of an offence.
(2) Any person (except a person mentioned in section 5A(1) or (2)) who is guilty of an offence under subsection (1)(a), (b) or 
```

### `section:5` · section · Control of scheduled species in transit

```text
5.—(1) Every scheduled species in transit in Singapore must be accompanied by — 10
(a) a valid CITES permit or certificate, or any other similar document, that is issued by the competent authority of the country of export or re-export of the scheduled species for the export or re-export of the scheduled species, and contains the prescribed information; and
(b) where required by the country of import or final destination of the scheduled species — a valid CITES permit or certificate, or any other similar document, that is issued by the competent authority of that country or destination for the import of the scheduled species, and contains the prescribed information.
(2) Different information 
```

### `section:5A` · section · section 4 or 5

```text
5A.—(1) Any corporation, unincorporated association or partnership that is guilty of an offence under section 4(1)(a), (b) or
(c) or 5(4) shall be liable on conviction —
(a) in the case where the offence is committed in respect of one or more specimens of any scheduled species specified in 12 Appendix I of the Schedule — to a fine not exceeding $200,000 for each specimen of that scheduled species (but not exceeding $1 million for, or the market value (at the material time of the offence) of, all the specimens of that scheduled species comprised in the offence, whichever is higher); and
(b) in the case where the offence is committed in respect of one or more specimens of any scheduled species
```

