# SGCA2002-S534-2019 · 战略物品（经纪）管制命令 2019

- 语言：`en`
- 版本：`sg:SGCA2002-S534-2019:en:src-f67d95d940b7`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：5；切片：4；发布资格：否

PDF 页数 2，空白页 []，目录页 [1]，条文 4。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
Strategic Goods (Control) (Brokering) Order 2019 Table of Contents Enacting Formula 1 Citation and commencement 2 Strategic goods to which section 6(1) of Act applies 3 Strategic goods technology to which section 6(1) of Act applies 4 Revocation No. S 534 STRATEGIC GOODS (CONTROL) ACT (CHAPTER 300) STRATEGIC GOODS (CONTROL) (BROKERING) ORDER 2019 In exercise of the powers conferred by section 6(2)(a) and (3)(a) of the Strategic Goods (Control) Act, the Minister for Trade and Industry makes the following Order: Citation and commencement
```

### `section:1` · section · 

```text
1.  This Order is the Strategic Goods (Control) (Brokering) Order 2019 and comes into operation on 1 October 2019. Strategic goods to which section 6(1) of Act applies
```

### `section:2` · section · Strategic goods to which section 6(1) of Act applies

```text
2.  Section 6(1) of the Act applies to all strategic goods specified in the following Category Codes in Division 2 of Part 1 of the Schedule to the Strategic Goods (Control) Order 2025 (G.N. No. S 660/2025):
(a) ML1 to ML4;
(b) ML8.
[S 788/2020 wef 16/11/2020]
[S 566/2021 wef 01/10/2021]
[S 543/2023 wef 01/10/2023]
[S 643/2024 wef 01/10/2024]
[S 662/2025 wef 01/12/2025] Strategic goods technology to which section 6(1) of Act applies
```

### `section:3` · section · Strategic goods technology to which section 6(1) of Act appl

```text
3.  Section 6(1) of the Act applies to all strategic goods technology specified in Category Codes ML21 and ML22 in Division 2 of Part 1 of the Schedule to the Strategic Goods (Control) Order 2025 that is necessary for the development, production or use of any strategic goods mentioned in paragraph 2.
[S 788/2020 wef 16/11/2020]
[S 566/2021 wef 01/10/2021]
[S 543/2023 wef 01/10/2023]
[S 643/2024 wef 01/10/2024]
[S 662/2025 wef 01/12/2025] Revocation
```

### `section:4` · section · Revocation

```text
4.  The Strategic Goods (Control) (Brokering) Order 2007 (G.N. No. S 640/2007) is revoked. Made on 17 July 2019. GABRIEL LIM Permanent Secretary, Ministry of Trade and Industry, Singapore.
[MTI 66/1-2-24/PT 1 Vol 3; AG/LEGIS/SL/300/2015/3 Vol. 1]
```

