# MTA2021-RG1 · 多式联运规例 2021

- 语言：`en`
- 版本：`sg:MTA2021-RG1:en:src-4594b2b5b9b2`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：6；切片：5；发布资格：否

PDF 页数 6，空白页 []，目录页 [1]，条文 4。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
MULTIMODAL TRANSPORT ACT 2021 (SECTION 31) MULTIMODAL TRANSPORT REGULATIONS 2021 ARRANGEMENT OF REGULATIONS Regulation 1. Citation 2. Application for registration certificate 3. Prescribed minimum assets 4. Application for renewal of registration certificate 5. Contents of multimodal transport document
[28 November 2021] Citation
1. These Regulations are the Multimodal Transport Regulations 2021. Application for registration certificate
```

### `section:2` · section · 

```text
2.—(1) For the purposes of section 4(2) of the Act, an application for a registration certificate —
(a) must be accompanied by a non‑refundable application fee of $130.80; and
(b) must include all the following information, where applicable:
(i) the name of the applicant and whether the applicant is a company, partnership, sole proprietor, or any other type of entity and the type of entity; p. 1
(ii) the place of the applicant’s place of incorporation or formation;
(iii) the following particulars of the applicant: (A) principal place of business; (B) registered address; (C) email address, Internet website address, phone number and fax number; (D) date of incorporation or formation; (E) Uniqu
```

### `section:3` · section · Prescribed minimum assets

```text
3. For the purposes of section 4(4)(d) of the Act, the prescribed minimum assets are 80,000 special drawing rights. Application for renewal of registration certificate
```

### `section:4` · section · Application for renewal of registration certificate

```text
4.—(1) For the purposes of section 5(1) of the Act, an application for the renewal of a registration certificate —
(a) must be accompanied by a non‑refundable application fee of $130.80; and
(b) must include particulars of any change to the information mentioned in regulation 2(1)(b) included in the application for the registration certificate. p. 3
(a) require an applicant to produce any documentary evidence of any change to the information mentioned in regulation 2(1)(b);
(b) in any particular case, dispense with the requirement for an applicant to include in the application for the renewal of a registration certificate, particulars of any change to the information mentioned in regulation 
```

### `section:5` · section · Contents of multimodal transport document

```text
5. For the purposes of section 10(1) of the Act, the prescribed particulars are as follows:
(a) in relation to the goods taken in charge in Singapore by the multimodal transport operator —
(i) the general nature of the goods;
(ii) the marks necessary for the identification of the goods;
(iii) a statement, if applicable, as to the dangerous or perishable character of the goods;
(iv) the number of packages or pieces of the goods;
(v) the gross weight of the goods or their quantity otherwise expressed;
(vi) the apparent condition of the goods; and
(vii) all particulars furnished by the consignor of the goods;
(b) the name and principal place of business of the multimodal transport operator;
(c)
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY MULTIMODAL TRANSPORT REGULATIONS 2021 This Legislative History is provided for the convenience of users of the Multimodal Transport Regulations 2021. It is not part of these Regulations.
1. G.N. No. S 822/2021 — Multimodal Transport Regulations 2021 Date of commencement : 28 November 2021
2. G.N. No. S 926/2023 — Multimodal Transport (Amendment) Regulations 2023 Date of commencement : 31 December 2021
3. G.N. No. S 926/2023 — Multimodal Transport (Amendment) Regulations 2023 Date of commencement : 1 January 2024
4. 2025 Revised Edition — Multimodal Transport Regulations 2021 Date of operation : 2 June 2025
5. G.N. No. S 708/2026 — Multimodal Transport (Amendment) Regulati
```

