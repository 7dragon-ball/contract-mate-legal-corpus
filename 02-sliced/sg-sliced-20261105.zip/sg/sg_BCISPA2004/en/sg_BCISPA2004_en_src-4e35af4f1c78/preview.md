# BCISPA2004 · 建筑与建造业付款保障法（2004）

- 语言：`en`
- 版本：`sg:BCISPA2004:en:src-4e35af4f1c78`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：45；切片：46；发布资格：否

PDF 页数 60，空白页 []，目录页 [1, 2, 3, 4]，条文 43。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE BUILDING AND CONSTRUCTION INDUSTRY SECURITY OF PAYMENT ACT 2004 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Building and Construction Industry Security of Payment Act 2004 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Definitions of “construction work”, “goods” and “services” 4. Application of Act
PART 2 RIGHTS TO PROGRESS PAYMENTS 5. Entitlement to progress payments 6. Amount of progress
```

### `section:1` · section · 

```text
1. This Act is the Building and Construction Industry Security of Payment Act 2004. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “adjudicated amount” means the amount of a progress payment that is determined to be payable under section 17 or 19, as the case may be; “adjudication” means the adjudication of a payment claim dispute in accordance with Part 4, and includes an adjudication review under that Part; “adjudication determination”, in relation to an adjudication, means the determination of the adjudicator; “adjudication response” means a response to an adjudication application lodged by a respondent under section 15(1); 3 “adjudicator” means a person appointed under this Act to determine a payment claim dispute that has been referred for adjudication, and in
```

### `section:3` · section · Definitions of “construction work”, “goods” and “services”

```text
3.—(1) In this Act, unless the context otherwise requires and subject to subsection (2) — “construction work” means —
(a) the construction, alteration, repair, restoration, maintenance, extension, demolition or dismantling of buildings or structures (whether permanent or not) that form, or are to form, part of the land;
(b) the construction, alteration, repair, restoration, maintenance, extension, demolition or dismantling of any works that form, or are to form, part of the land, including walls, roadworks, powerlines, telecommunication apparatus, aircraft runways, docks and harbours, railways, inland waterways, pipelines, reservoirs, water mains, wells, sewers, industrial plant and installa
```

### `section:4` · section · Application of Act

```text
4.—(1) Subject to subsection (2), this Act applies to any contract that is made in writing on or after 1 April 2005, whether or not the contract is expressed to be governed by the law of Singapore.
(2) This Act does not apply to —
(a) any contract for the carrying out of construction work at or on, or the supply of goods or services in relation to, any residential property (within the meaning of the Residential Property Act 1976), which does not require the approval of the Commissioner of Building Control under the Building Control Act 1989;
(b) any contract to the extent that —
(i) it contains provisions under which a party undertakes to carry out construction work, or to supply goods or se
```

### `section:5` · section · Entitlement to progress payments

```text
5. Any person who has carried out any construction work, or supplied any goods or services, under a contract is entitled to a progress payment. Amount of progress payment
```

### `section:6` · section · Amount of progress payment

```text
6. The amount of a progress payment to which a person is entitled under a contract is —
(a) the amount calculated in accordance with the terms of the contract; or
(b) if the contract does not contain such provision, the amount calculated on the basis of the value of the construction work carried out, or of the goods or services supplied, by the person under the contract. 11 Valuation of construction work, goods and services
```

### `section:7` · section · Valuation of construction work, goods and services

```text
7.—(1) Construction work carried out, or goods or services supplied, under a contract are to be valued —
(a) in accordance with the terms of the contract; or
(b) if the contract does not contain such provision, having regard to the matters specified in subsection (2).
(2) For the purpose of subsection (1)(b), construction work carried out, or goods or services supplied, under a contract are to be valued —
(a) having regard to —
(i) the contract price for the construction work, goods or services;
(ii) any other rate or price specified in the contract; and
(iii) any variation agreed to by the parties to the contract by which the contract price, or any other rate or price specified in the contr
```

