# CESA1973 · 必需品供应控制法 1973

- 语言：`en`
- 版本：`sg:CESA1973:en:src-60721b47f1d3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：32；切片：32；发布资格：否

PDF 页数 27，空白页 [2]，目录页 [1, 3, 4]，条文 30。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CONTROL OF ESSENTIAL SUPPLIES ACT 1973 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Control of Essential Supplies Act 1973 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Appointment of officers 4. Responsibilities of officers 5. Declaration of controlled and rationed articles 6. Regulations
PART 2 POWERS OF CONTROLLER 7. Licences and permits to sell controlled articles 8. Power of Controlle
```

### `section:1` · section · 

```text
1. This Act is the Control of Essential Supplies Act 1973. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “animal” includes birds, reptiles, fish and every kind of vertebrate animal and the young thereof, and the eggs of birds, reptiles and fish; 2 “article” includes every kind or description of thing or commodity; “controlled article” means any article or food, or any kind or type of article or food, which has been declared to be a controlled article by an order under section 5, and includes a rationed article; “Controller” means the officer appointed to be Controller of Supplies under section 3 and includes a Deputy Controller of Supplies, an Assistant Controller of Supplies and any person to whom the Controller has delegated any of his o
```

### `section:3` · section · Appointment of officers

```text
3. The Minister may appoint by name or office a Controller of Supplies, Deputy Controllers of Supplies, Assistant Controllers of Supplies and any other officers that the Minister considers necessary or expedient for the purposes of this Act. Responsibilities of officers
```

### `section:4` · section · Responsibilities of officers

```text
4.—(1) The Controller must, subject to the Minister’s general direction and control, perform the duties and exercise the rights and powers imposed and conferred upon him or her by this Act.
(2) The Deputy Controllers of Supplies, Assistant Controllers of Supplies and all other officers appointed under section 3 are under the direction and control of the Controller.
(3) All officers appointed under section 3 are deemed to be public servants for the purposes of the Penal Code 1871. Declaration of controlled and rationed articles
```

### `section:5` · section · Declaration of controlled and rationed articles

```text
5. The President may, by order in the Gazette, declare any article or food to be a controlled article or to be a rationed article or both. Regulations
```

### `section:6` · section · Regulations

```text
6.—(1) The Minister may make regulations generally for carrying into effect the provisions of this Act.
(2) Without limiting the powers conferred by subsection (1), any regulations made under this section may provide for — 4
(a) prohibiting, either absolutely or subject to prescribed conditions, the purchase or sale of any controlled article without the Controller’s written permission;
(b) prohibiting, regulating or controlling the import or export of any controlled article;
(c) prohibiting, regulating or controlling the movement of any controlled article;
(d) limiting wholesale or retail dealing in any controlled article to persons that hold licences or permits therefor as the regulations m
```

### `section:7` · section · Licences and permits to sell controlled articles

```text
7.—(1) The Controller may, subject to this Act and to conditions as he or she may think fit, by written licence or permit authorise any person to sell by wholesale or retail any controlled article in any premises or at a place or places specified in the licence. 6
(2) The Controller may issue or renew licences or permits to deal in controlled articles.
(3) Every licence or permit issued under this section is valid for the period that may be expressed therein and may, subject to any order made by any court under section 22(3), be renewed for a further period that the Controller thinks fit.
(4) Whenever, under this Act, any person is required to obtain a written licence or permit, the person m
```

