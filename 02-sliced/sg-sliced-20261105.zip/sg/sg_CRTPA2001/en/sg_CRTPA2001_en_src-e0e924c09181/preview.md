# CRTPA2001 · 合同（第三者权利）法（2001）

- 语言：`en`
- 版本：`sg:CRTPA2001:en:src-e0e924c09181`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：11；切片：10；发布资格：否

PDF 页数 13，空白页 [2]，目录页 [1, 3]，条文 9。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CONTRACTS (RIGHTS OF THIRD PARTIES) ACT 2001 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Contracts (Rights of Third Parties) Act 2001 ARRANGEMENT OF SECTIONS Section 1. Short title and application 2. Right of third party to enforce contractual term 3. Variation and rescission of contract 4. Defences, etc., available to promisor 5. Enforcement of contract by promisee 6. Protection of promisor from double liability 7. Exceptions 8
```

### `section:1` · section · 

```text
1.—(1) This Act is the Contracts (Rights of Third Parties) Act 2001.
(2) Subject to subsection (3), this Act does not apply in relation to a contract entered into before the end of the period of 6 months from 1 January 2002.
(3) The restriction in subsection (2) does not apply in relation to a contract which —
(a) is entered into on or after 1 January 2002; and
(b) expressly provides for the application of this Act. 1 Right of third party to enforce contractual term
```

### `section:2` · section · Right of third party to enforce contractual term

```text
2.—(1) Subject to the provisions of this Act, a person who is not a party to a contract (called in this Act a third party) may, in the third party’s own right, enforce a term of the contract if —
(a) the contract expressly provides that the third party may; or
(b) subject to subsection (2), the term purports to confer a benefit on the third party.
(2) Subsection (1)(b) does not apply if, on a proper construction of the contract, it appears that the parties did not intend the term to be enforceable by the third party.
(3) The third party must be expressly identified in the contract by name, as a member of a class or as answering a particular description, but need not be in existence when the 
```

### `section:3` · section · Variation and rescission of contract

```text
3.—(1) Subject to this section, where a third party has a right under section 2 to enforce a term of the contract, the parties to the contract may not, by agreement, rescind the contract, or vary the contract in such a way as to extinguish or alter the third party’s entitlement under that right, without the third party’s consent if —
(a) the third party has communicated the third party’s assent to the term to the promisor;
(b) the promisor is aware that the third party has relied on the term (whether or not the third party has knowledge of its precise terms); or
(c) the promisor can reasonably be expected to have foreseen that the third party would rely on the term and the third party has in
```

### `section:4` · section · Defences, etc., available to promisor

```text
4.—(1) Subsections (2) to (5) apply where proceedings for the enforcement of a term of a contract are brought by a third party in reliance on section 2.
(2) The promisor has available to the promisor, by way of defence or set-off, any matter that —
(a) arises from or in connection with the contract and is relevant to the term; and
(b) would have been available to the promisor by way of defence or set-off if the proceedings had been brought by the promisee.
(3) The promisor also has available to the promisor, by way of defence or set-off, any matter if —
(a) an express term of the contract provides for it to be available to the promisor in proceedings brought by the third party; and
(b) it wo
```

### `section:5` · section · Enforcement of contract by promisee

```text
5. Section 2 does not affect any right of the promisee to enforce any term of the contract. Protection of promisor from double liability
```

### `section:6` · section · Protection of promisor from double liability

```text
6. Where under section 2, a term of a contract is enforceable by a third party, and the promisee has recovered from the promisor a sum in respect of —
(a) the third party’s loss in respect of the term; or
(b) the expense to the promisee of making good to the third party the default of the promisor, then, in any proceedings brought in reliance on that section by the third party, the court or arbitral tribunal must reduce any award to the third party to such extent as it thinks appropriate to take account of the sum recovered by the promisee. 5 Exceptions
```

### `section:7` · section · Exceptions

```text
7.—(1) Section 2 does not confer any right on a third party in the case of a contract on a bill of exchange, promissory note or other negotiable instrument.
(2) Section 2 does not confer any right on a third party in the case of any contract binding on a company and its members under section 39 of the Companies Act 1967.
(3) Section 2 does not confer any right on a third party in the case of any registration document of a limited liability partnership registered under the Limited Liability Partnerships Act 2005 or any limited liability partnership agreement as defined in that Act.
[5/2005]
(4) Section 2 does not confer any right on a third party to enforce any term of a contract of employmen
```

