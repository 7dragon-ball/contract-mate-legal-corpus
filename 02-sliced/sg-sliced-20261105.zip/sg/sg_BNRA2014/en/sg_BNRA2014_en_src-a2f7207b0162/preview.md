# BNRA2014 · 商业名称注册法 2014

- 语言：`en`
- 版本：`sg:BNRA2014:en:src-a2f7207b0162`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：47；切片：50；发布资格：否

PDF 页数 55，空白页 []，目录页 [1, 2, 3]，条文 45。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE BUSINESS NAMES REGISTRATION ACT 2014 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Business Names Registration Act 2014 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Administration of Act and appointment of Registrar of Business Names, etc. 4. Persons not required to be registered under Act
PART 2 REGISTRATION 5. Requirement to register 6. Manner and particulars of registration 7. Registrat
```

### `section:1` · section · 

```text
1. This Act is the Business Names Registration Act 2014. 2 Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires —
[Deleted by Act 21 of 2024 wef 09/12/2024] “ACRA administered Act” means the Accounting and Corporate Regulatory Authority Act 2004 or any of the written laws specified in the Second Schedule to that Act;
[Act 21 of 2024 wef 09/12/2024] “authorised representative” means an authorised representative appointed under section 11(1); “Authority” means the Accounting and Corporate Regulatory Authority established under the Accounting and Corporate Regulatory Authority Act 2004; “business” includes every form of trade, commerce and profession, and any other activity, that is carried on for the purposes of gain, but does not include any off
```

### `section:3` · section · Business Names, etc.

```text
3.—(1) The Authority is responsible for the administration of this Act, subject to the general or special directions of the Minister.
(2) The Minister may, after consulting the Authority, appoint —
(a) an officer of the Authority to be the Registrar of Business Names; and
(b) such numbers of Deputy Registrars and Assistant Registrars of Business Names from among the officers of the Authority, public officers and the officers of any other statutory body, for the proper administration of this Act.
(3) The Registrar is responsible for keeping a register of registered persons and their registered business names, generally for the carrying out of the provisions of this Act, and for the collection
```

### `section:4` · section · Persons not required to be registered under Act

```text
4.—(1) The following persons are not required to be registered when carrying on business in Singapore:
(a) any individual proprietor carrying on business under only the individual proprietor’s full name;
(b) any firm of 2 or more individuals carrying on business under only the full names of all the individuals;
(c) subject to subsection (2), any individual or firm of 2 or more individuals carrying on any business consisting solely of the exercise of any profession that, under the provisions of any written law, can be exercised only by those who possess certain qualifications prescribed by the written law and whose names are registered or otherwise recorded in the manner prescribed by any wri
```

### `section:5` · section · Requirement to register

```text
5.—(1) Subject to the provisions of this Act, before a person carries on business in Singapore, the person and the person’s business name must be registered.
(2) Where a person intends to carry on business in Singapore under more than one business name, there must be separate registrations in respect of the person and each of those business names, and any reference to registration in this Act is to be construed accordingly. Manner and particulars of registration
```

### `section:6` · section · Manner and particulars of registration

```text
6.—(1) An application for registration —
(a) is to be lodged with the Registrar by an appropriate person; and
(b) is to contain the following particulars:
(i) the business name;
(ii) the general nature of the business;
(iii) the principal place of business;
(iv) where the business is to be carried on by an individual proprietor, the full name, identification, nationality, residential address and contact address of that individual proprietor;
[Act 21 of 2024 wef 09/12/2024]
(v) where the business is to be carried on by a sole proprietor that is a corporation, the corporate name, registration number and registered office of that corporation; 10
(vi) where the business is to be carried on by a 
```

### `section:7` · section · Registration by nominee or trustee

```text
7.—(1) Where a person (B) carries on a business wholly or mainly as nominee or trustee of or for another person (A), for the general purposes of the business in Singapore, B must, in addition to the particulars required by section 6, provide such particulars as may be prescribed. 12
(2) A person must not carry on business in Singapore as nominee or trustee of a foreign company. Registration
```

