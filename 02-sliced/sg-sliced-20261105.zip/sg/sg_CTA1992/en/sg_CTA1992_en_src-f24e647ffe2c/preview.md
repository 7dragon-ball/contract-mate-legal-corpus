# CTA1992 · 商品交易法 1992

- 语言：`en`
- 版本：`sg:CTA1992:en:src-f24e647ffe2c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：69；切片：69；发布资格：否

PDF 页数 61，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]，条文 66。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE COMMODITY TRADING ACT 1992 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Commodity Trading Act 1992 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Application
PART 2 COMMODITY MARKET AND CLEARING HOUSE 4. Establishment of commodities markets 5. Power of Board to approve commodity market 6. Business rules 7. Revocation of approval 8. Establishment of clearing house 9. Power of Board to approv
```

### `section:4` · section · 

```text
4.—(1) No person may establish or maintain, assist in establishing or maintaining or hold the person out as providing or maintaining any commodity market unless the commodity market has been approved by the Board under section 5(2).
(2) As from 8 October 2018, subsection (1) ceases to apply in relation to any commodity market —
(a) that is established on or after that date; or
(b) that was approved under subsection (1) before that date, to the extent that it relates to commodity forward contracts.
[4/2017]
(3) A person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $30,000 or to imprisonment for a term not exceeding 3 ye
```

### `section:5` · section · Power of Board to approve commodity market

```text
5.—(1) A body corporate may apply to the Board for approval as a commodity market in such form and manner as may be prescribed and the body corporate must, in connection with that application, provide such information as the Board may require.
(2) The Board may, in writing, approve a body corporate as a commodity market if it is satisfied that —
(a) the business rules of the body corporate make satisfactory provision for the matters referred to in section 6;
(b) the interests of the public will be served by granting the application. 12
(3) The Board must not refuse to approve a body corporate as a commodity market under this section without giving the applicant an opportunity of being heard.
```

### `section:6` · section · Business rules

```text
6.—(1) The business rules of every body corporate which has applied for approval or which has been approved as a commodity market under section 5 must make satisfactory provision —
(a) for the exclusion from membership of persons who are not of good character and high business integrity;
(b) for the expulsion, suspension or disciplining of members for conduct inconsistent with just and equitable principles in the transaction of business, or for a contravention of the business rules of the proposed commodity market;
(c) with respect to the terms and conditions under which commodity contracts may be made;
(d) with respect to the clearing and other arrangements made and the financial conditions
```

### `section:7` · section · Revocation of approval

```text
7.—(1) The Board may revoke any approval granted under section 5 if —
(a) the body corporate ceases to operate as a commodity market;
(b) the body corporate is being wound up;
(c) the body corporate is operating in a manner detrimental to the public interest; or
(d) any information provided to the Board under section 5(1) was false or misleading in a material particular.
(2) For the purposes of subsection (1)(a), a body corporate is deemed to have ceased to operate as a commodity market if it has ceased to operate for more than 30 days unless it has obtained the approval of the Board to do so, or unless it has ceased to operate by virtue of any direction issued by the Board under section 34(
```

### `section:8` · section · Establishment of clearing house

```text
8.—(1) No person may establish, maintain or provide or assist in establishing, maintaining or providing, or hold the person out as maintaining or providing a clearing house for a commodity market unless the person is a body corporate approved as a clearing house under section 9. 14
(2) As from 8 October 2018, subsection (1) ceases to apply in relation to any clearing house —
(a) that is established on or after that date; or
(b) that was approved under subsection (1) before that date, to the extent that it relates to commodity forward contracts.
[4/2017]
(3) A person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $30,000 
```

### `section:9` · section · Power of Board to approve clearing house

```text
9.—(1) A body corporate may apply to the Board for approval as a clearing house in such form and manner as may be prescribed and the body corporate must, in connection with that application, provide such information as the Board may require.
(2) The Board may in writing approve a body corporate as a clearing house if it is satisfied that —
(a) the business rules of the body corporate make satisfactory provision relating to the registration of, and guaranteeing to its members of the performance of, commodity contracts made in a commodity market; and
(b) the interests of the public will be served by granting the application. Appeal to Minister
```

### `section:10` · section · Appeal to Minister

```text
10. A person who is aggrieved by the decision of the Board made under section 5, 7 or 9 may, within 30 days of the decision, appeal to the Minister whose decision is final. Liabilities of commodity market and clearing house
```

