# MA2008 · 放债人法 2008

- 语言：`en`
- 版本：`sg:MA2008:en:src-bb7e57f85a60`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：97；切片：105；发布资格：否

PDF 页数 148，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]，条文 95。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE MONEYLENDERS ACT 2008 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Moneylenders Act 2008 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. Interpretation 3. Persons presumed to be moneylenders 4. Appointment of Registrar, etc.
PART 2 LICENSING OF MONEYLENDERS 5. No moneylending except under licence, etc. 6. Renewal of licences 7. Licensees to be companies 8. Other grounds for refusing to issue 
```

### `section:4` · section · 

```text
4. The Minister may appoint any public officer to be the Registrar of Moneylenders and any number of public officers that the Minister thinks fit to be Deputy Registrars of Moneylenders and Assistant Registrars of Moneylenders under this Act.
PART 2 LICENSING OF MONEYLENDERS No moneylending except under licence, etc.
```

### `section:5` · section · No moneylending except under licence, etc.

```text
5.—(1) A person must not carry on or hold out in any way that the person is carrying on the business of moneylending in Singapore, whether as principal or as agent, unless the person —
(a) is authorised to do so by a licence;
(b) is an excluded moneylender; or
(c) is an exempt moneylender.
(2) For the purposes of subsection (1), a person who wholly or partly carries on, from a place outside Singapore, the business of moneylending in Singapore is taken to have carried on that business in Singapore.
(3) The Minister may prescribe different classes or descriptions of licences for the purposes of this Act.
(4) An application for the issue of a licence must be —
(a) made in the form and manner de
```

### `section:6` · section · Renewal of licences

```text
6.—(1) An application for the renewal of a licence must be made at least one month before the expiry of the licence, in the form and manner determined by the Registrar.
(2) For the purpose of subsection (1), every licensee must notify the Registrar at least one month before the expiry of the licence if the licensee does not wish to renew the licence.
(3) The Registrar may renew a licence with or without conditions, or may refuse to renew a licence.
(4) Without affecting sections 7 and 8, the Registrar must not renew a licence —
(a) where any information or statement furnished by the licensee that is material to the application for the renewal of the licence under this section is incomplete, 
```

### `section:7` · section · Licensees to be companies

```text
7.—(1) On and after 29 March 2019 —
(a) no person other than a company with a paid-up capital that is equal to or greater than the prescribed amount may hold a licence; and
(b) the Registrar must not issue or renew a licence unless the applicant is a company with a paid-up capital that is equal to or greater than the prescribed amount.
[7/2018]
(2) A licence that is granted to a person that is not a company with a paid-up capital that is equal to or greater than the prescribed amount, and that is in force immediately before 29 March 2019, is deemed to be revoked as from 29 March 2019.
[7/2018]
(3) The revocation of a licence under subsection (2) does not affect any moneylending transaction e
```

### `section:8` · section · Other grounds for refusing to issue or renew licence, etc.

```text
8.—(1) For the purposes of sections 5 and 6, the Registrar may refuse to issue or renew a licence on any of the following grounds: 11
(a) if any person who is or will be responsible for the management of the applicant’s business of moneylending is not ordinarily resident in Singapore;
(b) if any director of the applicant or any person who is or will be responsible for the management of the applicant’s business of moneylending is below 21 years of age;
(c) if the Registrar is not satisfied that the applicant has any place of business in respect of which the licence is to be issued or renewed that is suitable for a business of moneylending, or the Registrar is of the view that it is not in the
```

### `section:9` · section · Licence fee

```text
9.—(1) Every licensee must pay such licence fee as may be prescribed for the issue or renewal of the licence by the Registrar.
(2) The Minister may prescribe different licence fees in respect of different classes or descriptions of licences.
(3) Where a licensee has more than one place of business, the licensee must pay such additional licence fee as may be prescribed for each additional place of business according to the class or description of licence which the licensee holds.
(4) The licence fees must be paid in the manner specified by the Registrar.
(5) Subject to subsection (6), there is no refund of any licence fee paid to the Registrar in the event that a licence is revoked or suspend
```

### `section:10` · section · Revocation or suspension of licence

```text
10.—(1) The Registrar may revoke a licence, or suspend it for any period that he or she considers appropriate, if the Registrar is satisfied —
(a) that the licensee —
(i) has ceased to carry on the business of moneylending, or is wound up or otherwise dissolved;
(ii) has not carried on the business of moneylending within 6 months, or such longer period as the Registrar may approve in writing, after the issue of the licence;
(iii) had, in connection with an application for the issue or renewal of the licence — 16 (A) knowingly recklessly furnished information or statement to the Registrar which was false or misleading in a material particular; (B) wilfully omitted to state any matter without 
```

