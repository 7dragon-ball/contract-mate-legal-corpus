# CBCA1960 · 法人团体合同法 1960

- 语言：`en`
- 版本：`sg:CBCA1960:en:src-37e93bef1c72`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：5；切片：4；发布资格：否

PDF 页数 5，空白页 []，目录页 [1, 2]，条文 3。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CORPORATE BODIES’ CONTRACTS ACT 1960 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Act 1960 ARRANGEMENT OF SECTIONS Section 1. Cases where contracts need not be under seal 2. Exclusion of companies under Companies Act 1967, etc. 3. Short title An Act to amend the law governing the making of contracts by or on behalf of bodies corporate; and for connected purposes.
[12 November 1993] Cases where contracts need not be under seal
```

### `section:1` · section · 

```text
1.—(1) Contracts may be made on behalf of any body corporate, wherever incorporated, as follows:
(a) a contract which if made between private persons would by law be required to be in writing, signed by the parties to be charged therewith, may be made on behalf of the body corporate in writing signed by any person acting under its authority, express or implied; and
(b) a contract which if made between private persons would by law be valid although made by parol only, and not reduced into writing, may be made by parol on behalf of the body corporate by any person acting under its authority, express or implied.
(2) A contract made according to this section shall be effectual in law, and shall 
```

### `section:2` · section · Exclusion of companies under Companies Act 1967, etc.

```text
2. This Act shall not apply to any company as defined in the Companies Act 1967, any limited liability partnership as defined in the Limited Liability Partnerships Act 2005 or any variable capital company as defined in the Variable Capital Companies Act 2018.
[5/2005]
[S 26/2022 wef 13/01/2022] Short title
```

### `section:3` · section · Short title

```text
3. This Act may be cited as the Corporate Bodies’ Contracts Act 1960. Act 1960 2
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY CORPORATE BODIES’ CONTRACTS ACT 1960 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act.
1. 8 & 9 Eliz. II, c. 46 — Corporate Bodies’ Contracts Act, 1960 Commencement : 29 July 1960 Application : 12 November 1993 Note: This Act was declared by the Application of English Law Act 1993 to apply or continue to apply in Singapore on 12 November 1993.
2. 1994 Revised Edition — Corporate Bodies’ Contracts Act (Chapter 385) Operation : 20 May 1994
3. Act 5 of 2005 — Limited Liability Partnerships Act 2005 (Amendments made by section 60(1) read with item (6) of the Sixth Schedule to the above Act) Bill :
```

