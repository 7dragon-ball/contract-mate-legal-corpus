# UCTA1977 · 不公平合同条款法（1977）

- 语言：`en`
- 版本：`sg:UCTA1977:en:src-f92bf4bde9f3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：27；切片：26；发布资格：否

PDF 页数 18，空白页 [2]，目录页 [1, 3, 4]，条文 23。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE UNFAIR CONTRACT TERMS ACT 1977 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Unfair Contract Terms Act 1977 ARRANGEMENT OF SECTIONS
PART 1 Section Introductory 1. Scope of this Part Avoidance of liability for negligence, breach of contract, etc. 2. Negligence liability 3. Liability arising in contract 4. Unreasonable indemnity clauses Liability arising from sale or supply of goods 5. “Guarantee” of consumer goods 6. Sale and hire-
```

### `section:1` · section · 

```text
1.—(1) For the purposes of this Part, “negligence” means the breach —
(a) of any obligation, arising from the express or implied terms of a contract, to take reasonable care or exercise reasonable skill in the performance of the contract; or
(b) of any common law duty to take reasonable care or exercise reasonable skill (but not any stricter duty).
(2) This Part is subject to Part 3; and in relation to contracts, the operation of sections 2 to 4 and 7 is subject to the exceptions made by the First Schedule. 2
(3) In the case of both contract and tort, sections 2 to 7 apply (except where the contrary is stated in section 6(4)) only to business liability, that is liability for breach of obliga
```

### `section:2` · section · Negligence liability

```text
2.—(1) A person cannot by reference to any contract term or to a notice given to persons generally or to particular persons exclude or restrict his liability for death or personal injury resulting from negligence.
(2) In the case of other loss or damage, a person cannot so exclude or restrict his liability for negligence except in so far as the term or notice satisfies the requirement of reasonableness.
(3) Where a contract term or notice purports to exclude or restrict liability for negligence, a person’s agreement to or awareness of it is not of itself to be taken as indicating his voluntary acceptance of any risk. Liability arising in contract
```

### `section:3` · section · Liability arising in contract

```text
3.—(1) This section applies as between contracting parties where one of them deals as consumer or on the other’s written standard terms of business.
(2) As against that party, the other cannot by reference to any contract term —
(a) when himself in breach of contract, exclude or restrict any liability of his in respect of the breach; or 3
(b) claim to be entitled —
(i) to render a contractual performance substantially different from that which was reasonably expected of him; or
(ii) in respect of the whole or any part of his contractual obligation, to render no performance at all, except in so far as (in any of the cases mentioned in this subsection) the contract term satisfies the requireme
```

### `section:4` · section · Unreasonable indemnity clauses

```text
4.—(1) A person dealing as consumer cannot by reference to any contract term be made to indemnify another person (whether a party to the contract or not) in respect of liability that may be incurred by the other for negligence or breach of contract, except in so far as the contract term satisfies the requirement of reasonableness.
(2) This section applies whether the liability in question —
(a) is directly that of the person to be indemnified or is incurred by him vicariously;
(b) is to the person dealing as consumer or to someone else. Liability arising from sale or supply of goods “Guarantee” of consumer goods
```

### `section:5` · section · “Guarantee” of consumer goods

```text
5.—(1) In the case of goods of a type ordinarily supplied for private use or consumption, where loss or damage —
(a) arises from the goods proving defective while in consumer use; and
(b) results from the negligence of a person concerned in the manufacture or distribution of the goods, liability for the loss or damage cannot be excluded or restricted by reference to any contract term or notice contained in or operating by reference to a guarantee of the goods. 4
(2) For these purposes —
(a) goods are to be regarded as “in consumer use” when a person is using them, or has them in his possession for use, otherwise than exclusively for the purposes of a business; and
(b) anything in writing is 
```

### `section:6` · section · Sale and hire-purchase

```text
6.—(1) Liability for breach of the obligations arising from —
(a) section 12 of the Sale of Goods Act 1979 (seller’s implied undertakings as to title, etc.); or
(b) section 6 of the Hire-Purchase Act 1969 (the corresponding thing in relation to hire-purchase), cannot be excluded or restricted by reference to any contract term.
(2) As against a person dealing as consumer, liability for breach of the obligations arising from —
(a) section 13, 14 or 15 of the Sale of Goods Act 1979 (seller’s implied undertakings as to conformity of goods with description or sample, or as to their quality or fitness for a particular purpose); or
(b) section 6A, 6B or 6C of the Hire-Purchase Act 1969 (the corresp
```

### `section:7` · section · Miscellaneous contracts under which goods pass

```text
7.—(1) Where the possession or ownership of goods passes under or in pursuance of a contract not governed by the law of sale of goods or hire-purchase, subsections (2) to (4) apply as regards the effect (if any) to be given to contract terms excluding or restricting liability for breach of obligation arising by implication of law from the nature of the contract.
(2) As against a person dealing as consumer, liability in respect of the goods’ correspondence with description or sample, or their quality or fitness for any particular purpose, cannot be excluded or restricted by reference to any such term.
(3) As against a person dealing otherwise than as consumer, that liability can be excluded o
```

