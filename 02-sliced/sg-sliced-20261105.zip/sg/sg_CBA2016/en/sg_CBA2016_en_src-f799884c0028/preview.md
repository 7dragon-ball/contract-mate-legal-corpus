# CBA2016 · 信用信息局法 2016

- 语言：`en`
- 版本：`sg:CBA2016:en:src-f799884c0028`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：86；切片：88；发布资格：否

PDF 页数 107，空白页 []，目录页 [1, 2, 3, 4, 5, 6]，条文 82。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE CREDIT BUREAU ACT 2016 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Credit Bureau Act 2016 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Purpose of Act 4. Application of Act 5. Appointment of assistants
PART 2 LICENSING OF CREDIT BUREAUS 6. Licensing of credit bureaus 7. Application for licence 8. Renewal of licence 9. Holding out as licensed credit bureau 10. Annual fees of licensed credi
```

### `section:1` · section · 

```text
1. This Act is the Credit Bureau Act 2016. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “advocate and solicitor” means an advocate and solicitor of the Supreme Court or a foreign lawyer as defined in section 2(1) of the Legal Profession Act 1966; “approved member”, in relation to a licensed credit bureau, means a member of the licensed credit bureau that is —
(a) deemed to be an approved member of the licensed credit bureau under section 29(1); or
(b) approved by the Authority under section 29(6)(a); “Authority” means the Monetary Authority of Singapore established under the Monetary Authority of Singapore Act 1970; “bank”, “bank in Singapore” and “banking business” have the meanings given by section 2(1) of the Banking Ac
```

### `section:3` · section · Purpose of Act

```text
3. The purpose of this Act is to regulate —
(a) licensed credit bureaus;
(b) approved members of any licensed credit bureau in relation to —
(i) their providing data to the credit bureau for the purpose of the credit bureau’s credit reporting business; and 10
(ii) their using and disclosing data received from the credit bureau in the course of the credit bureau’s credit reporting business; and
(c) matters relating to or connected with the above. Application of Act
```

### `section:4` · section · Application of Act

```text
4.—(1) Subject to subsection (2), this Act does not apply to any public authority.
(2) The Minister may by order declare that a public authority is one to which this Act applies.
(3) The provisions in Parts 3 and 6 of the Act are in addition to, and do not derogate from, anything in the Personal Data Protection Act 2012. Appointment of assistants
```

### `section:5` · section · Appointment of assistants

```text
5.—(1) Subject to subsection (2), the Authority may appoint any of its officers to exercise any of its powers or perform any of its functions or duties under this Act, either generally or in any particular case, except the power —
(a) of appointment conferred by this subsection; and
(b) to make subsidiary legislation.
(2) The Authority may appoint one or more of its officers to exercise the power under a provision of this Act specified in the Second Schedule to grant an exemption to a particular person, or to revoke any such exemption.
[Act 5 of 2025 wef 09/03/2025]
(2A) An appointment under subsection (2) must be published in the Gazette.
[Act 5 of 2025 wef 09/03/2025]
(3) Any officer appoi
```

### `section:6` · section · Licensing of credit bureaus

```text
6.—(1) Subject to the provisions of this Act, a person must not carry on any type of credit reporting business unless the person is licensed by the Authority under this Act in respect of that type of credit reporting business.
(2) Any person that contravenes this section shall be guilty of an offence and shall be liable on conviction —
(a) in the case of an individual, to a fine not exceeding $125,000 or to imprisonment for a term not exceeding 3 years or to both and, in the case of a continuing offence, to a further fine not exceeding $12,500 for every day or part of a day during which the offence continues after conviction; or
(b) in any other case, to a fine not exceeding $250,000 and, in
```

### `section:7` · section · Application for licence

```text
7.—(1) A person that desires to carry on a credit reporting business must apply in writing to the Authority for a licence under this section.
(2) Subject to subsection (3), the person in subsection (1) may apply for a licence to carry on —
(a) a consumer credit reporting business;
(b) a corporate credit reporting business; or
(c) both a consumer credit reporting business and a corporate credit reporting business.
(3) Upon receiving an application under subsection (1), the Authority must consider the application and may grant a licence to the applicant with or without conditions, or refuse to grant a licence. 12
(4) The Authority must not grant a licence to an applicant unless —
(a) the appli
```

