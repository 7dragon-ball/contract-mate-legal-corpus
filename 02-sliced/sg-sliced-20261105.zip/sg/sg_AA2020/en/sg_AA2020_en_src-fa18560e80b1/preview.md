# AA2020 · 海牙认证法 2020

- 语言：`en`
- 版本：`sg:AA2020:en:src-fa18560e80b1`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：34；切片：34；发布资格：否

PDF 页数 20，空白页 [2]，目录页 [1, 3, 4]，条文 30。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE APOSTILLE ACT 2020 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Apostille Act 2020 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Purpose 4. Act binds Government
PART 2 PROOF OF ORIGIN OF FOREIGN PUBLIC DOCUMENTS 5. Application of this Part 6. What is a foreign public document 7. What is meant by the origin of a foreign public document 8. What is legalisation of a foreign public document 9.
```

### `section:1` · section · 

```text
1. This Act is the Apostille Act 2020. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “Convention” means the Hague Convention Abolishing the Requirement of Legalisation for Foreign Public Documents, done at the Hague on 5 October 1961, the English text of which is set out in the First Schedule; “Convention State” means a State Party to the Convention other than Singapore, but does not include —
(a) any State Party that objected to Singapore’s accession to the Convention; and
(b) any State Party whose accession to the Convention Singapore objected to; 2 “Model Certificate” means the model certificate set out in the Annex to the Convention. Purpose
```

### `section:3` · section · Purpose

```text
3.—(1) The purpose of this Act is to give effect to the Convention.
(2) Part 2 —
(a) exempts foreign public documents (as defined in that Part) from any requirement of legalisation; and
(b) provides for the effect of certificates issued under the Convention and facilitates (but does not require) their use.
(3) Part 3 provides for certificates to be issued under the Convention for Singapore public documents (as defined in that Part). Act binds Government
```

### `section:4` · section · Act binds Government

```text
4. This Act binds the Government.
PART 2 PROOF OF ORIGIN OF FOREIGN PUBLIC DOCUMENTS Application of this Part
```

### `section:5` · section · Application of this Part

```text
5. This Part applies to a foreign public document sought to be produced in Singapore for any purpose, including —
(a) the purposes of proceedings in any court or tribunal; and
(b) the purposes of exercising any power or right, or performing any function, duty or obligation, under or pursuant to any written law or rule of law. 3 What is a foreign public document
```

### `section:6` · section · What is a foreign public document

```text
6. In this Part, “foreign public document” —
(a) means —
(i) a document executed in the territory of a Convention State and falling within any of the following categories: (A) a document emanating from an authority or official connected with the courts or tribunals of that State, including a document emanating from a public prosecutor, a clerk of a court or a process-server; (B) an administrative document; (C) a notarial act; (D) an official certificate that is placed on a document signed by a person in his or her private capacity (for example, an official certificate recording the registration of a document or the fact that the document was in existence on a certain date, or an official or 
```

### `section:7` · section · What is meant by the origin of a foreign public document

```text
7. In this Part, a reference to the origin of a foreign public document, or of a document purporting to be a foreign public document, is a reference to the following aspects of the document:
(a) the authenticity of the signature on the document; 4
(b) the capacity in which the person signing the document has acted;
(c) where appropriate, the identity of the seal or stamp that the document bears. What is legalisation of a foreign public document
```

