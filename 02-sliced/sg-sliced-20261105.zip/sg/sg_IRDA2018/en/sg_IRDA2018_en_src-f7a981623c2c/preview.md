# IRDA2018 · 破产、重组与解散法（2018）

- 语言：`en`
- 版本：`sg:IRDA2018:en:src-f7a981623c2c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：570；切片：593；发布资格：否

PDF 页数 573，空白页 []，目录页 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]，条文 565。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE INSOLVENCY, RESTRUCTURING AND DISSOLUTION ACT 2018 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Insolvency, Restructuring and Dissolution Act 2018 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title and commencement 2. General interpretation
PART 2 JURISDICTION, POWERS AND PROCEDURE OF COURT
Division 1 — Jurisdiction 3. General Division of High Court to be court that has jurisdiction in corporate and individual inso
```

### `section:1` · section · 

```text
1.—(1) This Act is the Insolvency, Restructuring and Dissolution Act 2018.
(2) Sections 467(h) and 479 come into operation on a date that the Minister appoints by notification in the Gazette. 22 General interpretation
```

### `section:2` · section · General interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “banking corporation” means a bank that holds a valid licence under section 7 or 79 of the Banking Act 1970; “bankrupt” means —
(a) an individual debtor who has been adjudged bankrupt by a bankruptcy order; or
(b) where a bankruptcy order has been made against a firm, each of the partners in the firm; “company” has the meaning given by section 4(1) of the Companies Act 1967; “contributory” has the meaning given by section 4(1) of the Companies Act 1967; “corporation” has the meaning given by section 4(1) of the Companies Act 1967; “Court” means the General Division of the High Court; “creditors’ committee”, in relation to a bankrupt
```

### `section:3` · section · jurisdiction in corporate and individual insolvency, etc.

```text
3. Subject to any other written law, the General Division of the High Court is the court that has jurisdiction in corporate insolvency and winding up, individual insolvency and bankruptcy, and related matters under this Act.
[40/2019] Exercise of jurisdiction in chambers
```

### `section:4` · section · Exercise of jurisdiction in chambers

```text
4. Subject to this Act and the Rules, any judge of the Court may exercise in chambers the whole or any part of the Court’s jurisdiction under this Act. Jurisdiction of Registrar under this Act
```

### `section:5` · section · Jurisdiction of Registrar under this Act

```text
5. Subject to the Rules —
(a) the Registrar has all the powers and jurisdiction of the Court; and
(b) any order made or act done by the Registrar in the exercise of those powers and jurisdiction is, subject to an appeal to a judge in chambers, deemed to be the order or act of the Court. General powers of Court under this Act
```

### `section:6` · section · General powers of Court under this Act

```text
6.—(1) Subject to this Act, the Court, when exercising its jurisdiction under this Act, has full power to decide all questions of priorities and all other questions, whether of law or fact, that may arise in any case or matter under this Act coming within the cognizance of the Court, or that the Court considers expedient or necessary to decide for the purpose of doing complete justice or making a complete distribution of property in any such case or matter.
(2) The Court may adjourn any case or matter under this Act coming within the cognizance of the Court, or make such order or 26 give such direction as the Court thinks fit for the just, expeditious and economical disposal of any such case
```

### `section:7` · section · Power to review orders

```text
7. The Court may review, rescind or vary any order made by the Court when exercising its jurisdiction under this Act. Appeals under this Act
```

