# AIIDA1968 · 仲裁（国际投资争端）法 1968

- 语言：`en`
- 版本：`sg:AIIDA1968:en:src-a41876bb10ef`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：13；切片：19；发布资格：否

PDF 页数 29，空白页 []，目录页 [1, 2]，条文 10。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE ARBITRATION (INTERNATIONAL INVESTMENT DISPUTES) ACT 1968 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Arbitration (International Investment Disputes) Act 1968 ARRANGEMENT OF SECTIONS Section 1. Short title 2. Interpretation 3. Binding on Government 4. Registration of Convention awards 5. Effect of registration 6. Power to make rules 7. Government contribution to expenses under Convention 8. Exclusion of Arbitration Act 2001 9. Ce
```

### `section:1` · section · 

```text
1. This Act is the Arbitration (International Investment Disputes) Act 1968. Interpretation
```

### `section:2` · section · Interpretation

```text
2.—(1) In this Act, unless the context otherwise requires — “award” includes any decision interpreting, reversing or annulling an award, being a decision pursuant to the Convention, and any decision as to costs which under the Convention is to form part of the award; 1 “Centre” means the International Centre for Settlement of Investment Disputes established by the Convention; “Convention” means the Convention on the Settlement of Investment Disputes between States and Nationals of other States which was opened for signature in Washington on 18 March 1965 and is set out in the Schedule.
(2) An award shall be deemed to have been rendered pursuant to the Convention on the date on which certifie
```

### `section:3` · section · Binding on Government

```text
3. Sections 4 and 5 shall bind the Government (but not so as to make an award enforceable against the Government in a manner in which a judgment would not be enforceable against the Government). Registration of Convention awards
```

### `section:4` · section · Registration of Convention awards

```text
4.—(1) Any person seeking recognition or enforcement of an award rendered pursuant to the Convention shall be entitled to have the award registered in the General Division of the High Court subject to proof of any matters that may be prescribed and to the other provisions of this Act.
[40/2019]
(2) In addition to the pecuniary obligations imposed by the award, the award shall be registered for the reasonable costs of and incidental to registration.
(3) If at the date of the application for registration the pecuniary obligations imposed by the award have been partly satisfied, the award shall be registered only in respect of the balance, and accordingly if those obligations have been wholly s
```

### `section:5` · section · Effect of registration

```text
5. Subject to the provisions of this Act, an award registered under section 4 shall, as respects the pecuniary obligations which it imposes, be of the same force and effect for the purposes of enforcement as if it had been a judgment of the General Division of 2 the High Court given when the award was rendered pursuant to the Convention and entered on the date of registration under this Act, and, so far as relates to such pecuniary obligations —
(a) proceedings may be taken on the award;
(b) the sum for which the award is registered shall carry interest; and
(c) the General Division of the High Court shall have the same control over the enforcement of the award, as if the award had been such
```

### `section:6` · section · Power to make rules

```text
6. The Supreme Court Judges, or any 3 of them, of whom the Chief Justice shall be one, may make rules —
(a) to prescribe the procedure for applying for registration of an award under this Act, and to require the applicant to give prior notice of his intention to register to other parties;
(b) to prescribe matters to be proved on the application and the manner of proof, and in particular to require the applicant to furnish a copy of the award certified pursuant to the Convention;
(c) to provide for the service of notice of registration of the award by the applicant on other parties; and
(d) to provide for the stay of enforcement (whether provisionally or otherwise) of any award registered und
```

### `section:7` · section · Government contribution to expenses under Convention

```text
7. Any sums required to meet any obligations of the Government arising out of Article 17 of the Convention (which obliges the 3 Contracting States to meet any deficit of the Centre) shall be charged on and paid out of the Consolidated Fund. Exclusion of Arbitration Act 2001
```

