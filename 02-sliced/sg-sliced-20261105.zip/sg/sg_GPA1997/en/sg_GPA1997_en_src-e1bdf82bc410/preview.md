# GPA1997 · 政府采购法（1997）

- 语言：`en`
- 版本：`sg:GPA1997:en:src-e1bdf82bc410`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：28；切片：27；发布资格：否

PDF 页数 23，空白页 [2]，目录页 [1, 3, 4]，条文 26。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE GOVERNMENT PROCUREMENT ACT 1997 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Government Procurement Act 1997 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation 3. Relevant State or relevant Protocol State 4. Application 5. Certification by Minister
PART 2 REGULATIONS GOVERNING PROCUREMENT 6. Power to make regulations 7. Duty of contracting authority
PART 3 CHALLENGE PROCEEDINGS 8. Government Procu
```

### `section:1` · section · 

```text
1. This Act is the Government Procurement Act 1997. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “Agreement on Government Procurement” means the Agreement by that name done at Marrakesh on 15 April 1994 and amended by the Protocol; “applicant” has the meaning given by section 12(1); “award”, in relation to a contract or tender, means to accept an offer made; “challenge proceeding” means any proceeding under Part 3; 2 “Commissioner” means the Commissioner appointed under section 8(2) and includes an acting Commissioner appointed under section 8(9); “contracting authority” means a ministry or department of the Government, an Organ of State or a statutory board declared, by order made under section 4(1), as a contracting authority for
```

### `section:3` · section · Relevant State or relevant Protocol State

```text
3. The Minister may, from time to time, by order in the Gazette, declare any country or territory as a relevant State or relevant Protocol State for the purposes of this Act.
[2/2014] Application
```

### `section:4` · section · Application

```text
4.—(1) The Minister may, by order in the Gazette, declare any ministry or department of the Government, Organ of State or statutory board as a contracting authority for the purposes of this Act.
(2) The Minister may, by order in the Gazette, declare a procurement to be subject to the Act.
(3) An order made under subsection (2) may identify the procurement by one or more of the following:
(a) the means by which the procurement is undertaken;
(b) the contracting authority undertaking the procurement;
(c) the goods or service, or combination of goods and service, to be procured;
(d) the value of the procurement.
(4) An order made under subsection (2) may specify —
(a) the method by which the pr
```

### `section:5` · section · Certification by Minister

```text
5.—(1) The Minister may issue a certificate certifying that a particular procurement is not a procurement subject to the Act by virtue of section 4(4)(b).
(2) The Minister may issue a certificate certifying that a ground referred to in section 4(4)(c) exists in relation to a particular procurement or an act or measure in relation to a particular procurement.
(3) A certificate issued under subsection (1) or (2) is conclusive evidence of the matters so certified. 6
PART 2 REGULATIONS GOVERNING PROCUREMENT Power to make regulations
```

### `section:6` · section · Power to make regulations

```text
6.—(1) The Minister may, for the purposes of implementing the Agreement on Government Procurement and other international obligations of Singapore relating to procurements by the Government and public authorities, make regulations to govern procurements subject to the Act.
[28/2004]
(2) Without limiting subsection
(1), the regulations may prescribe —
(a) the technical specifications for a procurement;
(b) the procedure for qualification of suppliers for a procurement;
(c) the procedure for the award of a procurement contract and the procedure following such award;
(d) the provision of any information pertaining to a procurement; and
(e) different provisions for different procurements.
[28/20
```

### `section:7` · section · Duty of contracting authority

```text
7.—(1) Subject to an order made under section 4(2), a contracting authority must, in undertaking a procurement subject to the Act, comply with the regulations made under section 6.
(2) The duty of a contracting authority referred to in subsection (1) is a duty owed to —
(a) relevant suppliers or relevant Protocol suppliers in relation to that procurement; and
(b) such other supplier or class of suppliers as the Minister may, by order published in the Gazette, declare.
[28/2004; 2/2014] 7
(3) A breach of a duty referred to in subsection (1) is not to be the subject of any proceedings in any court but may be the subject of a challenge brought before the Tribunal by a supplier to whom the duty 
```

