# MA1967 · 失实陈述法（1967）

- 语言：`en`
- 版本：`sg:MA1967:en:src-12db0f24602f`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：6；切片：5；发布资格：否

PDF 页数 6，空白页 [2]，目录页 [1, 3, 4]，条文 4。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE MISREPRESENTATION ACT 1967 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Misrepresentation Act 1967 ARRANGEMENT OF SECTIONS Section 1. Removal of certain bars to rescission for innocent misrepresentation 2. Damages for misrepresentation 3. Avoidance of provision excluding liability for misrepresentation 4. Saving for past transactions 5. Short title An Act to amend the law relating to innocent misrepresentations.
[12 November 1993
```

### `section:2` · section · 

```text
2.—(1) Where a person has entered into a contract after a misrepresentation has been made to him by another party thereto and as a result thereof he has suffered loss, then, if the person making the misrepresentation would be liable to damages in respect thereof had the misrepresentation been made fraudulently, that person shall be so liable notwithstanding that the misrepresentation was not made fraudulently, unless he proves that he had reasonable ground to believe and did believe up to the time the contract was made that the facts represented were true.
(2) Where a person has entered into a contract after a misrepresentation has been made to him otherwise than fraudulently, and he would b
```

### `section:3` · section · misrepresentation

```text
3. If a contract contains a term which would exclude or restrict —
(a) any liability to which a party to a contract may be subject by reason of any misrepresentation made by him before the contract was made; or 2
(b) any remedy available to another party to the contract by reason of such a misrepresentation, that term shall be of no effect except in so far as it satisfies the requirement of reasonableness as stated in section 11(1) of the Unfair Contract Terms Act 1977, and it is for those claiming that the term satisfies that requirement to show that it does. Saving for past transactions
```

### `section:4` · section · Saving for past transactions

```text
4. Nothing in this Act applies in relation to any misrepresentation or contract of sale made before 12 November 1993 except in so far as it was applicable by virtue of section 5 of the Civil Law Act 1909 in force before that date. Short title
```

### `section:5` · section · Short title

```text
5. This Act may be cited as the Misrepresentation Act 1967. 3
```

### `supplement:historical` · supplement · 

```text
LEGISLATIVE HISTORY MISREPRESENTATION ACT 1967 This Legislative History is a service provided by the Law Revision Commission on a best-efforts basis. It is not part of the Act.
1. U.K. 1967, c. 7 — Misrepresentation Act 1967 Commencement : 22 April 1967 Application : 12 November 1993 Note: This Act was declared by the Application of English Law Act 1993 to apply or continue to apply in Singapore on 12 November 1993.
2. 1994 Revised Edition — Misrepresentation Act (Chapter 390) Operation : 20 May 1994 Abbreviations C.P. Council Paper G.N. No. S (N.S.) Government Notification Number Singapore (New Series) G.N. No. Government Notification Number G.N. No. S Government Notification Number Singapo
```

