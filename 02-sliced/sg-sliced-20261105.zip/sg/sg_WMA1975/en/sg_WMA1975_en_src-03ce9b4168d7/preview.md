# WMA1975 · 度量衡法 1975

- 语言：`en`
- 版本：`sg:WMA1975:en:src-03ce9b4168d7`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：55；切片：58；发布资格：否

PDF 页数 67，空白页 []，目录页 [1, 2, 3, 4]，条文 50。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE WEIGHTS AND MEASURES ACT 1975 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Weights and Measures Act 1975 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 UNITS AND STANDARDS OF MEASUREMENT 3. Units of measurement 4. Standard weights and measures
PART 3 WEIGHING AND MEASURING FOR TRADE 5. Meaning of “use for trade” 6. Units of measurements and weights lawful for use for trade 7. Weighing o
```

### `section:2` · section · 

```text
2.—(1) In this Act, unless the context otherwise requires — “Accuracy Label” means a mark referred to in section 7(2)(d)(ii) for use as evidence of the passing of any weighing or measuring instrument as fit for use for trade; “Authorised Verifier” means any person appointed by the Commission under section 29A;
[Act 13 of 2025 wef 01/07/2025]
[Deleted by Act 13 of 2025 wef 01/07/2025] “catch weight goods” means goods that —
(a) are enclosed in a package;
(b) cannot be portioned to a predetermined quantity because of their nature; and
(c) are usually sold in varying quantities; 3 “check-weighed”, in relation to any vehicle, means weighed with its load by means of the nearest suitable and avail
```

### `section:3` · section · Units of measurement

```text
3.—(1) The metre is the unit of measurement of length and the kilogram is the unit of measurement of mass by reference to which any measurement involving a measurement of length or mass is to be made in Singapore.
[30/2005]
(2) The First Schedule has effect for defining, for the purposes of measurements falling to be made in Singapore, the units of measurements set out in that Schedule; and for the purposes of any measurement of weight falling to be so made, the weight of anything may be expressed, by reference to the units of measurements set out in Part 5 of that Schedule, in the same terms as its mass. 7 Standard weights and measures
```

### `section:4` · section · Standard weights and measures

```text
4.—(1) There is to be maintained by the Agency for Science, Technology and Research established under section 3 of the Agency for Science, Technology and Research Act 1990 or any other person that the Minister may, by notification in the Gazette, specify the standards of the metre and kilogram (called in this Act the Singapore standards) by reference to which all other standards of —
(a) those units; and
(b) any other unit of measurement derived wholly or partly from any of those units, are maintained.
[30/2005; 54/2007]
(2) The Minister must from time to time as may appear to him or her expedient cause —
(a) the value of each of the Singapore standards to be determined or redetermined; and

```

### `section:5` · section · Meaning of “use for trade”

```text
5.—(1) For the purposes of this Act, “use for trade” means, subject to subsection (2), use in Singapore in connection with, or with a view to, a transaction for —
(a) the transferring or rendering of money or money’s worth in consideration of money or money’s worth; or
(b) the making of a payment in respect of any toll or duty, where —
(c) the transaction is by reference to quantity or is a transaction for the purposes of which there is made or implied a statement of the quantity of goods to which the transaction relates; and
(d) the use is for the purpose of the determination or statement of that quantity.
(2) Subsection (1) does not apply where —
(a) the determination or statement is a det
```

### `section:6` · section · Units of measurements and weights lawful for use for trade

```text
6.—(1) Subject to section 40, a person must not use for trade any unit of measurement of length, area, volume, capacity, mass or weight which is not included in the First Schedule.
(2) A person must not use the carat (metric) for trade except for the purposes of transactions in precious stones or pearls.
[30/2005]
(3) Any person who contravenes subsection (1) or (2) shall be guilty of an offence, and any measure or weight used, or in any person’s possession for use, in contravention of any of those subsections shall be liable to be forfeited.
[30/2005]
(4) The Minister may by regulations prescribe what may be treated for the purposes of use for trade as the equivalent of, or of any multiple 
```

### `section:7` · section · Weighing or measuring instruments for use for trade

```text
7.—(1) This section applies to weighing or measuring instruments of any class or description that may be prescribed.
[30/2005]
(2) A person must not —
(a) supply for use for trade; or
(b) use for trade, or have in the person’s possession for use for trade, any weighing or measuring instrument to which this section applies unless —
(c) the instrument has been submitted to and passed as being fit for such use by an Authorised Verifier under section 7A or an inspector under section 7B; and
(d) except as otherwise expressly provided under this Act or by regulations made under section 10, the instrument has been affixed with —
(i) a stamp; and
(ii) an Accuracy Label, 11
(d) indicating that it has
```

### `section:7A` · section · Inspection and testing by Authorised Verifier

```text
7A.—(1) Any person requiring any weighing or measuring instrument to which section 7 applies to be tested for its fitness for 12 use for trade by an Authorised Verifier must submit the instrument to the Authorised Verifier in the manner that the Authorised Verifier may require.
[30/2005]
(2) An Authorised Verifier may charge any fee that he or she may determine for the testing of any weighing or measuring instrument submitted to him or her under subsection (1).
[30/2005]
(3) On payment of the fee, the Authorised Verifier must inspect the weighing or measuring instrument and —
(a) test the instrument for its fitness for use for trade by means of any method of testing, working standard and tes
```

