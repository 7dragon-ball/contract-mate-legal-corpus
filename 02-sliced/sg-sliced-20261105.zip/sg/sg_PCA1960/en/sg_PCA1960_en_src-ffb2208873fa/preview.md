# PCA1960 · 防止贪污法（1960）

- 语言：`en`
- 版本：`sg:PCA1960:en:src-ffb2208873fa`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：46；切片：46；发布资格：否

PDF 页数 37，空白页 [2]，目录页 [1, 3, 4, 5]，条文 44。

## 结构单元摘录（前 8 条）

### `preface:1` · preface · 

```text
THE STATUTES OF THE REPUBLIC OF SINGAPORE PREVENTION OF CORRUPTION ACT 1960 2020 REVISED EDITION This revised edition incorporates all amendments up to and including 1 December 2021 and comes into operation on 31 December 2021. Prepared and Published by THE LAW REVISION COMMISSION UNDER THE AUTHORITY OF THE REVISED EDITION OF THE LAWS ACT 1983 Prevention of Corruption Act 1960 ARRANGEMENT OF SECTIONS
PART 1 PRELIMINARY Section 1. Short title 2. Interpretation
PART 2 APPOINTMENT OF STAFF AND PERSONNEL MATTERS 3. Appointment of Director and officers 4. Director and officers deemed to be public servants 4A. Establishment of Occupational Superannuation Scheme 4B. Benefits not as of right, etc. 4
```

### `section:1` · section · 

```text
1. This Act is the Prevention of Corruption Act 1960. Interpretation
```

### `section:2` · section · Interpretation

```text
2. In this Act, unless the context otherwise requires — “agent” means any person employed by or acting for another, and includes a trustee, administrator and executor, and a person serving the Government or under any corporation or public body, and for the purposes of section 8 includes a subcontractor and any person employed by or acting for such subcontractor; “CPIB officer” means a public officer in the Corrupt Practices Investigation Service (Junior) Scheme of Service or in the Corrupt Practices Investigation Service (Senior) Scheme of Service; “Director” means the Director of the Corrupt Practices Investigation Bureau appointed under section 3; “gratification” includes —
(a) money or an
```

### `section:3` · section · Appointment of Director and officers

```text
3.—(1) The President may appoint an officer to be the Director of the Corrupt Practices Investigation Bureau: Provided that the President acting in his discretion may refuse to appoint or revoke the appointment of the Director if he does not concur with the advice or recommendation of the Cabinet or a Minister acting under the general authority of the Cabinet.
(2) The President may appoint such number of deputy directors, assistant directors and special investigators of the Corrupt Practices Investigation Bureau as he may think fit.
[2/2012]
(3) Any powers conferred on and duties to be performed by the Director under this Act may, subject to the orders and directions of the Director, be exer
```

### `section:4` · section · Director and officers deemed to be public servants

```text
4.—(1) The Director, deputy directors, assistant directors and special investigators of the Corrupt Practices Investigation Bureau shall be deemed to be public servants within the meaning of the Penal Code 1871.
[2/2012] 5
(2) A warrant card shall be issued to every officer of the Corrupt Practices Investigation Bureau referred to in subsection (1) and shall be evidence of his appointment under this Act.
[2/2012] Establishment of Occupational Superannuation Scheme
```

### `section:4A` · section · Establishment of Occupational Superannuation Scheme

```text
4A.—(1) The Minister shall, by regulations, establish an Occupational Superannuation Scheme for the benefit of all CPIB officers appointed on or after 1 November 2001, who will be the members of the Scheme.
[29/2002]
(2) The regulations made under subsection (1) shall provide for the payment of —
(a) any gratuity, allowance, superannuation or other like benefit to members of the Scheme, or to their legal personal representatives or dependants, on the death of the members in the service or on the resignation, retirement or discharge of the members from the service;
(b) any pension, gratuity, allowance, compensation or other benefit in respect of the death of or injuries received by any member
```

### `section:4B` · section · Benefits not as of right, etc.

```text
4B.—(1) No member shall have an absolute right to compensation for past services or to any pension, gratuity, allowance or other benefit under the Scheme.
[29/2002]
(2) Nothing in this Act shall limit the right of the Public Service Commission, or any of its delegates, to dismiss any CPIB officer who is a member from the service without compensation.
[29/2002]
(3) Subject to Article 113 of the Constitution, where it is established to the satisfaction of an award officer that a member has been guilty of negligence, irregularity or misconduct, it shall be lawful for the award officer to reduce or altogether withhold the pension, gratuity, allowance or other benefit for which the member would b
```

### `section:4C` · section · Non-assignability or attachment of benefits, etc.

```text
4C.—(1) No payments, allowance or other benefit payable under the Scheme (whether on death, retirement or resignation of a member or otherwise), and no contribution by the Government made under the Scheme, and no interest thereon shall be assignable or transferable, or liable to be garnished, attached, sequestered or levied upon for or in respect of any debt or claim, other than —
(a) a debt due to the Government; or
(b) an order of court for the payment of periodical sums of money towards the maintenance of the wife or former wife or minor child (whether legitimate or not) of the member to 8 whom the payment, allowance or other benefit has been granted.
[29/2002]
(2) Subject to the provisio
```

