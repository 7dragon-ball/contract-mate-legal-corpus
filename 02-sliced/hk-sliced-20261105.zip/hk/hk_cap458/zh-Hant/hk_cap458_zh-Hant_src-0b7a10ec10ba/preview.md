# Cap. 458 · 《不合情理合約條例》

- 语言：`zh-Hant`
- 版本：`hk:cap458:zh-Hant:src-0b7a10ec10ba`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：22；切片：22；发布资格：否

文本覆盖对账：True，片段 171，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在授權法庭就某些經裁定屬不合情理的合約給予濟助。
```

### `note:1` · note · 

```text
[1995年10月20日]1995年第476號法律公告
```

### `note:2` · note · 

```text
(格式變更——2021年第6號編輯修訂紀錄)
```

### `other:enactingformula:4/note:3` · note · 

```text
(略去制定語式條文——2021年第6號編輯修訂紀錄)
```

### `heading:part:6` · heading · 第I部 導言

```text
第I部 導言
```

### `section:1/note:4` · note · 

```text
(編輯修訂——2021年第6號編輯修訂紀錄)
```

### `section:1/note:5` · note · 

```text
(已失時效而略去——2021年第6號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
(1)
本條例可引稱為《不合情理合約條例》。
(2)
```

