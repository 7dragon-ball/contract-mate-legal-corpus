# Cap. 458 · 《不合情理合約條例》

- 语言：`en`
- 版本：`hk:cap458:en:src-c4672a9c9d3f`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：22；切片：22；发布资格：否

文本覆盖对账：True，片段 171，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to empower courts to give relief in certain contracts found to be unconscionable.
```

### `note:1` · note · 

```text
[20 October 1995]L.N. 476 of 1995
```

### `note:2` · note · 

```text
(Format changes—E.R. 6 of 2021)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 6 of 2021)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 6 of 2021)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 6 of 2021)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Unconscionable Contracts Ordinance.
(2)
```

