# Cap. 457 · 《服務提供(隱含條款)條例》

- 语言：`en`
- 版本：`hk:cap457:en:src-77596738de91`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：25；切片：25；发布资格：否

文本覆盖对账：True，片段 125，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to consolidate and amend the law with respect to the terms to be implied in contracts for the supply of services.
```

### `note:1` · note · 

```text
[21 October 1994]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2021)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2021)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Supply of Services (Implied Terms) Ordinance.
```

### `section:2/note:4` · note · 

```text
(Amended 65 of 2000 s. 3)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance—
business (業務) includes—
(a)
a profession;
(b)
the activities of a public body or public authority; and
(c)
the activities of a board, commission, committee or other body appointed by the Chief Executive or Government.
```

