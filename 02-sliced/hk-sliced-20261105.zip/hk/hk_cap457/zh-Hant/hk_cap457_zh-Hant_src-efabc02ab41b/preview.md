# Cap. 457 · 《服務提供(隱含條款)條例》

- 语言：`zh-Hant`
- 版本：`hk:cap457:zh-Hant:src-efabc02ab41b`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：26；切片：26；发布资格：否

文本覆盖对账：True，片段 130，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合及修訂關乎服務提供合約中隱含的條款的法律。
```

### `note:1` · note · 

```text
[1994年10月21日]
```

### `note:2` · note · 

```text
(格式變更——2021年第1號編輯修訂紀錄)
```

### `other:enactingformula:4/note:3` · note · 

```text
(略去制定語式條文——2021年第1號編輯修訂紀錄)
```

### `heading:part:6` · heading · 第I部 導言

```text
第I部 導言
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《服務提供(隱含條款)條例》。
```

### `section:2/note:4` · note · 

```text
(由2000年第65號第3條修訂)
```

### `section:2` · section · 釋義

```text
2.
釋義
在本條例中 ——
業務 (business)包括 ——
(a)
專業；
(b)
公共機構或公共主管當局的事務；及
(c)
由行政長官或政府委任的各類委員會或其他同類團體的事務。
```

