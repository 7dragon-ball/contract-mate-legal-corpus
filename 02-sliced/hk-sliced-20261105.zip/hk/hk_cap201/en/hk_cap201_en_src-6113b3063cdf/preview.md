# Cap. 201 · 《防止賄賂條例》

- 语言：`en`
- 版本：`hk:cap201:en:src-6113b3063cdf`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：700；切片：543；发布资格：否

文本覆盖对账：True，片段 2996，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make further and better provision for the prevention of bribery and for purposes necessary thereto or connected therewith.
```

### `note:1` · note · 

```text
[14 May 1971]L.N. 58 of 1971
```

### `heading:part:3` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Prevention of Bribery Ordinance.
```

### `section:2/note:3` · note · 

```text
(Amended 33 of 1991 s. 2; 10 of 2000 s. 47)
```

### `section:2/note:4` · note · 

```text
(Replaced 28 of 1980 s. 2)
```

### `section:2/note:5` · note · 

```text
(Replaced 1 of 2003 s. 3)
```

