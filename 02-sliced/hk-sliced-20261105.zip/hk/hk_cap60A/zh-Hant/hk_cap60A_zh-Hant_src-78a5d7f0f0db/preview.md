# Cap. 60A · 《進出口(一般)規例》

- 语言：`zh-Hant`
- 版本：`hk:cap60A:zh-Hant:src-78a5d7f0f0db`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：424；切片：429；发布资格：否

文本覆盖对账：True，片段 2785，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《進出口(一般)規例》
```

### `other:enactingformula:2` · other · 

```text
(第60章第31條)
```

### `note:1` · note · 

```text
[1972年1月1日]
```

### `note:2` · note · 

```text
(格式變更——2012年第1號編輯修訂紀錄)
```

### `heading:part:5` · heading · 第1部 導言

```text
第1部 導言
```

### `section:1` · section · 引稱

```text
1.
引稱
本規例可引稱為《進出口(一般)規例》。
```

### `section:2/note:3` · note · 

```text
(2003年第93號法律公告；2025年第30號第30條)
```

### `section:2/note:4` · note · 

```text
(2003年第93號法律公告)
```

