# Cap. 60A · 《進出口(一般)規例》

- 语言：`en`
- 版本：`hk:cap60A:en:src-414a6478623c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：419；切片：420；发布资格：否

文本覆盖对账：True，片段 2771，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Import and Export (General) Regulations
```

### `other:enactingformula:2` · other · 

```text
(Cap. 60, section 31)
```

### `note:1` · note · 

```text
[1 January 1972]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2012)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1` · section · Citation

```text
1.
Citation
These regulations may be cited as the Import and Export (General) Regulations.
```

### `section:2/note:3` · note · 

```text
(L.N. 93 of 2003)
```

### `section:2/note:4` · note · 

```text
(L.N. 111 of 1993)
```

