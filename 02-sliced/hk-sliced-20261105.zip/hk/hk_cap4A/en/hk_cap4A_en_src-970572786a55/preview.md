# Cap. 4A · 《高等法院規則》

- 语言：`en`
- 版本：`hk:cap4A:en:src-970572786a55`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：2007；切片：2186；发布资格：否

文本覆盖对账：True，片段 29591，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
The Rules of the High Court
```

### `other:enactingformula:2` · other · 

```text
(Cap. 4, section 54)
```

### `note:1` · note · 

```text
[1 May 1988]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2018)
```

### `note:3` · note · 

```text
Editorial Note: The title of these Rules was amended from “The Rules of the Supreme Court” to “The Rules of the High Court” — see 25 of 1998 s. 2 (adaptation amendments retroactively made).
```

### `heading:crossheading:6` · heading · Preliminary

```text
Preliminary
```

### `section:1/note:4` · note · 

```text
(25 of 1998 s. 2)
```

### `table:section:1:1/note:5` · note · 

```text
(28 of 2012 ss. 912 & 920)
```

