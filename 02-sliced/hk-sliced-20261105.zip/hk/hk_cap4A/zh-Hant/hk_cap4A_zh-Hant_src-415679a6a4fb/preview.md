# Cap. 4A · 《高等法院規則》

- 语言：`zh-Hant`
- 版本：`hk:cap4A:zh-Hant:src-415679a6a4fb`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：2219；切片：2643；发布资格：否

文本覆盖对账：True，片段 32712，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《高等法院規則》
```

### `other:enactingformula:2` · other · 

```text
(第4章第54條)
```

### `note:1` · note · 

```text
[1988年5月1日]
```

### `note:2` · note · 

```text
(格式變更——2018年第1號編輯修訂紀錄)
```

### `note:3` · note · 

```text
編輯附註： 本規則的名稱由《最高法院規則》修訂為《高等法院規則》——見1998年第25號第2條(具追溯力的適應化修訂)。
```

### `heading:crossheading:6` · heading · 導言

```text
導言
```

### `section:1/note:4` · note · 

```text
(1998年第25號第2條)
```

### `table:section:1:1/note:5` · note · 

```text
(2012年第28號第912及920條)
```

