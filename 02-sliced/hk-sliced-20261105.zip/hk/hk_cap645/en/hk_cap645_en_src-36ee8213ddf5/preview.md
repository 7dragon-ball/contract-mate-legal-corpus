# Cap. 645 · 《內地民商事判決(相互強制執行)條例》

- 语言：`en`
- 版本：`hk:cap645:en:src-36ee8213ddf5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：58；切片：58；发布资格：否

文本覆盖对账：True，片段 992，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to make provisions for the enforcement in Hong Kong of judgments in civil and commercial matters given in the Mainland, and for facilitating the recognition and enforcement in the Mainland of such judgments given in Hong Kong, so as to give effect to the Arrangement on Reciprocal Recognition and Enforcement of Judgments in Civil and Commercial Matters by the Courts of the Mainland and of the Hong Kong Special Administrative Region made between the Supreme People’s Court of the People’s Republic of China and the Government of the Hong Kong Special Administrative Region; and to provide for related matters.
```

### `note:1` · note · 

```text
[29 January 2024] L.N. 153 of 2023
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2024)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:3` · note · 

```text
(Amended E.R. 2 of 2024)
```

### `section:1/note:4` · note · 

```text
(Omitted as spent—E.R. 2 of 2024)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Mainland Judgments in Civil and Commercial Matters (Reciprocal Enforcement) Ordinance.
(2)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
(1)
In this Ordinance—
arbitral tribunal (仲裁庭) means a sole arbitrator or a panel of arbitrators, and includes an umpire;
Court means the Court of First Instance;
effective (生效)—
(a)
in relation to a Mainland Judgment—see section 8; and
(b)
in relation to a Hong Kong Judgment—see section 9;
excluded judgment (被排除的判決)—see section 5(1);
Hong Kong Judgment (香港判決) means a judgment, order, decree, allocatur, or certificate of fixed costs, however described, given or made by a specified Hong Kong court, but does not include an order for interim relief or an anti-suit injunction;
Hong Kong Judgment in a civil or commercial matter (香港民商事判決)—see section 4;
judgment creditor (判定債權人),
```

