# Cap. 645 · 《內地民商事判決(相互強制執行)條例》

- 语言：`zh-Hant`
- 版本：`hk:cap645:zh-Hant:src-4fe9bdbe1d40`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：58；切片：62；发布资格：否

文本覆盖对账：True，片段 993，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在為以下事宜訂定條文：在香港強制執行內地的民商事判決，以及利便在內地承認和強制執行香港的民商事判決，以實施由中華人民共和國最高人民法院與香港特別行政區政府簽訂的《關於內地與香港特別行政區法院相互認可和執行民商事案件判決的安排》；並就相關事宜，訂定條文。
```

### `note:1` · note · 

```text
[2024年1月29日 ] 2023年第153號法律公告
```

### `other:enactingformula:3/note:2` · note · 

```text
(略去制定語式條文——2024年第2號編輯修訂紀錄)
```

### `heading:part:5` · heading · 第1部 導言

```text
第1部 導言
```

### `section:1/note:3` · note · 

```text
(編輯修訂——2024年第2號編輯修訂紀錄)
```

### `section:1/note:4` · note · 

```text
(已失時效而略去——2024年第2號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
(1)
本條例可引稱為《內地民商事判決(相互強制執行)條例》。
(2)
```

### `section:2` · section · 釋義

```text
2.
釋義
(1)
在本條例中 ——
已登記判決 (registered judgment)指已按照登記令而登記的內地民商事判決或上述判決的部分；
內地 (Mainland)指香港、澳門及台灣以外的中國其他部分；
《內地反不正當競爭法》 (Mainland Anti-Unfair Competition Law)指《中華人民共和國反不正當競爭法》；
內地民商事判決 (Mainland Judgment in a civil or commercial matter) ——參閱第3條；
內地判決 (Mainland Judgment)指由內地法院作出的判決、裁定、調解書或繳付令，但不包括就臨時措施作出的裁定；
內地判案法院 (original Mainland court)就某內地判決而言，指作出該判決的內地法院；
生效 (effective) ——
(a)
就內地判決而言——參閱第8條；及
(b)
就香港判決而言——參閱第9條；
仲裁庭 (arbitral tribunal)指一名獨任仲裁員或一組仲裁員，並包括一名公斷人；
判定債權人 (judgment creditor)就某內地民商事判決或香港民商事判決而言，指該判決所惠及的人，而在該判決所賦權利藉繼承、轉讓或其他途徑而轉歸某人的情況下，亦包括該人；
指明知識產權 (specified intellectual property right)指 ——
(a)
版權或有關權利；
(b)
商標；
(c)
地理標誌；
(d)
工業外觀設計；
(e)
專利；
(f)
集成電路的布圖設計(拓樸圖)；
(g)
保護未被披露的資料的權利；
```

