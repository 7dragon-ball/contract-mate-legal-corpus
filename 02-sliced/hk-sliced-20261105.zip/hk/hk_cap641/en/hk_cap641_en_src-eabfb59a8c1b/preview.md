# Cap. 641 · 《貨物銷售(聯合國公約)條例》

- 语言：`en`
- 版本：`hk:cap641:en:src-eabfb59a8c1b`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：288；切片：288；发布资格：否

文本覆盖对账：True，片段 667，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to implement the United Nations Convention on Contracts for the International Sale of Goods.
```

### `note:1` · note · 

```text
[1 December 2022] L.N. 160 of 2022
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2023)
```

### `section:1/note:3` · note · 

```text
(Amended E.R. 1 of 2023)
```

### `section:1/note:4` · note · 

```text
(Omitted as spent—E.R. 1 of 2023)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Sale of Goods (United Nations Convention) Ordinance.
(2)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance—
Convention (《公約》) means the United Nations Convention on Contracts for the International Sale of Goods done at Vienna on 11 April 1980, as set out in the Schedule.
```

### `section:3` · section · Application to Government

```text
3.
Application to Government
This Ordinance applies to the Government.
```

