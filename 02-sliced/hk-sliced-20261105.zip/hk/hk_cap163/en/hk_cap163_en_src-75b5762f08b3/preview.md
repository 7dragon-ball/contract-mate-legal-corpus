# Cap. 163 · 《放債人條例》

- 语言：`en`
- 版本：`hk:cap163:en:src-75b5762f08b3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：190；切片：190；发布资格：否

文本覆盖对账：True，片段 1624，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To provide for the control and regulation of money lenders and money-lending transactions, the appointment of a Registrar of Money Lenders and the licensing of persons carrying on business as money lenders; to provide protection and relief against excessive interest rates and extortionate stipulations in respect of loans; to provide for offences and for matters connected with or incidental to the foregoing; and to repeal the Money-lenders Ordinance 1911.
```

### `note:1` · note · 

```text
[12 December 1980]L.N. 347 of 1980
```

### `note:2` · note · 

```text
(Format changes—E.R. 3 of 2018)
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title and application

```text
1.
Short title and application
(1)
This Ordinance may be cited as the Money Lenders Ordinance.
(2)
This Ordinance shall have effect notwithstanding any agreement to the contrary.
```

### `section:2/note:3` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920)
```

### `section:2/note:4` · note · 

```text
(Added 28 of 2012 ss. 912 & 920)
```

### `section:2/note:5` · note · 

```text
(Added 69 of 1988 s. 2)
```

