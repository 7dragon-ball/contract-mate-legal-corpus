# Cap. 112 · 《稅務條例》

- 语言：`en`
- 版本：`hk:cap112:en:src-36d890087cb8`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：4559；切片：4682；发布资格：否

文本覆盖对账：True，片段 68669，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To impose a tax on property, earnings and profits.
```

### `note:1` · note · 

```text
(Amended 26 of 1969 s. 2; 17 of 1989 s. 2)
```

### `note:2` · note · 

```text
[3 May 1947]
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2012)
```

### `heading:part:5` · heading · Part 1 Introductory

```text
Part 1 Introductory
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Inland Revenue Ordinance.
```

### `section:2/note:4` · note · 

```text
(Added 15 of 2020 s. 3)
```

### `section:2/note:5` · note · 

```text
(Replaced 13 of 1971 s. 2. Amended 76 of 1975 s. 2; 74 of 1981 s. 4; 30 of 1990 s. 2; 78 of 1999 s. 7)
```

