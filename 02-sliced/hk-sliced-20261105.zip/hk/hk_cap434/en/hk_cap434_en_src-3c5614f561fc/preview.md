# Cap. 434 · 《商船(限制船東責任)條例》

- 语言：`en`
- 版本：`hk:cap434:en:src-3c5614f561fc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：248；切片：248；发布资格：否

文本覆盖对账：True，片段 1112，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to provide for and to limit the liability of shipowners and others, and for ancillary matters.
```

### `note:1` · note · 

```text
[1 October 1993] L.N. 381 of 1993
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2022)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 3 of 2015)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 1 of 2022)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 3 of 2015)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Merchant Shipping (Limitation of Shipowners Liability) Ordinance.
(2)
```

