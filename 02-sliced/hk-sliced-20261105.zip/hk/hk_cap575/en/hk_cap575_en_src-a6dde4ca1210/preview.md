# Cap. 575 · 《聯合國(反恐怖主義措施)條例》

- 语言：`en`
- 版本：`hk:cap575:en:src-a6dde4ca1210`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：173；切片：175；发布资格：否

文本覆盖对账：True，片段 2279，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to further implement a decision of the Security Council of the United Nations in its Resolution 1373 of 28 September 2001 relating to measures for the prevention of terrorist acts, and in that connection, to permit the implementation of the United Nations International Convention for the Suppression of Terrorist Bombings, the United Nations Convention for the Suppression of Unlawful Acts Against the Safety of Maritime Navigation and the United Nations Protocol for the Suppression of Unlawful Acts Against the Safety of Fixed Platforms Located on the Continental Shelf; to implement certain Recommendations of the Financial Action Task Force; to further implement a decision of the S
```

### `note:1` · note · 

```text
(Amended 21 of 2004 s. 2; 14 of 2018 s. 3)
```

### `note:2` · note · 

```text
[23 August 2002]
```

### `note:3` · note · 

```text
(Format changes—E.R. 2 of 2012)
```

### `other:enactingformula:5/note:4` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2012)
```

### `heading:part:7` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:5` · note · 

```text
(Amended E.R. 2 of 2019)
```

### `section:1/note:6` · note · 

```text
(Omitted as spent—E.R. 2 of 2012)
```

