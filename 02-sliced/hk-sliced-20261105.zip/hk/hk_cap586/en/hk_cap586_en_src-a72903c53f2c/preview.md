# Cap. 586 · 《保護瀕危動植物物種條例》

- 语言：`en`
- 版本：`hk:cap586:en:src-a72903c53f2c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：804；切片：606；发布资格：否

文本覆盖对账：True，片段 7191，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to give effect in Hong Kong to the Convention on International Trade in Endangered Species of Wild Fauna and Flora signed in Washington D.C. on 3 March 1973; to regulate the import, introduction from the sea, export, re-export, and possession or control of certain endangered species of animals and plants and parts and derivatives of those species; and to provide for incidental and connected matters.
```

### `note:1` · note · 

```text
[1 December 2006]L.N. 206 of 2006
```

### `note:2` · note · 

```text
(Format changes—E.R. 5 of 2021)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 5 of 2021)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 5 of 2021)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 5 of 2021)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Protection of Endangered Species of Animals and Plants Ordinance.
(2)
```

