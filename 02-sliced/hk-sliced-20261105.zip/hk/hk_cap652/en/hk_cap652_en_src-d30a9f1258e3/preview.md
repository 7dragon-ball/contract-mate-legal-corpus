# Cap. 652 · 《建造業付款保障條例》

- 语言：`en`
- 版本：`hk:cap652:en:src-d30a9f1258e3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：173；切片：173；发布资格：否

文本覆盖对账：True，片段 2232，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to facilitate the recovery of payments under construction contracts; to provide a mechanism for speedy resolution of payment disputes under certain construction contracts through adjudication proceedings; to give a right to a party to a construction contract, under certain circumstances, to suspend or reduce the rate of progress of the construction work or the supply of related goods and services under the contract; and to provide for related matters.
```

### `note:1` · note · 

```text
[27 December 2024]
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2026)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `heading:division:6` · heading · Division 1 Short Title

```text
Division 1 Short Title
```

### `note:3` · note · 

```text
(Amended E.R. 2 of 2026)
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 2 of 2026)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 2 of 2026)
```

