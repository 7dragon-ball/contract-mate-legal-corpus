# Cap. 623 · 《合約(第三者權利)條例》

- 语言：`en`
- 版本：`hk:cap623:en:src-d75e9d8edd2a`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：23；切片：23；发布资格：否

文本覆盖对账：True，片段 377，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to provide for the enforcement of contractual terms by third parties and for related matters.
```

### `note:1` · note · 

```text
[1 January 2016]L.N. 118 of 2015
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2015)
```

### `section:1/note:3` · note · 

```text
(Amended E.R. 1 of 2016)
```

### `section:1/note:4` · note · 

```text
(Omitted as spent—E.R. 1 of 2016)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Contracts (Rights of Third Parties) Ordinance.
(2)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance—
promisee (受諾人), in relation to a term of a contract enforceable by a third party under section 4, means a party to the contract who may enforce the term against the promisor;
promisor (許諾人), in relation to a term of a contract enforceable by a third party under section 4, means a party to the contract against whom a third party may enforce the term;
third party (第三者), in relation to a contract, means a person who is not a party to the contract.
```

### `section:3/note:5` · note · 

```text
(Amended 16 of 2016 s. 47)
```

