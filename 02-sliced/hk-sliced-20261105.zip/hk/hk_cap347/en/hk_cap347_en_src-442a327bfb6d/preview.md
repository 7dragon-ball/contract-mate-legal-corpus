# Cap. 347 · 《時效條例》

- 语言：`en`
- 版本：`hk:cap347:en:src-442a327bfb6d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：146；切片：146；发布资格：否

文本覆盖对账：True，片段 1059，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate and amend the law relating to the limitation of actions.
```

### `note:1` · note · 

```text
(Amended 17 of 2010 s. 112)
```

### `note:2` · note · 

```text
[11 June 1965]
```

### `note:3` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Limitation Ordinance.
```

### `section:2/note:4` · note · 

```text
(Replaced 67 of 1976 s. 2)
```

### `section:2/note:5` · note · 

```text
(Amended E.R. 4 of 2020)
```

