# Cap. 347 · 《時效條例》

- 语言：`zh-Hant`
- 版本：`hk:cap347:zh-Hant:src-317c73bb05b5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：145；切片：151；发布资格：否

文本覆盖对账：True，片段 1073，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合及修訂有關訴訟時效的法律。
```

### `note:1` · note · 

```text
(由2010年第17號第112條修訂)
```

### `note:2` · note · 

```text
[1965年6月11日]
```

### `note:3` · note · 

```text
(格式變更——2020年第4號編輯修訂紀錄)
```

### `heading:part:5` · heading · 第I部 導言

```text
第I部 導言
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《時效條例》。
```

### `section:2/note:4` · note · 

```text
(由1976年第67號第2條代替)
```

### `section:2/note:5` · note · 

```text
(編輯修訂——2020年第4號編輯修訂紀錄)
```

