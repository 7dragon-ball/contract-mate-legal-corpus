# Cap. 68 · 《度量衡條例》

- 语言：`en`
- 版本：`hk:cap68:en:src-c39c75f65b2e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：99；切片：100；发布资格：否

文本覆盖对账：True，片段 1428，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make provision with respect to units and standards of measurement and weighing or measuring equipment used for trade, to regulate trade transactions regarding goods supplied by weight or measure including pre-packed goods, and to provide for the administration of this Ordinance, offences and the forfeiture of weighing or measuring equipment and goods in the case of certain contraventions; and for connected purposes.
```

### `note:1` · note · 

```text
[1 January 1989]L.N. 351 of 1988
```

### `note:2` · note · 

```text
(Format changes—E.R. 3 of 2022)
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Weights and Measures Ordinance.
```

### `section:2/note:3` · note · 

```text
(Amended 65 of 2000 s. 3)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance, unless the context otherwise requires—
authorized officer (獲授權人員) means any public officer authorized by the Commissioner of Customs and Excise under section 4;
authorized unit (認可單位) means a unit of measurement specified in the Second Schedule;
Commissioner (關長) means any of the following—
(a)
the Commissioner of Customs and Excise;
(b)
any Deputy Commissioner of Customs and Excise;
(c)
any Assistant Commissioner of Customs and Excise;
container (容器) means any form of packaging of goods for supply as a single item, and includes a wrapper or confining band;
inspection (檢查), in relation to weighing or measuring equipment, includes the examination, testing,
```

### `section:3` · section · Application

```text
3.
Application
(1)
This Ordinance shall apply without prejudice to the Metrication Ordinance (Cap. 214) and to any orders made under that Ordinance.
(2)
Unless the Commissioner of Customs and Excise by order in the Gazette so provides, this Ordinance shall not apply to the supply or measurement of—
(a)
water, other than in a container; or
(b)
the quantity of any goods, other than by mass or weight, length, width, height, area, volume, capacity or number.
```

