# Cap. 296A · 《儲備商品(進出口及儲備存貨管制)規例》

- 语言：`zh-Hant`
- 版本：`hk:cap296A:zh-Hant:src-44df28b61cb3`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：78；切片：79；发布资格：否

文本覆盖对账：True，片段 739，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《儲備商品(進出口及儲備存貨管制)規例》
```

### `other:enactingformula:2` · other · 

```text
(第296章第3條)
```

### `note:1` · note · 

```text
[1979年11月1日]
```

### `note:2` · note · 

```text
(格式變更——2020年第2號編輯修訂紀錄)
```

### `section:1` · section · 引稱

```text
1.
引稱
本規例可引稱為《儲備商品(進出口及儲備存貨管制)規例》。
```

### `section:2/note:3` · note · 

```text
(2000年第29號第8條)
```

### `section:2/note:4` · note · 

```text
(2000年第29號第8條)
```

### `section:2/note:5` · note · 

```text
(2003年第35號法律公告)
```

