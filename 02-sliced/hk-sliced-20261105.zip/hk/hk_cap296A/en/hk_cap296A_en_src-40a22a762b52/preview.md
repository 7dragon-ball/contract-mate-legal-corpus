# Cap. 296A · 《儲備商品(進出口及儲備存貨管制)規例》

- 语言：`en`
- 版本：`hk:cap296A:en:src-40a22a762b52`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：78；切片：78；发布资格：否

文本覆盖对账：True，片段 739，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Reserved Commodities (Control of Imports, Exports and Reserve Stocks) Regulations
```

### `other:enactingformula:2` · other · 

```text
(Cap. 296, section 3)
```

### `note:1` · note · 

```text
[1 November 1979]
```

### `note:2` · note · 

```text
(Format changes—E.R. 2 of 2020)
```

### `section:1` · section · Citation

```text
1.
Citation
These regulations may be cited as the Reserved Commodities (Control of Imports, Exports and Reserve Stocks) Regulations.
```

### `section:2/note:3` · note · 

```text
(29 of 2000 s. 8)
```

### `section:2/note:4` · note · 

```text
(29 of 2000 s. 8)
```

### `section:2/note:5` · note · 

```text
(L.N. 35 of 2003)
```

