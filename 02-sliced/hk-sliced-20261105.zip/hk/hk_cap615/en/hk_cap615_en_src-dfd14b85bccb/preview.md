# Cap. 615 · 《打擊洗錢及恐怖分子資金籌集條例》

- 语言：`en`
- 版本：`hk:cap615:en:src-dfd14b85bccb`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：825；切片：838；发布资格：否

文本覆盖对账：True，片段 15329，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to provide for the imposition of requirements relating to customer due diligence and record-keeping on specified financial institutions and designated non-financial businesses and professions; to provide for the powers of the relevant authorities and regulatory bodies to supervise compliance with those requirements and other requirements under this Ordinance; to provide for the regulation of the operation of a money service and the licensing of money service operators; to provide for the regulation of the operation of a trust or company service and the licensing of trust or company service providers; to provide for the regulation of activities involving virtual assets and the li
```

### `note:1` · note · 

```text
(Amended 4 of 2018 s. 3; 15 of 2022 s. 3)
```

### `note:2` · note · 

```text
[8 July 2011]
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2012)
```

### `note:4` · note · 

```text
(Format changes—E.R. 2 of 2012)
```

### `heading:part:7` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:5` · note · 

```text
(Amended 4 of 2018 s. 4)
```

### `section:1/note:6` · note · 

```text
(Omitted as spent—E.R. 2 of 2012)
```

