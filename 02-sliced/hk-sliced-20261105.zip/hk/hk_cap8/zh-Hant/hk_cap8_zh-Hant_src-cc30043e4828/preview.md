# Cap. 8 · 《證據條例》

- 语言：`zh-Hant`
- 版本：`hk:cap8:zh-Hant:src-cc30043e4828`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：413；切片：423；发布资格：否

文本覆盖对账：True，片段 3182，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合證據的法律。
```

### `note:1` · note · 

```text
[1889年1月18日]
```

### `heading:part:3` · heading · 第I部 導言

```text
第I部 導言
```

### `note:2` · note · 

```text
(格式變更——2018年第4號編輯修訂紀錄)
```

### `section:1/note:3` · note · 

```text
(由1924年第5號第6條修訂)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《證據條例》。
```

### `section:2/note:4` · note · 

```text
(由1911年第50號修訂；由1911年第62號附表修訂；由1912年第27號修訂；由1998年第25號第2條修訂)
```

### `section:2/note:5` · note · 

```text
[比照 1851 c. 99 s. 16 U.K.]
```

