# Cap. 8 · 《證據條例》

- 语言：`en`
- 版本：`hk:cap8:en:src-3a18b587b554`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：404；切片：406；发布资格：否

文本覆盖对账：True，片段 3120，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate the law of evidence.
```

### `note:1` · note · 

```text
[18 January 1889]
```

### `heading:part:3` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2018)
```

### `section:1/note:3` · note · 

```text
(Amended 5 of 1924 s. 6)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Evidence Ordinance.
```

### `section:2/note:4` · note · 

```text
(Amended 9 of 1950Schedule; 37 of 1984 s. 11)
```

### `section:2/note:5` · note · 

```text
(Replaced 37 of 1984 s. 2)
```

