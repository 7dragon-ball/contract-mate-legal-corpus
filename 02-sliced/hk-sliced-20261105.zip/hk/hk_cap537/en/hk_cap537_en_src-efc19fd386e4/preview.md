# Cap. 537 · 《聯合國制裁條例》

- 语言：`en`
- 版本：`hk:cap537:en:src-efc19fd386e4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：12；切片：12；发布资格：否

文本覆盖对账：True，片段 86，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to provide for the imposition of sanctions against persons, and against places outside the People’s Republic of China, arising from Chapter 7 of the Charter of the United Nations, and to provide for matters incidental thereto or connected therewith.
```

### `note:1` · note · 

```text
(Amended 26 of 2018 s. 3)
```

### `note:2` · note · 

```text
[18 July 1997]
```

### `note:3` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2017)
```

### `note:4` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the United Nations Sanctions Ordinance.
```

### `section:2/note:5` · note · 

```text
(Added 26 of 2018 s. 4)
```

### `section:2/note:6` · note · 

```text
(Amended 26 of 2018 s. 4)
```

