# Cap. 652A · 《建造業付款保障規例》

- 语言：`en`
- 版本：`hk:cap652A:en:src-2a837f229b37`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：25；切片：25；发布资格：否

文本覆盖对账：True，片段 296，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Construction Industry Security of Payment Rules
```

### `other:enactingformula:2` · other · 

```text
(Cap. 652, section 50)
```

### `note:1` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2026)
```

### `note:2` · note · 

```text
[5 September 2025]
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:3` · note · 

```text
(Omitted as spent—E.R. 2 of 2026)
```

### `section:1` · section · 

```text
1.
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In these Rules—
Cap. 4A (《第4A章》) means the Rules of the High Court (Cap. 4 sub. leg. A);
Cap. 336H (《第336H章》) means the Rules of the District Court (Cap. 336 sub. leg. H);
CFI Judge (原訟法庭法官) means a judge, recorder or deputy judge mentioned in section 4(1)(b), (ba) or (c) of the High Court Ordinance (Cap. 4);
Court (法院) means the Court of First Instance or the District Court;
District Judge (區域法院法官) means a judge as defined by section 2 of the District Court Ordinance (Cap. 336);
enforcement application (強制執行申請) means an application for leave to enforce a determination under section 49 of the Ordinance;
Master of the District Court (區域法院聆案官) means a master as defined by Ord
```

