# Cap. 652A · 《建造業付款保障規例》

- 语言：`zh-Hant`
- 版本：`hk:cap652A:zh-Hant:src-ed50aee2bfd6`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：25；切片：25；发布资格：否

文本覆盖对账：True，片段 297，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《建造業付款保障規則》
```

### `other:enactingformula:2` · other · 

```text
(第652章第50條)
```

### `note:1` · note · 

```text
(略去制定語式條文——2026年第2號編輯修訂紀錄)
```

### `note:2` · note · 

```text
[2025年9月5日]
```

### `heading:part:5` · heading · 第1部 導言

```text
第1部 導言
```

### `section:1/note:3` · note · 

```text
(已失時效而略去——2026年第2號編輯修訂紀錄)
```

### `section:1` · section · 

```text
1.
```

### `section:2` · section · 釋義

```text
2.
釋義
在本規則中 ——
法院 (Court)指原訟法庭或區域法院；
原訟法庭法官 (CFI Judge)指《高等法院條例》(第4章)第4(1)(b)、(ba)或(c)條所述的法官、特委法官或暫委法官；
高等法院聆案官 (Master of the High Court)指《第4A章》第1號命令第4(1)條規則所界定的聆案官；
區域法院法官 (District Judge)指《區域法院條例》(第336章)第2條所界定的法官；
區域法院聆案官 (Master of the District Court)指《第336H章》第1號命令第4(1)條規則所界定的聆案官；
強制執行申請 (enforcement application)指根據本條例第49條提出以尋求許可強制執行某項裁定的申請；
《第4A章》 (Cap. 4A)指《高等法院規則》(第4章，附屬法例A)；
《第336H章》 (Cap. 336H)指《區域法院規則》(第336章，附屬法例H)；
撤銷申請 (set aside application)指根據本條例第48條提出以尋求撤銷某項裁定的申請。
```

