# Cap. 293 · 《法人團體合約條例》

- 语言：`en`
- 版本：`hk:cap293:en:src-1599fc4a68ef`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：9；切片：9；发布资格：否

文本覆盖对账：True，片段 40，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law governing the making of contracts by or on behalf of bodies corporate, and for connected purposes.
```

### `note:1` · note · 

```text
[15 August 1969]
```

### `note:2` · note · 

```text
(Format changes—E.R. 2 of 2014)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Corporate Bodies Contracts Ordinance.
```

### `section:2/note:3` · note · 

```text
[cf. 1960 c. 46 s. 1 U.K.]
```

### `section:2` · section · Cases where contracts need not be under seal

```text
2.
Cases where contracts need not be under seal
(1)
Contracts may be made on behalf of any body corporate, wherever incorporated, as follows—
(a)
a contract which if made between private persons would be by law required to be in writing, signed by the parties to be charged therewith, may be made on behalf of the body corporate in writing signed by any person acting under its authority, express or implied; and
(b)
a contract which if made between private persons would by law be valid although made by parol only and not reduced into writing, may be made by parol on behalf of the body corporate by any person acting under its authority, express or implied.
(2)
A contract made according to this s
```

### `section:3/note:4` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920; E.R. 2 of 2014)
```

### `section:3/note:5` · note · 

```text
[cf. 1960 c. 46 s. 2 U.K.]
```

