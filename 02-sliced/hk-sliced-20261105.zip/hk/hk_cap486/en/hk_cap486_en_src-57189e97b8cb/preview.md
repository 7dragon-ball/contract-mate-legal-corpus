# Cap. 486 · 《個人資料(私隱)條例》

- 语言：`en`
- 版本：`hk:cap486:en:src-57189e97b8cb`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：446；切片：450；发布资格：否

文本覆盖对账：True，片段 5535，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to protect the privacy of individuals in relation to personal data, and to provide for matters incidental thereto or connected therewith.
```

### `note:1` · note · 

```text
[1 August 1996]L.N. 343 of 1996
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2013)
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2013)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended L.N. 130 of 2007)
```

### `section:1` · section · Short title and commencement

```text
1.
Short title and commencement
(1)
This Ordinance may be cited as the Personal Data (Privacy) Ordinance.
(2)
This Ordinance shall come into operation on a day to be appointed by the Secretary for Constitutional and Mainland Affairs by notice in the Gazette.
```

### `section:2/note:5` · note · 

```text
(Added 18 of 2012 s. 3)
```

