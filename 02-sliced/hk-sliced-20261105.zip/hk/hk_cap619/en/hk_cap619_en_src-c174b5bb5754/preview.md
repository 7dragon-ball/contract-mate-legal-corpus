# Cap. 619 · 《競爭條例》

- 语言：`en`
- 版本：`hk:cap619:en:src-c174b5bb5754`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：411；切片：412；发布资格：否

文本覆盖对账：True，片段 5812，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to prohibit conduct that prevents, restricts or distorts competition in Hong Kong; to prohibit mergers that substantially lessen competition in Hong Kong; to establish a Competition Commission and a Competition Tribunal; and to provide for incidental and connected matters.
```

### `note:1` · note · 

```text
[18 January 2013]
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2019)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2012)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 1 of 2016)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 1 of 2016)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Competition Ordinance.
(2)
```

