# Cap. 60 · 《進出口條例》

- 语言：`en`
- 版本：`hk:cap60:en:src-54a0c3a87f6c`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：455；切片：459；发布资格：否

文本覆盖对账：True，片段 4180，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To provide for the regulation and control of the import of articles into Hong Kong, the export of articles from Hong Kong, the handling and carriage of articles within Hong Kong which have been imported into Hong Kong or which may be exported from Hong Kong, and any matter incidental to or connected with the foregoing.
```

### `note:1` · note · 

```text
(Amended 22 of 1991 s. 2)
```

### `note:2` · note · 

```text
[1 January 1972]L.N. 180 of 1971
```

### `note:3` · note · 

```text
(Format changes—E.R. 2 of 2021)
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Import and Export Ordinance.
```

### `section:2/note:4` · note · 

```text
(Added 29 of 2000 s. 2)
```

### `section:2/note:5` · note · 

```text
(Added L.N. 294 of 1982)
```

