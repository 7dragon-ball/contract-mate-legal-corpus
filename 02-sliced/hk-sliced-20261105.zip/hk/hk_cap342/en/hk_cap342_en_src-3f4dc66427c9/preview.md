# Cap. 342 · 《香港海關條例》

- 语言：`en`
- 版本：`hk:cap342:en:src-3f4dc66427c9`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：211；切片：211；发布资格：否

文本覆盖对账：True，片段 1303，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To establish a Customs and Excise Service and to make provision as to its duties and powers and as to the discipline of members thereof and to make provision for a welfare fund; and for purposes connected with the matters aforesaid.
```

### `note:1` · note · 

```text
(Amended 46 of 1977 s. 2)
```

### `note:2` · note · 

```text
[16 October 1963]L.N. 121 of 1963
```

### `note:3` · note · 

```text
(Format changes—E.R. 5 of 2020)
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended 46 of 1977 s. 3)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Customs and Excise Service Ordinance.
```

### `section:2/note:5` · note · 

```text
(Added 40 of 1985 s. 2. Amended 76 of 1999 s. 3)
```

