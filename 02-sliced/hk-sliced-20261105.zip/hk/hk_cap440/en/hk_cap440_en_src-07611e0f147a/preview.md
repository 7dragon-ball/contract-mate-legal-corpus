# Cap. 440 · 《提單及相類裝運單據條例》

- 语言：`en`
- 版本：`hk:cap440:en:src-07611e0f147a`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：20；切片：20；发布资格：否

文本覆盖对账：True，片段 226，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to replace the Bills of Lading Ordinance with new provisions with respect to bills of lading and certain other shipping documents.
```

### `note:1` · note · 

```text
[1 March 1994]L.N. 105 of 1994
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2021)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 4 of 2021)
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 4 of 2021)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 4 of 2021)
```

### `section:1/note:6` · note · 

```text
Editorial Note: * Operation date: 1 March 1994.
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Bills of Lading and Analogous Shipping Documents Ordinance.
(2)
(3)
Nothing in this Ordinance shall have effect in relation to any document issued before this Ordinance comes into operation*.
```

