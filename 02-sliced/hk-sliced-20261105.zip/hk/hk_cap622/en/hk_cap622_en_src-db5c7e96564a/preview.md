# Cap. 622 · 《公司條例》

- 语言：`en`
- 版本：`hk:cap622:en:src-db5c7e96564a`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：2056；切片：2067；发布资格：否

文本覆盖对账：True，片段 36015，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to reform and modernize Hong Kong company law, to restate part of the enactments relating to companies, to make other provision relating to companies, and to provide for incidental and connected matters.
```

### `note:1` · note · 

```text
[3 March 2014]
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2013)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2013)
```

### `heading:division:7` · heading · Division 1 Short Title and Commencement

```text
Division 1 Short Title and Commencement
```

### `section:1` · section · Short title and commencement

```text
1.
Short title and commencement
(1)
This Ordinance may be cited as the Companies Ordinance.
(2)
This Ordinance comes into operation on a day to be appointed by the Secretary for Financial Services and the Treasury by notice published in the Gazette.
```

### `heading:division:9` · heading · Division 2 Interpretation of this Ordinance: General

```text
Division 2 Interpretation of this Ordinance: General
```

