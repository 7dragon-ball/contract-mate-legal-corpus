# Cap. 132 · 《公眾衞生及市政條例》

- 语言：`en`
- 版本：`hk:cap132:en:src-b5b09f3861be`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：1109；切片：1140；发布资格：否

文本覆盖对账：True，片段 11871，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make provision for public health and municipal services.
```

### `note:1` · note · 

```text
(Amended 10 of 1986 s. 2)
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2019)
```

### `note:3` · note · 

```text
[11 November 1960]G.N.A. 132 of 1960
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:4` · note · 

```text
(Format changes—E.R. 4 of 2019)
```

### `section:1/note:5` · note · 

```text
(Amended 10 of 1986 s. 3)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Public Health and Municipal Services Ordinance.
```

