# Cap. 284 · 《失實陳述條例》

- 语言：`en`
- 版本：`hk:cap284:en:src-f9bed6f02ce5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：17；切片：17；发布资格：否

文本覆盖对账：True，片段 58，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law relating to innocent misrepresentations.
```

### `note:1` · note · 

```text
[29 August 1969]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Misrepresentation Ordinance.
```

### `section:2/note:3` · note · 

```text
[cf. 1967 c. 7 s. 1 U.K.]
```

### `section:2` · section · Removal of certain bars to rescission for innocent misrepres

```text
2.
Removal of certain bars to rescission for innocent misrepresentation
Where a person has entered into a contract after a misrepresentation has been made to him, and—
(a)
the misrepresentation has become a term of the contract; or
(b)
the contract has been performed,
or both, then, if otherwise he would be entitled to rescind the contract without alleging fraud, he shall be so entitled, subject to the provisions of this Ordinance, notwithstanding the matters mentioned in paragraphs (a) and (b).
```

### `section:3/note:4` · note · 

```text
[cf. 1967 c. 7 s. 2 U.K.]
```

### `section:3` · section · Damages for misrepresentation

```text
3.
Damages for misrepresentation
(1)
Where a person has entered into a contract after a misrepresentation has been made to him by another party thereto and as a result thereof he has suffered loss, then, if the person making the misrepresentation would be liable to damages in respect thereof had the misrepresentation been made fraudulently, that person shall be so liable notwithstanding that the misrepresentation was not made fraudulently, unless he proves that he had reasonable grounds to believe and did believe up to the time the contract was made that the facts represented were true.
(2)
Where a person has entered into a contract after a misrepresentation has been made to him otherwise th
```

