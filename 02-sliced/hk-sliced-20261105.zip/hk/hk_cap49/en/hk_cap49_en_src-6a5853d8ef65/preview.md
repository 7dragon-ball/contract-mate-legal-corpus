# Cap. 49 · 《業務轉讓(債權人保障)條例》

- 语言：`en`
- 版本：`hk:cap49:en:src-6a5853d8ef65`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：23；切片：23；发布资格：否

文本覆盖对账：True，片段 322，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To protect creditors on the transfer of businesses, to provide for the liability of transferees of business, the manner in which such liability may be avoided and for matters incidental thereto and connected therewith, and to repeal the Fraudulent Transfers of Businesses Ordinance.
```

### `note:1` · note · 

```text
[27 June 1980]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2019)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Transfer of Businesses (Protection of Creditors) Ordinance.
```

### `section:2/note:3` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920)
```

### `section:2/note:4` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920)
```

### `section:2/note:5` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920; E.R. 1 of 2019)
```

### `section:2/note:6` · note · 

```text
(Amended 24 of 2005 s. 55)
```

