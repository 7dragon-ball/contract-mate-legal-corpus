# Cap. 26 · 《貨品售賣條例》

- 语言：`en`
- 版本：`hk:cap26:en:src-72aca4a2a5c1`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：128；切片：128；发布资格：否

文本覆盖对账：True，片段 782，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To codify the law relating to the sale of goods.
```

### `note:1` · note · 

```text
[cf. 1893 c. 71 U.K.]
```

### `note:2` · note · 

```text
[1 August 1896]
```

### `note:3` · note · 

```text
(Format changes—E.R. 4 of 2018)
```

### `section:1/note:4` · note · 

```text
(Amended 5 of 1924 s. 6)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Sale of Goods Ordinance.
```

### `section:2/note:5` · note · 

```text
(Added 58 of 1977 s. 2. Amended 59 of 1989 s. 20; 66 of 2000 s. 3)
```

### `section:2/note:6` · note · 

```text
(Amended 59 of 1989 s. 20)
```

