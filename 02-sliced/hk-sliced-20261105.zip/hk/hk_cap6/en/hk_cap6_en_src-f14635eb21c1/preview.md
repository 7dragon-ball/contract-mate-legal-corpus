# Cap. 6 · 《破產條例》

- 语言：`en`
- 版本：`hk:cap6:en:src-f14635eb21c1`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：904；切片：908；发布资格：否

文本覆盖对账：True，片段 5841，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law relating to bankruptcy.
```

### `note:1` · note · 

```text
(Format changes—E.R. 3 of 2021)
```

### `note:2` · note · 

```text
[1 January 1932]
```

### `note:3` · note · 

```text
Editorial Note: This Ordinance was amended by the Bankruptcy (Amendment) Ordinance 2005 (18 of 2005) (Commencement date: 10 December 2007). Please see the transitional and savings provisions contained in section 49 of that Amendment Ordinance.
```

### `heading:part:5` · heading · Part I Short Title and Interpretation

```text
Part I Short Title and Interpretation
```

### `note:4` · note · 

```text
(Format changes—E.R. 1 of 2019)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Bankruptcy Ordinance.
```

### `section:2/note:5` · note · 

```text
(Added 76 of 1996 s. 2)
```

