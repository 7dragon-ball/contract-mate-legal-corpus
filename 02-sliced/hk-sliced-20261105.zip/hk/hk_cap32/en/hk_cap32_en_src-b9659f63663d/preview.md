# Cap. 32 · 《公司(清盤及雜項條文)條例》

- 语言：`en`
- 版本：`hk:cap32:en:src-b9659f63663d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：2866；切片：2851；发布资格：否

文本覆盖对账：True，片段 18166，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make provision for the winding up of companies; for receivers and managers; for offering of shares and debentures; for prospectuses; for disqualification orders; for prevention of evasion of the Societies Ordinance; and for incidental and connected matters.
```

### `note:1` · note · 

```text
(Replaced 28 of 2012 ss. 912 & 920. Amended 14 of 2016 s. 3)
```

### `note:2` · note · 

```text
[1 July 1933]
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:3` · note · 

```text
(Added 14 of 2016 s. 4)
```

### `heading:division:6` · heading · Division 1 Short Title

```text
Division 1 Short Title
```

### `note:4` · note · 

```text
(Added 14 of 2016 s. 4)
```

### `section:1/note:5` · note · 

```text
(Amended 28 of 2012 ss. 912 & 920)
```

