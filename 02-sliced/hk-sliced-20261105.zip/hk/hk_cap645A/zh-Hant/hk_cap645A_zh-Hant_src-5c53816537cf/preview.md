# Cap. 645A · 《內地民商事判決(相互強制執行)規則》

- 语言：`zh-Hant`
- 版本：`hk:cap645A:zh-Hant:src-5c53816537cf`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：46；切片：47；发布资格：否

文本覆盖对账：True，片段 671，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《內地民商事判決(相互強制執行)規則》
```

### `other:enactingformula:2` · other · 

```text
(第645章第35條)
```

### `note:1` · note · 

```text
(略去制定語式條文——2024年第2號編輯修訂紀錄)
```

### `note:2` · note · 

```text
[2024年1月29日] 2023年第153號法律公告
```

### `heading:part:5` · heading · 第1部 導言

```text
第1部 導言
```

### `section:1/note:3` · note · 

```text
(已失時效而略去——2024年第2號編輯修訂紀錄)
```

### `section:1` · section · 

```text
1.
```

### `section:2` · section · 釋義

```text
2.
釋義
在本規則中 ——
身分證 (identity card)具有《人事登記條例》(第177章)第1A(1)條所給予的涵義；
身分識別文件 (proof of identity)就某人而言，指 ——
(a)
該人的身分證；或
(b)
如該人並非身分證持有人——該人的身分證明文件，而該文件經公證，或以其他方式按照該文件發出地的法律妥為認證；
尋求作廢申請 (setting aside application)指根據本條例第20條提出的申請。
```

