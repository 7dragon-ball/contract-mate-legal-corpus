# Cap. 645A · 《內地民商事判決(相互強制執行)規則》

- 语言：`en`
- 版本：`hk:cap645A:en:src-f5354a9417e6`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：46；切片：46；发布资格：否

文本覆盖对账：True，片段 669，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Mainland Judgments in Civil and Commercial Matters (Reciprocal Enforcement) Rules
```

### `other:enactingformula:2` · other · 

```text
(Cap. 645, section 35)
```

### `note:1` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2024)
```

### `note:2` · note · 

```text
[29 January 2024] L.N. 153 of 2023
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:3` · note · 

```text
(Omitted as spent—E.R. 2 of 2024)
```

### `section:1` · section · 

```text
1.
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In these Rules—
identity card (身分證) has the meaning given by section 1A(1) of the Registration of Persons Ordinance (Cap. 177);
proof of identity (身分識別文件), in relation to a person, means—
(a)
the person’s identity card; or
(b)
if the person is not a holder of an identity card, an identification document of the person notarized or otherwise duly authenticated in accordance with the law of the place in which the document was issued;
setting aside application (尋求作廢申請) means an application under section 20 of the Ordinance.
```

