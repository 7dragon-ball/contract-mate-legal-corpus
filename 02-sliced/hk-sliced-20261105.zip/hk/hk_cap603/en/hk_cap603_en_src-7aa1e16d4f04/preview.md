# Cap. 603 · 《產品環保責任條例》

- 语言：`en`
- 版本：`hk:cap603:en:src-7aa1e16d4f04`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：359；切片：359；发布资格：否

文本覆盖对账：True，片段 4355，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to introduce measures to minimize the environmental impact of certain types of products; and to provide for related matters.
```

### `note:1` · note · 

```text
[30 April 2009]
```

### `note:2` · note · 

```text
(Format changes—E.R. 3 of 2015)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 3 of 2015)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 3 of 2015)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 3 of 2015)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Product Eco-responsibility Ordinance.
(2)
```

