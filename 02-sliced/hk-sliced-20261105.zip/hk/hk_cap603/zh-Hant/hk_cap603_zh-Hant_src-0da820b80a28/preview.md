# Cap. 603 · 《產品環保責任條例》

- 语言：`zh-Hant`
- 版本：`hk:cap603:zh-Hant:src-0da820b80a28`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：359；切片：366；发布资格：否

文本覆盖对账：True，片段 4408，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在推行措施，將若干種類產品對環境的影響盡量減低；並就相關事宜訂定條文。
```

### `note:1` · note · 

```text
[2009年4月30日]
```

### `note:2` · note · 

```text
(格式變更——2015年第3號編輯修訂紀錄)
```

### `other:enactingformula:4/note:3` · note · 

```text
(略去制定語式條文——2015年第3號編輯修訂紀錄)
```

### `heading:part:6` · heading · 第1部 導言

```text
第1部 導言
```

### `section:1/note:4` · note · 

```text
(編輯修訂——2015年第3號編輯修訂紀錄)
```

### `section:1/note:5` · note · 

```text
(已失時效而略去——2015年第3號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
(1)
本條例可引稱為《產品環保責任條例》。
(2)
```

