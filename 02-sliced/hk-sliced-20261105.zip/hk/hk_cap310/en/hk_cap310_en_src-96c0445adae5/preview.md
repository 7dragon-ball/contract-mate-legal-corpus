# Cap. 310 · 《商業登記條例》

- 语言：`en`
- 版本：`hk:cap310:en:src-96c0445adae5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：331；切片：334；发布资格：否

文本覆盖对账：True，片段 3157，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law relating to the registration of businesses in Hong Kong.
```

### `note:1` · note · 

```text
(Amended 12 of 1985 s. 29(1))
```

### `note:2` · note · 

```text
[6 February 1959]
```

### `note:3` · note · 

```text
(Format changes—E.R. 2 of 2018)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Business Registration Ordinance.
```

### `section:2/note:4` · note · 

```text
(Amended 13 of 2010 s. 3)
```

### `section:2/note:5` · note · 

```text
(Added 13 of 2010 s. 3)
```

### `section:2/note:6` · note · 

```text
(Amended L.N. 88 of 1975; 32 of 1975 s. 2)
```

