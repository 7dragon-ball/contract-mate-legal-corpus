# Cap. 609 · 《仲裁條例》

- 语言：`en`
- 版本：`hk:cap609:en:src-76f8c6cafd9e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：442；切片：433；发布资格：否

文本覆盖对账：True，片段 5032，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to reform the law relating to arbitration, and to provide for related and consequential matters.
```

### `note:1` · note · 

```text
[1 June 2011]L.N. 38 of 2011
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2014)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `note:3` · note · 

```text
(Format changes— E.R. 1 of 2018)
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 2 of 2014)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 2 of 2014)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Arbitration Ordinance.
(2)
```

