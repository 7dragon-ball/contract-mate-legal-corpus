# Cap. 609 · 《仲裁條例》

- 语言：`zh-Hant`
- 版本：`hk:cap609:zh-Hant:src-49e2ccd1ac13`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：441；切片：441；发布资格：否

文本覆盖对账：True，片段 5426，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在改革與仲裁有關的法律，以及就相關及相應事宜訂定條文。
```

### `note:1` · note · 

```text
[2011年6月1日]2011年第38號法律公告
```

### `other:enactingformula:3/note:2` · note · 

```text
(略去制定語式條文——2014年第2號編輯修訂紀錄)
```

### `heading:part:5` · heading · 第1部 導言

```text
第1部 導言
```

### `note:3` · note · 

```text
(格式變更——2018年第1號編輯修訂紀錄)
```

### `section:1/note:4` · note · 

```text
(編輯修訂——2014年第2號編輯修訂紀錄)
```

### `section:1/note:5` · note · 

```text
(已失時效而略去——2014年第2號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
(1)
本條例可引稱為《仲裁條例》。
(2)
```

