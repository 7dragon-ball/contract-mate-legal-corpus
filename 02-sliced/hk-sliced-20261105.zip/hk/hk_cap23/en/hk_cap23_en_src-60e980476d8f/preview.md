# Cap. 23 · 《法律修訂及改革(綜合)條例》

- 语言：`en`
- 版本：`hk:cap23:en:src-60e980476d8f`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：127；切片：128；发布资格：否

文本覆盖对账：True，片段 827，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate Ordinances relating to interests in land, assignments, contract, tort, breach of promise and foreign corporations; and to amend the law relating to the defence of tender before action.
```

### `note:1` · note · 

```text
(Amended 3 of 2008 s. 7)
```

### `note:2` · note · 

```text
[1 July 1901]
```

### `section:1/note:3` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Law Amendment and Reform (Consolidation) Ordinance.
```

### `heading:part:6` · heading · Part I

```text
Part I
```

### `note:4` · note · 

```text
(Repealed 62 of 1984 s. 66)
```

### `heading:part:8` · heading · Part II Assignments

```text
Part II Assignments
```

