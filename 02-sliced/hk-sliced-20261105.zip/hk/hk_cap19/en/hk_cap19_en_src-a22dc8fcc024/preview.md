# Cap. 19 · 《匯票條例》

- 语言：`en`
- 版本：`hk:cap19:en:src-a22dc8fcc024`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：276；切片：276；发布资格：否

文本覆盖对账：True，片段 1491，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To codify the law relating to bills of exchange, cheques and promissory notes.
```

### `note:1` · note · 

```text
[4 May 1885]
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

### `heading:part:4` · heading · Part I Preliminary Provisions

```text
Part I Preliminary Provisions
```

### `note:3` · note · 

```text
(Added 51 of 1911; 63 of 1911Schedule)
```

### `section:1/note:4` · note · 

```text
(Amended 5 of 1924 s. 6)
```

### `section:1/note:5` · note · 

```text
[cf. 1882 c. 61 s. 1 U.K.]
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Bills of Exchange Ordinance.
```

