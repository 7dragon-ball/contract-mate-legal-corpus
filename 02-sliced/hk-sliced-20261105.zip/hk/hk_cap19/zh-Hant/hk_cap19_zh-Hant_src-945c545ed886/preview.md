# Cap. 19 · 《匯票條例》

- 语言：`zh-Hant`
- 版本：`hk:cap19:zh-Hant:src-945c545ed886`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：269；切片：271；发布资格：否

文本覆盖对账：True，片段 1458，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在將與匯票、支票及承付票有關的法律編纂為成文法則。
```

### `note:1` · note · 

```text
[1885年5月4日]
```

### `note:2` · note · 

```text
(格式變更——2020年第4號編輯修訂紀錄)
```

### `heading:part:4` · heading · 第I部 導言

```text
第I部 導言
```

### `note:3` · note · 

```text
(由1911年第51號增補；由1911年第63號附表增補)
```

### `section:1/note:4` · note · 

```text
(由1924年第5號第6條修訂)
```

### `section:1/note:5` · note · 

```text
[比照 1882 c. 61 s. 1 U.K.]
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《匯票條例》。
```

