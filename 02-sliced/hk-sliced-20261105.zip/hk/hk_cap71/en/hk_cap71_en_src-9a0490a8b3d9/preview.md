# Cap. 71 · 《管制免責條款條例》

- 语言：`en`
- 版本：`hk:cap71:en:src-9a0490a8b3d9`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：69；切片：69；发布资格：否

文本覆盖对账：True，片段 491，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To limit the extent to which civil liability for breach of contract, or for negligence or other breach of duty, can be avoided by means of contract terms and otherwise; and to restrict the enforceability of arbitration agreements.
```

### `note:1` · note · 

```text
[1 December 1990]L.N. 38 of 1990
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Control of Exemption Clauses Ordinance.
```

### `section:2/note:3#2` · note · 

```text
(Amended 65 of 2000 s. 3)
```

### `section:2/note:4` · note · 

```text
[cf. 1977 c. 50 ss. 1 & 14 U.K.]
```

### `section:2` · section · Interpretation and application

```text
2.
Interpretation and application
(1)
In this Ordinance—
business (業務) includes a profession and the activities of a public body, a public authority, or a board, commission, committee or other body appointed by the Chief Executive or Government;
goods (貨品) has the same meaning as in the Sale of Goods Ordinance (Cap. 26);
negligence (疏忽) means the breach—
(a)
of any obligation, arising from the express or implied terms of a contract, to take reasonable care or exercise reasonable skill in the performance of the contract;
(b)
of any common law duty to take reasonable care or exercise reasonable skill (but not any stricter duty);
(c)
of the common duty of care imposed by the Occupiers Liability
```

