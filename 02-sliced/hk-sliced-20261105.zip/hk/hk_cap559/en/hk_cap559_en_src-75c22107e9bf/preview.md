# Cap. 559 · 《商標條例》

- 语言：`en`
- 版本：`hk:cap559:en:src-75c22107e9bf`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：363；切片：364；发布资格：否

文本覆盖对账：True，片段 4585，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to make provision for the registration of trade marks, to give effect to the Protocol Relating to the Madrid Agreement Concerning the International Registration of Marks, and to provide for connected matters.
```

### `note:1` · note · 

```text
(Amended 3 of 2020 s. 3)
```

### `note:2` · note · 

```text
[4 April 2003]L.N. 31 of 2003
```

### `note:3` · note · 

```text
(Format changes—E.R. 7 of 2020)
```

### `other:enactingformula:5/note:4` · note · 

```text
(Enacting provision omitted—E.R. 7 of 2020)
```

### `heading:part:7` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:5` · note · 

```text
(Amended E.R. 7 of 2020)
```

### `section:1/note:6` · note · 

```text
(Omitted as spent—E.R. 7 of 2020)
```

