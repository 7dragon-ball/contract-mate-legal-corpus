# Cap. 1115 · 《香港出口信用保險局條例》

- 语言：`en`
- 版本：`hk:cap1115:en:src-7a7b6b7a4442`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：89；切片：89；发布资格：否

文本覆盖对账：True，片段 501，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To provide for the establishment of the Hong Kong Export Credit Insurance Corporation, and to define its powers and functions.
```

### `note:1` · note · 

```text
[23 December 1966]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2013)
```

### `heading:part:4` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Hong Kong Export Credit Insurance Corporation Ordinance.
```

### `section:2/note:3` · note · 

```text
(Amended 66 of 2000 s. 3)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance, unless the context otherwise requires—
Advisory Board (諮詢委員會) means the Advisory Board established by section 10;
auditors (核數師) means the auditors appointed under section 25;
Commissioner (總監) means the Commissioner of the Hong Kong Export Credit Insurance Corporation appointed under section 6;
Corporation (保險局) means the Hong Kong Export Credit Insurance Corporation established by section 3;
financial year (財政年度) means the period commencing on the 1 April in any year and ending on the 31 March in the year following, except that the period from the commencement of this Ordinance to 31 March 1967 shall be deemed to be a financial year;
trade with places o
```

### `heading:part:8` · heading · Part 2 Establishment, Constitution, Incorporation and Busine

```text
Part 2 Establishment, Constitution, Incorporation and Business of the Corporation
```

