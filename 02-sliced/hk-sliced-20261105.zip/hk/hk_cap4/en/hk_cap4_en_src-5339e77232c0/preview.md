# Cap. 4 · 《高等法院條例》

- 语言：`en`
- 版本：`hk:cap4:en:src-5339e77232c0`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：551；切片：553；发布资格：否

文本覆盖对账：True，片段 4614，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend and consolidate the law relating to the constitution, jurisdiction, practice and powers of the High Court and the administration of justice therein and for matters ancillary thereto and connected therewith.
```

### `note:1` · note · 

```text
(Amended 25 of 1998 s. 2)
```

### `note:2` · note · 

```text
[20 February 1976]L.N. 50 of 1976
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2017)
```

### `note:4` · note · 

```text
Editorial Note: The title of this Ordinance was amended from “Supreme Court Ordinance” to “High Court Ordinance” — see 25 of 1998 s. 2.
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:5` · note · 

```text
(Amended 25 of 1998 s. 2)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the High Court Ordinance.
```

