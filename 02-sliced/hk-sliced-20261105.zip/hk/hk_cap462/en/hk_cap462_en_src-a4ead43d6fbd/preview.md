# Cap. 462 · 《海上貨物運輸條例》

- 语言：`en`
- 版本：`hk:cap462:en:src-a4ead43d6fbd`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：58；切片：58；发布资格：否

文本覆盖对账：True，片段 325，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to regulate liability in respect of the carriage of goods by sea.
```

### `note:1` · note · 

```text
[16 December 1994]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2023)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 1 of 2023)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Carriage of Goods by Sea Ordinance.
```

### `section:2/note:4` · note · 

```text
(Amended 43 of 1999 s. 91; E.R. 1 of 2023)
```

### `section:2/note:5` · note · 

```text
(Amended E.R. 1 of 2023)
```

### `section:2/note:6` · note · 

```text
(Amended E.R. 1 of 2023)
```

