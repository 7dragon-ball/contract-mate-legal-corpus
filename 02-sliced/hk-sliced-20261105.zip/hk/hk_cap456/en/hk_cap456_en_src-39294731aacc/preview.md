# Cap. 456 · 《消費品安全條例》

- 语言：`en`
- 版本：`hk:cap456:en:src-39294731aacc`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：75；切片：75；发布资格：否

文本覆盖对账：True，片段 830，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to impose a duty on manufacturers, importers and suppliers of certain consumer goods to ensure that the consumer goods they supply are safe and for incidental purposes.
```

### `note:1` · note · 

```text
[20 October 1995]L.N. 444 of 1995
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 4 of 2020)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 4 of 2020)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent—E.R. 4 of 2020)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Consumer Goods Safety Ordinance.
(2)
```

