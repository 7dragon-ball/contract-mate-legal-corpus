# Cap. 528 · 《版權條例》

- 语言：`en`
- 版本：`hk:cap528:en:src-ca4ce37a1c56`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：1475；切片：1471；发布资格：否

文本覆盖对账：True，片段 13988，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to make provisions in respect of copyright and related rights and for connected purposes.
```

### `note:1` · note · 

```text
(Amended 15 of 2007 s. 3)
```

### `note:2` · note · 

```text
[27 June 1997]
```

### `note:3` · note · 

```text
(Format changes—E.R. 2 of 2019)
```

### `note:4` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2019)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1/note:5` · note · 

```text
(Amended E.R. 2 of 2019)
```

### `section:1/note:6` · note · 

```text
(Omitted as spent—E.R. 2 of 2019)
```

