# Cap. 514 · 《專利條例》

- 语言：`en`
- 版本：`hk:cap514:en:src-8ab57b807447`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：803；切片：795；发布资格：否

文本覆盖对账：True，片段 7927，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to make provisions in respect of patents and related matters.
```

### `note:1` · note · 

```text
(Amended 17 of 2016 s. 3)
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

### `note:3` · note · 

```text
[27 June 1997] L.N. 367 of 1997
```

### `note:4` · note · 

```text
(Enacting provision omitted—E.R. 4 of 2020)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `note:5` · note · 

```text
(Replaced 17 of 2016 s. 4)
```

### `note:6` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

