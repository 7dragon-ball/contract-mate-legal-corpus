# Cap. 41 · 《保險業條例》

- 语言：`en`
- 版本：`hk:cap41:en:src-ba5f62def0b4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：1869；切片：1885；发布资格：否

文本覆盖对账：True，片段 23552，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To regulate the carrying on of insurance business; to establish the Insurance Authority (as a body corporate) to regulate the insurance industry for protecting policy holders and potential policy holders and for promoting the stable development of the insurance industry; and to provide for related matters.
```

### `note:1` · note · 

```text
(Replaced 12 of 2015 s. 3)
```

### `note:2` · note · 

```text
[30 June 1983]L.N. 203 of 1983
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2013)
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:4` · note · 

```text
(Format changes—E.R. 1 of 2013)
```

### `section:1/note:5` · note · 

```text
(Amended 12 of 2015 s. 4)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Insurance Ordinance.
```

