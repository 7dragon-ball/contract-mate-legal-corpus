# Cap. 60G · 《進出口(戰略物品)規例》

- 语言：`en`
- 版本：`hk:cap60G:en:src-a77bec38a27a`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：3460；切片：3115；发布资格：否

文本覆盖对账：True，片段 24274，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Import and Export (Strategic Commodities) Regulations
```

### `other:enactingformula:2` · other · 

```text
(Cap. 60, sections 6B and 31)
```

### `note:1` · note · 

```text
[24 December 1965]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2012)
```

### `note:3` · note · 

```text
Editorial Note: These regulations were formerly cited as the Importation and Exportation (Strategic Commodities) Regulations.
```

### `section:1` · section · Citation

```text
1.
Citation
These regulations may be cited as the Import and Export (Strategic Commodities) Regulations.
```

### `section:2/note:4` · note · 

```text
(29 of 2000 s. 2)
```

### `section:2/note:5` · note · 

```text
(L.N. 299 of 1993)
```

