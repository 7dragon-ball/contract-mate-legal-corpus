# Cap. 60G · 《進出口(戰略物品)規例》

- 语言：`zh-Hant`
- 版本：`hk:cap60G:zh-Hant:src-cd2957424311`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：3404；切片：3131；发布资格：否

文本覆盖对账：True，片段 23640，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《進出口(戰略物品)規例》
```

### `other:enactingformula:2` · other · 

```text
(第60章第6B及31條)
```

### `note:1` · note · 

```text
[1965年12月24日]
```

### `note:2` · note · 

```text
(格式變更——2012年第1號編輯修訂紀錄)
```

### `note:3` · note · 

```text
編輯附註： 本規例前引稱為《進口及出口(戰略物品)規例》*。 * 《進口及出口(戰略物品)規例》”乃“Importation and Exportation (Strategic Commodities) Regulations”之譯名。
```

### `section:1` · section · 引稱

```text
1.
引稱
本規例可引稱為《進出口(戰略物品)規例》。
```

### `section:2/note:4` · note · 

```text
(2000年第29號第2條)
```

### `section:2/note:5` · note · 

```text
(1993年第299號法律公告)
```

