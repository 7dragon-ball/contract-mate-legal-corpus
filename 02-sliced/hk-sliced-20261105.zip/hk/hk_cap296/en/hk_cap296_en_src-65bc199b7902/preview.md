# Cap. 296 · 《儲備商品條例》

- 语言：`en`
- 版本：`hk:cap296:en:src-65bc199b7902`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：109；切片：110；发布资格：否

文本覆盖对账：True，片段 849，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make provision with respect of reserved commodities.
```

### `note:1` · note · 

```text
[1 November 1979]L.N. 253 of 1979
```

### `note:2` · note · 

```text
(Format changes—E.R. 2 of 2020)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Reserved Commodities Ordinance.
```

### `section:2/note:3` · note · 

```text
(Amended 42 of 1996 s. 2)
```

### `section:2/note:4` · note · 

```text
(Amended L.N. 294 of 1982)
```

### `section:2/note:5` · note · 

```text
(Added L.N. 294 of 1982. Amended 65 of 2000 s. 3)
```

### `section:2/note:6` · note · 

```text
(Replaced L.N. 294 of 1982. Amended L.N. 292 of 1989; L.N. 173 of 2000)
```

