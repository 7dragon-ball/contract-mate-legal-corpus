# Cap. 296 · 《儲備商品條例》

- 语言：`zh-Hant`
- 版本：`hk:cap296:zh-Hant:src-bb48eff03b3d`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：111；切片：113；发布资格：否

文本覆盖对账：True，片段 876，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在就儲備商品訂定條文。
```

### `note:1` · note · 

```text
[1979年11月1日]1979年第253號法律公告
```

### `note:2` · note · 

```text
(格式變更——2020年第2號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《儲備商品條例》。
```

### `section:2/note:3` · note · 

```text
(由2002年第24號第3條增補)
```

### `section:2/note:4` · note · 

```text
(由2025年第30號第76條增補)
```

### `section:2/note:5` · note · 

```text
(由2025年第30號第76條增補)
```

### `section:2/note:6` · note · 

```text
(由2002年第24號第3條增補)
```

