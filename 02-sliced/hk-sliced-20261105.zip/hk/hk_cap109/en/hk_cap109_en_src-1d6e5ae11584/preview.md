# Cap. 109 · 《應課稅品條例》

- 语言：`en`
- 版本：`hk:cap109:en:src-1d6e5ae11584`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：625；切片：628；发布资格：否

文本覆盖对账：True，片段 4529，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law relating to the taxation and control of liquors, tobacco, hydrocarbon oil, methyl alcohol and other substances, for providing for the licensing of certain dealings in liquors and for purposes connected therewith.
```

### `note:1` · note · 

```text
(Amended 3 of 1970 s. 2; 40 of 1974 s. 2; 34 of 1976 s. 2; 20 of 1985 s. 2; 66 of 1986 s. 2; 35 of 1992 s. 2; 32 of 1993 s. 2)
```

### `note:2` · note · 

```text
[16 October 1963]L.N. 120 of 1963
```

### `note:3` · note · 

```text
(Format changes—E.R. 4 of 2020)
```

### `heading:part:5` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Dutiable Commodities Ordinance.
```

### `section:2/note:4` · note · 

```text
(Added 46 of 1996 s. 2. Amended 12 of 1999 s. 3)
```

### `section:2/note:5` · note · 

```text
(Added 29 of 2000 s. 4)
```

