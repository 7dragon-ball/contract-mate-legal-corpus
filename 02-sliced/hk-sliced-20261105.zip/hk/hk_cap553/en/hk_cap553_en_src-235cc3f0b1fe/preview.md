# Cap. 553 · 《電子交易條例》

- 语言：`en`
- 版本：`hk:cap553:en:src-235cc3f0b1fe`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：308；切片：309；发布资格：否

文本覆盖对账：True，片段 2765，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to facilitate the use of electronic transactions for commercial and other purposes, to provide for matters arising from and related to such use, to enable the Postmaster General to provide the services of a certification authority and to provide for connected purposes.
```

### `note:1` · note · 

```text
(Enacting provision omitted—E.R. 3 of 2017)
```

### `note:2` · note · 

```text
[7 January 2000]
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:3` · note · 

```text
(Format changes—E.R. 3 of 2017)
```

### `section:1/note:4` · note · 

```text
(Omitted as spent—E.R. 3 of 2017)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Electronic Transactions Ordinance.
(2)-(3)
```

### `section:2/note:5` · note · 

```text
(Added 14 of 2004 s. 2)
```

