# Cap. 319 · 《外地判決(交互強制執行)條例》

- 语言：`en`
- 版本：`hk:cap319:en:src-f69a109096b5`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：43；切片：43；发布资格：否

文本覆盖对账：True，片段 366，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To make provision for the enforcement in the Colony of Hong Kong of judgments given in other parts of the Commonwealth and foreign countries which afford reciprocal treatment to judgments given in the Colony of Hong Kong, for facilitating the enforcement in such parts or countries of judgments given in the Colony of Hong Kong, and for matters connected therewith.
```

### `note:1` · note · 

```text
[6 May 1960]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2019)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Foreign Judgments (Reciprocal Enforcement) Ordinance.
```

### `section:2/note:3` · note · 

```text
(Replaced 37 of 1985 s. 6)
```

### `section:2/note:4` · note · 

```text
(Amended 25 of 1998 s. 2)
```

### `section:2/note:5` · note · 

```text
(Amended 92 of 1975 s. 58; 25 of 1998 s. 2)
```

### `section:2/note:6` · note · 

```text
(Amended E.R. 1 of 2019)
```

