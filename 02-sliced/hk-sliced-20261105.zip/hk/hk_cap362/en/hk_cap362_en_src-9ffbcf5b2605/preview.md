# Cap. 362 · 《商品說明條例》

- 语言：`en`
- 版本：`hk:cap362:en:src-9ffbcf5b2605`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：340；切片：341；发布资格：否

文本覆盖对账：True，片段 2846，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To prohibit false trade descriptions, false, misleading or incomplete information, false marks and misstatements in respect of goods provided in the course of trade or suppliers of such goods; to confer power to require information or instruction relating to goods to be marked on or to accompany the goods or to be included in advertisements; to restate the law relating to forgery of trade marks; to prohibit certain unfair trade practices; to prohibit false trade descriptions in respect of services supplied by traders; to confer power to require any services to be accompanied by information or instruction relating to the services or an advertisement of any services to contain or refer to info
```

### `note:1` · note · 

```text
(Amended 65 of 2000 s. 3; 19 of 2008 s. 3; 25 of 2012 s. 32)
```

### `note:2` · note · 

```text
[1 April 1981]L.N. 64 of 1981
```

### `note:3` · note · 

```text
(Format changes—E.R. 2 of 2012)
```

### `heading:part:5` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Trade Descriptions Ordinance.
```

### `section:2/note:4` · note · 

```text
(Added 25 of 2012 s. 3)
```

### `section:2/note:5` · note · 

```text
(Added 25 of 2012 s. 3)
```

