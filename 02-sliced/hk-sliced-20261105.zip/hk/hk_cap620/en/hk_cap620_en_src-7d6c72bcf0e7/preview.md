# Cap. 620 · 《調解條例》

- 语言：`en`
- 版本：`hk:cap620:en:src-7d6c72bcf0e7`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：122；切片：111；发布资格：否

文本覆盖对账：True，片段 528，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to provide a regulatory framework in respect of certain aspects of the conduct of mediation and to make consequential and related amendments.
```

### `note:1` · note · 

```text
[1 January 2013]L.N. 167 of 2012
```

### `other:enactingformula:3/note:2` · note · 

```text
(Enacting provision omitted—E.R. 2 of 2012)
```

### `section:1/note:3` · note · 

```text
(Amended E.R. 1 of 2013)
```

### `section:1/note:4` · note · 

```text
(Omitted as spent—E.R. 1 of 2013)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Mediation Ordinance.
(2)
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
(1)
In this Ordinance—
agreement to mediate (調解協議) means an agreement in writing by 2 or more persons to submit a dispute between them to mediation, regardless of—
(a)
whether the agreement is in the form of a mediation clause in an agreement or in the form of a separate agreement;
(b)
whether the agreement is made before or after the dispute arises; and
(c)
whether or not a mediator is appointed at the time the agreement is made;
Note—An agreement to mediate could be in electronic form—see also section 5(1) of the Electronic Transactions Ordinance (Cap. 553).
dispute (爭議) includes a difference;
mediated settlement agreement (經調解的和解協議) means an agreement by some or all of t
```

### `section:3` · section · Objects of this Ordinance

```text
3.
Objects of this Ordinance
The objects of this Ordinance are—
(a)
to promote, encourage and facilitate the resolution of disputes by mediation; and
(b)
to protect the confidential nature of mediation communications.
```

