# Cap. 117 · 《印花稅條例》

- 语言：`en`
- 版本：`hk:cap117:en:src-ec5d30fa7464`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：907；切片：937；发布资格：否

文本覆盖对账：True，片段 12570，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate and amend the law relating to stamp duty.
```

### `note:1` · note · 

```text
[1 July 1981]L.N. 173 of 1981
```

### `heading:part:3` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:2` · note · 

```text
(Format changes—E.R. 2 of 2014)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Stamp Duty Ordinance.
```

### `section:2/note:3` · note · 

```text
(Added 5 of 2000 s. 2)
```

### `section:2/note:4` · note · 

```text
(Added 2 of 2018 s. 3)
```

### `section:2/note:5` · note · 

```text
(Amended 10 of 2013 s. 24)
```

