# Cap. 117 · 《印花稅條例》

- 语言：`zh-Hant`
- 版本：`hk:cap117:zh-Hant:src-6be700ec3e54`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：917；切片：1005；发布资格：否

文本覆盖对账：True，片段 12615，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合和修訂有關印花稅的法律。
```

### `note:1` · note · 

```text
[1981年7月1日]1981年第173號法律公告
```

### `heading:part:3` · heading · 第I部 導言

```text
第I部 導言
```

### `note:2` · note · 

```text
(格式變更——2014年第2號編輯修訂紀錄)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《印花稅條例》。
```

### `section:2/note:3` · note · 

```text
(由1981年第77號第2條修訂)
```

### `section:2/note:4` · note · 

```text
(由2003年第21號第2條代替)
```

### `section:2/note:5` · note · 

```text
(由2000年第12號第23條增補。由2002年第5號第407條修訂)
```

