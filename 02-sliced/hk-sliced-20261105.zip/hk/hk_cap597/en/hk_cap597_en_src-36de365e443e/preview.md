# Cap. 597 · 《內地判決(交互強制執行)條例》

- 语言：`en`
- 版本：`hk:cap597:en:src-36de365e443e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：65；切片：65；发布资格：否

文本覆盖对账：True，片段 609，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to give effect to the Arrangement on Reciprocal Recognition and Enforcement of Judgments in Civil and Commercial Matters by the Courts of the Mainland and of the Hong Kong Special Administrative Region pursuant to Choice of Court Agreements between Parties Concerned made between the Supreme People’s Court of the People’s Republic of China and the Government of the Hong Kong Special Administrative Region (as amended from time to time), and for that purpose to make provisions for the enforcement in Hong Kong of judgments in civil or commercial matters that are given in the Mainland and for facilitating the enforcement in the Mainland of judgments in civil or commercial matters tha
```

### `note:1` · note · 

```text
[1 August 2008]L.N. 195 of 2008
```

### `note:2` · note · 

```text
(Format changes—E.R. 6 of 2019)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 6 of 2019)
```

### `heading:part:6` · heading · Part 1 Preliminary

```text
Part 1 Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended E.R. 6 of 2019)
```

### `section:1/note:5` · note · 

```text
(Omitted as spent——E.R. 6 of 2019)
```

### `section:1` · section · Short title

```text
1.
Short title
(1)
This Ordinance may be cited as the Mainland Judgments (Reciprocal Enforcement) Ordinance.
(2)
```

