# Cap. 329 · 《海上保險條例》

- 语言：`en`
- 版本：`hk:cap329:en:src-b77cda97a622`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：212；切片：211；发布资格：否

文本覆盖对账：True，片段 946，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To codify the law relating to marine insurance.
```

### `note:1` · note · 

```text
[9 June 1961]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2022)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Marine Insurance Ordinance.
```

### `heading:crossheading:5` · heading · Marine Insurance

```text
Marine Insurance
```

### `section:2/note:3` · note · 

```text
[cf. 1906 c. 41 ss. 1 & 2 U.K.]
```

### `section:2` · section · Marine insurance defined

```text
2.
Marine insurance defined
(1)
A contract of marine insurance is a contract whereby the insurer undertakes to indemnify the assured, in manner and to the extent thereby agreed, against marine losses, that is to say, the losses incident to marine adventure.
(2)
A contract of marine insurance may, by its express terms, or by usage of trade, be extended so as to protect the assured against losses on inland waters or on any land risk which may be incidental to any sea voyage.
(3)
Where a ship in course of building, or the launch of a ship, or any adventure analogous to a marine adventure, is covered by a policy in the form of a marine policy, the provisions of this Ordinance, in so far as appli
```

### `section:3/note:4` · note · 

```text
[cf. 1906 c. 41 s. 3 U.K.]
```

