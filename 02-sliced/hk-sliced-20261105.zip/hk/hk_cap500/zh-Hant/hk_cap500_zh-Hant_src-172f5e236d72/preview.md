# Cap. 500 · 《航空運輸條例》

- 语言：`zh-Hant`
- 版本：`hk:cap500:zh-Hant:src-172f5e236d72`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：739；切片：742；发布资格：否

文本覆盖对账：True，片段 2480，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在施行若干關於國際航空運輸方面的公約；訂立關於公約所不適用的非國際航空運輸及國際航空運輸的條文並就有關目的訂定條文。
```

### `note:1` · note · 

```text
[1997年2月5日]
```

### `note:2` · note · 

```text
(格式變更——2023年第4號編輯修訂紀錄)
```

### `other:enactingformula:4/note:3` · note · 

```text
(略去制定語式條文——2023年第4號編輯修訂紀錄)
```

### `heading:part:6` · heading · 第I部 導言

```text
第I部 導言
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《航空運輸條例》。
```

### `section:2/note:4` · note · 

```text
(由2005年第22號第3條代替)
```

### `section:2/note:5` · note · 

```text
(由2005年第22號第3條增補)
```

