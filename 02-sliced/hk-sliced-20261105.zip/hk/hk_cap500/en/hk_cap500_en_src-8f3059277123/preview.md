# Cap. 500 · 《航空運輸條例》

- 语言：`en`
- 版本：`hk:cap500:en:src-8f3059277123`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：739；切片：739；发布资格：否

文本覆盖对账：True，片段 2343，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
An Ordinance to give effect to certain Conventions concerning international carriage by air; to make provisions relating to non-international carriage by air and international carriage by air to which the Conventions do not apply; and for related purposes.
```

### `note:1` · note · 

```text
[5 February 1997]
```

### `note:2` · note · 

```text
(Format changes—E.R. 4 of 2023)
```

### `other:enactingformula:4/note:3` · note · 

```text
(Enacting provision omitted—E.R. 4 of 2023)
```

### `heading:part:6` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Carriage by Air Ordinance.
```

### `section:2/note:4` · note · 

```text
(Replaced 22 of 2005 s. 3)
```

### `section:2/note:5` · note · 

```text
(Replaced 22 of 2005 s. 3)
```

