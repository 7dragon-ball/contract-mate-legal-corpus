# Cap. 46 · 《外地判決(限制承認及強制執行)條例》

- 语言：`en`
- 版本：`hk:cap46:en:src-1f41e33790b0`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：19；切片：19；发布资格：否

文本覆盖对账：True，片段 131，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To amend the law relating to the recognition and enforcement of foreign judgments; to bar the bringing of proceedings in Hong Kong as an alternative to the enforcement of a foreign judgment; and to provide for matters incidental thereto.
```

### `note:1` · note · 

```text
[28 June 1985]
```

### `note:2` · note · 

```text
(Format changes—E.R. 1 of 2019)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Foreign Judgments (Restriction on Recognition and Enforcement) Ordinance.
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
In this Ordinance, unless the context otherwise requires—
court (法院), in relation to an overseas country, includes any tribunal or person having power to make, confirm, enforce, vary or revoke a maintenance order as defined in section 2 of the Maintenance Orders (Reciprocal Enforcement) Ordinance (Cap. 188);
judgment (判決) means any judgment or order (by whatever name called) given or made by a court in any civil proceedings;
overseas country (海外國家) means any place outside Hong Kong.
```

### `section:3/note:3` · note · 

```text
(Amended 45 of 1995 s. 16; 14 of 2009 s. 38)
```

### `section:3/note:4` · note · 

```text
(Replaced 38 of 1990 s. 32(2). Amended 14 of 2009 s. 38)
```

### `section:3/note:5` · note · 

```text
(Added 14 of 2009 s. 38)
```

