# Cap. 60E · 《進出口(登記)規例》

- 语言：`en`
- 版本：`hk:cap60E:en:src-392cb0775ad4`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：166；切片：166；发布资格：否

文本覆盖对账：True，片段 1191，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
Import and Export (Registration) Regulations
```

### `note:1` · note · 

```text
(Format changes—E.R. 2 of 2012)
```

### `other:enactingformula:3` · other · 

```text
(Cap. 60, section 31)
```

### `note:2` · note · 

```text
[3 October 1966]L.N. 70 of 1966
```

### `note:3` · note · 

```text
Editorial Note: These regulations were made under the repealed Importation and Exportation Ordinance (Chapter 50, 1966 R.Ed.) and, by virtue of section 36(1) of the Interpretation and General Clauses Ordinance (Cap. 1), continue to have the like effect as if they had been made under the Import and Export Ordinance (Cap. 60, enacted in 1970).
```

### `heading:part:6` · heading · Part I Citation and Interpretation

```text
Part I Citation and Interpretation
```

### `note:4` · note · 

```text
(Format changes—E.R. 2 of 2012)
```

### `section:1` · section · Citation

```text
1.
Citation
These regulations may be cited as the Import and Export (Registration) Regulations.
```

