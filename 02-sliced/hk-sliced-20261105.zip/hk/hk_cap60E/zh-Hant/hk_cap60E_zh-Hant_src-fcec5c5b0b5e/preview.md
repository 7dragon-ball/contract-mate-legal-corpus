# Cap. 60E · 《進出口(登記)規例》

- 语言：`zh-Hant`
- 版本：`hk:cap60E:zh-Hant:src-fcec5c5b0b5e`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：169；切片：174；发布资格：否

文本覆盖对账：True，片段 1254，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `other:doctitle:1` · other · 

```text
《進出口(登記)規例》
```

### `note:1` · note · 

```text
(格式變更——2012年第2號編輯修訂紀錄)
```

### `other:enactingformula:3` · other · 

```text
(第60章第31條)
```

### `note:2` · note · 

```text
[1966年10月3日]1966年第70號法律公告
```

### `note:3` · note · 

```text
編輯附註： 此規例乃根據已廢除的《進出口條例》*(第 50 章，1966年編正版)而訂立。憑藉《釋義及通則條例》(第1章)第36(1)條的規定，此規例須一如是根據《進出口條例》(第60章，1970年制訂)訂立般繼續有效。 * “《進出口條例》”乃“Importation and Exportation Ordinance”之譯名。
```

### `heading:part:6` · heading · 第I部 引稱及釋義

```text
第I部 引稱及釋義
```

### `note:4` · note · 

```text
(格式變更——2012年第2號編輯修訂紀錄)
```

### `section:1` · section · 引稱

```text
1.
引稱
本規例可引稱為《進出口(登記)規例》。
```

