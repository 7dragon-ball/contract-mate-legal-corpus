# Cap. 48 · 《代理商條例》

- 语言：`en`
- 版本：`hk:cap48:en:src-f7e37ccbf379`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：25；切片：25；发布资格：否

文本覆盖对账：True，片段 103，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate and amend the law relating to factors.
```

### `note:1` · note · 

```text
[cf. 1889 c. 45 U.K.]
```

### `note:2` · note · 

```text
[1 July 1896]
```

### `note:3` · note · 

```text
(Format changes—E.R. 1 of 2019)
```

### `heading:crossheading:5` · heading · Preliminary

```text
Preliminary
```

### `section:1/note:4` · note · 

```text
(Amended 5 of 1924 s. 6)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Factors Ordinance.
```

### `section:2` · section · Interpretation

```text
2.
Interpretation
(1)
In this Ordinance, unless the context otherwise requires—
document of title (所有權文件) includes any bill of lading, dock warrant, warehouse keeper’s certificate, and warrant or order for the delivery of goods, and any other document used in the ordinary course of business as proof of the possession or control of goods, or authorizing or purporting to authorize, either by indorsement or by delivery, the possessor of the document to transfer or receive goods thereby represented;
goods (貨品) includes wares and merchandise;
mercantile agent (商業代理人) means a mercantile agent having, in the customary course of his business as such agent, authority either to sell goods, or to consi
```

