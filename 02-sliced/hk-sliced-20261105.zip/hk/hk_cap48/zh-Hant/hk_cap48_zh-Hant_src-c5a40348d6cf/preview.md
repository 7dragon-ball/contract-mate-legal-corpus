# Cap. 48 · 《代理商條例》

- 语言：`zh-Hant`
- 版本：`hk:cap48:zh-Hant:src-c5a40348d6cf`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：25；切片：25；发布资格：否

文本覆盖对账：True，片段 103，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合及修訂關於代理商的法律。
```

### `note:1` · note · 

```text
[比照 1889 c. 45 U.K.]
```

### `note:2` · note · 

```text
[1896年7月1日]
```

### `note:3` · note · 

```text
(格式變更——2019年第1號編輯修訂紀錄)
```

### `heading:crossheading:5` · heading · 導言

```text
導言
```

### `section:1/note:4` · note · 

```text
(由1924年第5號第6條修訂)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《代理商條例》。
```

### `section:2/note:5` · note · 

```text
(編輯修訂——2019年第1號編輯修訂紀錄)
```

