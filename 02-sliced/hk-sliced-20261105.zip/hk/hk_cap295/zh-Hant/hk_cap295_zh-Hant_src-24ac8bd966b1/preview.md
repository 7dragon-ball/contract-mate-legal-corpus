# Cap. 295 · 《危險品條例》

- 语言：`zh-Hant`
- 版本：`hk:cap295:zh-Hant:src-24ac8bd966b1`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：100；切片：103；发布资格：否

文本覆盖对账：True，片段 805，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
本條例旨在綜合和修訂與危險品有關的法例。
```

### `note:1` · note · 

```text
[1956年7月27日]
```

### `note:2` · note · 

```text
(格式變更——2019年第6號編輯修訂紀錄)
```

### `heading:part:4` · heading · 第I部 導言

```text
第I部 導言
```

### `note:3` · note · 

```text
(由1971年第9號第2條增補)
```

### `section:1` · section · 簡稱

```text
1.
簡稱
本條例可引稱為《危險品條例》。
```

### `section:2/note:4` · note · 

```text
(由2002年第4號第2條及2021年第5號編輯修訂紀錄修訂)
```

### `section:2/note:5` · note · 

```text
(由1971年第9號第3條增補)
```

