# Cap. 295 · 《危險品條例》

- 语言：`en`
- 版本：`hk:cap295:en:src-0a79145689ed`
- 状态：`passed`（技术处理完成不等于法律时效已核验）
- 结构单元：98；切片：98；发布资格：否

文本覆盖对账：True，片段 800，缺失 0，重复 0。

## 结构单元摘录（前 8 条）

### `long_title:1` · long_title · 

```text
To consolidate and amend the law relating to dangerous goods.
```

### `note:1` · note · 

```text
[27 July 1956]
```

### `note:2` · note · 

```text
(Format changes—E.R. 6 of 2019)
```

### `heading:part:4` · heading · Part I Preliminary

```text
Part I Preliminary
```

### `note:3` · note · 

```text
(Added 9 of 1971 s. 2)
```

### `section:1` · section · Short title

```text
1.
Short title
This Ordinance may be cited as the Dangerous Goods Ordinance.
```

### `section:2/note:4` · note · 

```text
(Amended 4 of 2002 s. 2 and E.R. 5 of 2021)
```

### `section:2/note:5` · note · 

```text
(Added 9 of 1971 s. 3)
```

